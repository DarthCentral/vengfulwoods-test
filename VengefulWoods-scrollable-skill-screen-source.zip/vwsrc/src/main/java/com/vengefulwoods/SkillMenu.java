package com.vengefulwoods;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * The tree, as a menu with no slots in it at all.
 * <p>
 * There is nothing to put anywhere: every click is a purchase. What the window carries is which class it is
 * drawing, how many points are left, and a bitmask of what has already been learned.
 */
public class SkillMenu extends AbstractContainerMenu {

    /** Points left, then one entry per skill holding its rank. */
    public static final int DATA_SIZE = 1 + Skill.values().length;

    private final ContainerData data;
    private final WoodsClass chosen;
    private final List<Skill> offered;

    public SkillMenu(int id, Inventory playerInventory, FriendlyByteBuf extra) {
        this(id, WoodsClass.byName(extra.readUtf(32)), new SimpleContainerData(DATA_SIZE));
    }

    public SkillMenu(int id, WoodsClass chosen, ContainerData data) {
        super(VengefulWoods.SKILL_MENU.get(), id);
        this.chosen = chosen;
        this.data = data;
        this.offered = new java.util.ArrayList<>();
        for (Skill skill : Skill.values()) {
            if (skill.openTo(chosen)) {
                offered.add(skill);
            }
        }
        addDataSlots(data);
    }

    public List<Skill> offered() {
        return offered;
    }

    public WoodsClass chosen() {
        return chosen;
    }

    public int points() {
        return data.get(0);
    }

    /** What rank this player has in a skill, as the window sees it. */
    public int rank(Skill skill) {
        return data.get(1 + skill.ordinal());
    }

    public boolean known(Skill skill) {
        return rank(skill) > 0;
    }

    /** True when the branch above has been taken, so this one can be bought. */
    public boolean unlocked(Skill skill) {
        return skill.requires == null || rank(skill.requires) > 0;
    }

    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id < 0 || id >= offered.size() || !(player instanceof ServerPlayer server)) {
            return false;
        }
        Skills.buy(server, offered.get(id));
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean stillValid(Player player) {
        return true;
    }
}
