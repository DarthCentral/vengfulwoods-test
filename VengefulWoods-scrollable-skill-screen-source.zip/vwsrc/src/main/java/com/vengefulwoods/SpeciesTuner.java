package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.tree.species.Species;

import java.lang.reflect.Field;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Changes how every Dynamic Trees species grows, depending on the current stage:
 * a faster natural growth rate from stage 1, and from stage 2 enough "signal energy" to reach the height cap
 * plus the widest trunk its tree family allows. The original values are remembered and put back when the
 * server stops.
 */
public final class SpeciesTuner {

    /** [growthRate, signalEnergy, maxBranchRadius] as Dynamic Trees defined them. */
    private static final Map<Species, float[]> ORIGINAL = new IdentityHashMap<>();
    /** [growthRate, signalEnergy, maxBranchRadius] as we last set them. */
    private static final Map<Species, float[]> APPLIED = new IdentityHashMap<>();

    /** Asked-for trunk radius at stage 2 and up. Dynamic Trees clamps this to whatever each tree family allows. */
    private static final int WIDE_TRUNK_RADIUS = 24;

    private static Field growthRateField;
    private static boolean growthRateLookedUp;

    private SpeciesTuner() {
    }

    /**
     * Reads a species' raw growth rate. Dynamic Trees has a setter for it but no plain getter, so this reads the
     * field directly. Returns NaN if that is not possible (growth-rate tuning is then simply skipped).
     */
    public static float readGrowthRate(Species species) {
        if (!growthRateLookedUp) {
            growthRateLookedUp = true;
            try {
                Field field = Species.class.getDeclaredField("growthRate");
                field.setAccessible(true);
                growthRateField = field;
            } catch (Throwable t) {
                VengefulWoods.LOGGER.warn("Could not read Dynamic Trees growth rates; natural growth will not be sped up.", t);
            }
        }
        if (growthRateField == null) {
            return Float.NaN;
        }
        try {
            return growthRateField.getFloat(species);
        } catch (Throwable t) {
            return Float.NaN;
        }
    }

    /** Applies the given stage to every species. Safe to call as often as you like. */
    public static void apply(Stage stage) {
        float multiplier = stage.naturalGrowthMultiplier();
        boolean tall = stage.atLeast(Stage.THICKENING);
        float heightCap = Config.MAX_TREE_HEIGHT.get();

        for (Species species : Species.REGISTRY.getAll()) {
            if (species == null || !species.isValid()) {
                continue;
            }
            float rate = readGrowthRate(species);
            float energy = species.getSignalEnergy();
            float radius = species.getMaxBranchRadius();

            float[] original = ORIGINAL.get(species);
            float[] applied = APPLIED.get(species);
            boolean changedBehindOurBack = applied != null
                    && ((!Float.isNaN(rate) && applied[0] != rate) || applied[1] != energy || applied[2] != radius);
            if (original == null || changedBehindOurBack) {
                // First time we see this species, or Dynamic Trees reloaded its data (/reload).
                original = new float[]{rate, energy, radius};
                ORIGINAL.put(species, original);
            }

            float newRate = original[0] * multiplier;
            float newEnergy = tall ? Math.max(original[1], heightCap) : original[1];

            if (!Float.isNaN(newRate)) {
                species.setGrowthRate(newRate);
            }
            species.setSignalEnergy(newEnergy);
            if (tall) {
                // Thicker trunks. Dynamic Trees clamps this per tree family, so most trees simply stay as they were.
                species.setMaxBranchRadius(WIDE_TRUNK_RADIUS);
            }
            APPLIED.put(species, new float[]{newRate, newEnergy, species.getMaxBranchRadius()});
        }
    }

    /** Puts every species back the way Dynamic Trees had it. */
    public static void reset() {
        for (Map.Entry<Species, float[]> entry : ORIGINAL.entrySet()) {
            Species species = entry.getKey();
            float[] original = entry.getValue();
            float[] applied = APPLIED.get(species);
            if (applied == null) {
                continue;
            }
            float rate = readGrowthRate(species);
            // Only undo values that are still ours.
            if (!Float.isNaN(original[0]) && !Float.isNaN(rate) && rate == applied[0]) {
                species.setGrowthRate(original[0]);
            }
            if (species.getSignalEnergy() == applied[1]) {
                species.setSignalEnergy(original[1]);
            }
            if (species.getMaxBranchRadius() == applied[2]) {
                species.setMaxBranchRadius((int) original[2]);
            }
        }
        ORIGINAL.clear();
        APPLIED.clear();
    }
}
