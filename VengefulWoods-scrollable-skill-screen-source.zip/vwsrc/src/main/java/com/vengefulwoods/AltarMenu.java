package com.vengefulwoods;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * The altar's own window.
 * <p>
 * Nine slots for what you are giving up, and a rite to pick from a list that only shows what you can
 * actually ask for. The numbers along the top - your anger, your favour, what you have banked - are kept in
 * sync so you can watch a price being met rather than guessing at it.
 */
public class AltarMenu extends AbstractContainerMenu {

    public static final int BOWL_SIZE = 9;
    /** Tribute, effective felled count, offerings, and the stage, in that order. */
    public static final int DATA_SIZE = 4;

    private final Container bowl;
    private final ContainerData data;
    private final List<Rite> rites;

    /** Built on the client from the packet the server sends when the window opens. */
    public AltarMenu(int id, Inventory playerInventory, FriendlyByteBuf extra) {
        this(id, playerInventory, new SimpleContainer(BOWL_SIZE), new SimpleContainerData(DATA_SIZE),
                Rite.forClass(WoodsClass.byName(extra.readUtf(32))));
    }

    public AltarMenu(int id, Inventory playerInventory, Container bowl, ContainerData data, List<Rite> rites) {
        super(VengefulWoods.ALTAR_MENU.get(), id);
        this.bowl = bowl;
        this.data = data;
        this.rites = rites;
        checkContainerSize(bowl, BOWL_SIZE);
        addDataSlots(data);

        // The bowl, in one row across the top.
        for (int i = 0; i < BOWL_SIZE; i++) {
            addSlot(new Slot(bowl, i, 8 + i * 18, 22));
        }
        // The player's own, in the usual place.
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 174 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(playerInventory, col, 8 + col * 18, 232));
        }
    }

    public List<Rite> rites() {
        return rites;
    }

    public int tribute() {
        return data.get(0);
    }

    public int felled() {
        return data.get(1);
    }

    public int offerings() {
        return data.get(2);
    }

    public Stage stage() {
        int index = Math.max(0, Math.min(Stage.values().length - 1, data.get(3)));
        return Stage.values()[index];
    }

    /** A rite was clicked. The id is its place in the list the window was given. */
    @Override
    public boolean clickMenuButton(Player player, int id) {
        if (id < 0 || id >= rites.size() || !(player instanceof ServerPlayer server)) {
            return false;
        }
        if (!(server.level() instanceof ServerLevel level)) {
            return false;
        }
        Rite rite = rites.get(id);
        // The altar has to still be there and still be within reach.
        if (!(bowl instanceof AltarBlockEntity altar)) {
            return false;
        }
        Rituals.perform(level, altar.getBlockPos(), server, rite);
        return true;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = slots.get(index);
        if (!slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack stack = slot.getItem();
        ItemStack original = stack.copy();
        if (index < BOWL_SIZE) {
            // Out of the bowl, back to the player.
            if (!moveItemStackTo(stack, BOWL_SIZE, slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else if (!moveItemStackTo(stack, 0, BOWL_SIZE, false)) {
            return ItemStack.EMPTY;
        }
        if (stack.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return original;
    }

    @Override
    public boolean stillValid(Player player) {
        return bowl.stillValid(player);
    }
}
