package com.vengefulwoods;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;

/**
 * What you came into these woods as.
 * <p>
 * Three of these are offered. The fourth is not: it is chosen by reaching for the empty space in the middle
 * of the other three, and nothing anywhere tells you it is there.
 */
public enum WoodsClass {

    /** Nobody has chosen yet. Plays exactly as the mod did before classes existed. */
    NONE,

    /**
     * Druid. Everything the forest is willing to give, it gives you twice as much of, and it will kill
     * what you point at.
     */
    DRUID,

    /**
     * Colonialist. You are here to take the wood out, the forest knows it, and you are paid in fire and
     * timber for the trouble. Open ground is where you are strongest, which is a problem, because the
     * forest is working very hard on there being less of it.
     */
    COLONIALIST,

    /**
     * Invader. The weeds are yours: cheap, harmless to you, and lethal to everything else. Right up until
     * there is more of them than there is of you.
     */
    INVADER,

    /** The Original. */
    MUSHROOM;

    public static WoodsClass of(@Nullable Player player) {
        if (!(player instanceof ServerPlayer server) || server.getServer() == null) {
            return NONE;
        }
        return WrathData.global(server.getServer()).own(server.getUUID()).woodsClass();
    }

    public static WoodsClass byName(String name) {
        for (WoodsClass value : values()) {
            if (value.name().equalsIgnoreCase(name)) {
                return value;
            }
        }
        return NONE;
    }

    public String key() {
        return "class.vengefulwoods." + name().toLowerCase(java.util.Locale.ROOT);
    }

    // ------------------------------------------------------------------------------------------------------------
    // What each one changes
    // ------------------------------------------------------------------------------------------------------------

    /** Multiplier on anger earned. The Colonialist is resented out of all proportion, and trades on it. */
    public double angerRate() {
        switch (this) {
            case COLONIALIST:
                return Config.COLONIALIST_ANGER.get();
            case DRUID:
                return 0.75; // It believes you did not mean it.
            default:
                return 1.0;
        }
    }

    /** Multiplier on favour earned. */
    public double favourRate() {
        switch (this) {
            case DRUID:
                return Config.DRUID_FAVOUR.get();
            case COLONIALIST:
                return 0.4; // It is not interested in your apology.
            default:
                return 1.0;
        }
    }

    /** The same, with whatever the player has learned folded in. */
    public static double favourRate(net.minecraft.world.entity.player.Player player) {
        double rate = of(player).favourRate();
        if (Skills.has(player, Skill.GREEN_TONGUE)) {
            rate *= 1.5;
        }
        return rate;
    }

    public static double angerRate(net.minecraft.world.entity.player.Player player) {
        return of(player).angerRate();
    }

    public static double heartwoodRate(net.minecraft.world.entity.player.Player player) {
        double rate = of(player).heartwoodFromFelling();
        if (Skills.has(player, Skill.TIMBERMAN)) {
            rate *= 2.0;
        }
        return rate;
    }

    public static double riteCostRate(net.minecraft.world.entity.player.Player player) {
        double rate = of(player).riteCostRate();
        if (Skills.has(player, Skill.GREEN_HAND)) {
            rate *= 0.6; // A green hand gets a better price out of the stone.
        }
        return rate;
    }

    /** Multiplier on heartwood out of a felled tree. */
    public double heartwoodFromFelling() {
        return this == COLONIALIST ? Config.COLONIALIST_HEARTWOOD.get() : 1.0;
    }

    /** Multiplier on what the rites charge for an invasive species. */
    public double riteCostRate() {
        return this == INVADER ? Config.INVADER_RITE_COST.get() : 1.0;
    }

    /** True when the weeds will not touch this player. */
    public boolean weedsSpare(Player player) {
        if (Skills.has(player, Skill.SYMBIOTE)) {
            return true; // It has stopped telling you from itself, in the useful direction.
        }
        return this == INVADER && !Invader.consumed(player);
    }

    /** True when this player's weeds hit everything else harder. */
    public boolean weedsFightForYou() {
        return this == INVADER;
    }
}
