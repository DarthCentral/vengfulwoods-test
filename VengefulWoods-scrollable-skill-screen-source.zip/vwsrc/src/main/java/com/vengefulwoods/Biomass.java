package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * What the forest has to spend.
 * <p>
 * Every standing tree feeds a pool. The forest can do one of two things with it. Early on it <em>spreads</em>
 * the pool across everything it owns, which is why an angry wood thickens evenly and slowly. Later it stops
 * doing that and <em>channels</em> the whole pool into one place - whatever is nearest the person it is angry
 * with - and the handful of trees standing over you get everything a thousand trees made. That is why the
 * later stages feel like the wood closing on you personally rather than simply growing.
 * <p>
 * The weeds keep their own pool and work the same way, except they only ever channel.
 */
public class Biomass {

    /** One dimension's pools, and what the forest is currently doing with its own. */
    private static final class Pool {
        float forest;
        float weeds;
        /** Where the forest is pouring itself, when it is channelling. */
        @Nullable
        BlockPos focus;
        long focusSet;
        long lastTold;
    }

    private static final Map<ResourceKey<Level>, Pool> POOLS = new HashMap<>();

    public static void clear() {
        POOLS.clear();
    }

    private static Pool pool(ServerLevel level) {
        return POOLS.computeIfAbsent(level.dimension(), key -> new Pool());
    }

    // ------------------------------------------------------------------------------------------------------------
    // Earning it
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Credits the forest for a day's standing timber. The more wood there is, the more there is to move
     * around, so a forest that has already overgrown a valley grows faster still.
     */
    static void growForest(ServerLevel level, int trees, float days) {
        if (!Config.BIOMASS_ENABLED.get() || trees <= 0 || days <= 0.0F) {
            return;
        }
        Pool pool = pool(level);
        pool.forest = Math.min(pool.forest + trees * Config.BIOMASS_PER_TREE.get().floatValue() * days,
                Config.BIOMASS_CAP.get().floatValue());
    }

    /** The same for a weed, counted off the blocks it has in the ground. */
    static void growWeeds(ServerLevel level, int blocks, float days) {
        if (!Config.BIOMASS_ENABLED.get() || blocks <= 0 || days <= 0.0F) {
            return;
        }
        Pool pool = pool(level);
        pool.weeds = Math.min(pool.weeds + blocks * Config.BIOMASS_PER_WEED.get().floatValue() * days,
                Config.BIOMASS_CAP.get().floatValue());
    }

    // ------------------------------------------------------------------------------------------------------------
    // Spending it
    // ------------------------------------------------------------------------------------------------------------

    /** True once the forest has stopped spreading itself thin and started aiming. */
    static boolean channels(Stage stage) {
        return Config.BIOMASS_ENABLED.get() && stage.atLeast(Stage.RELENTLESS);
    }

    /**
     * Where the forest is currently pouring everything. Re-aimed every so often at whoever it is angriest
     * with, and held there in between so the growth stays in one place long enough to be frightening.
     */
    @Nullable
    static BlockPos focus(ServerLevel level, List<ServerPlayer> players, Stage stage, long now) {
        if (!channels(stage) || players.isEmpty()) {
            return null;
        }
        Pool pool = pool(level);
        int hold = Config.BIOMASS_FOCUS_SECONDS.get() * 20;
        if (pool.focus != null && now - pool.focusSet < hold) {
            return pool.focus;
        }
        ServerPlayer worst = null;
        int worstFelled = -1;
        for (ServerPlayer player : players) {
            if (player.isCreative() || player.isSpectator()) {
                continue;
            }
            int felled = WrathData.global(level.getServer()).account(player.getUUID()).effectiveFelled();
            if (felled > worstFelled) {
                worstFelled = felled;
                worst = player;
            }
        }
        if (worst == null) {
            return null;
        }
        pool.focus = worst.blockPosition();
        pool.focusSet = now;

        // Tell them once in a while. Growth this violent with no explanation just reads as a glitch.
        if (now - pool.lastTold > 2400L && pool.forest > Config.BIOMASS_PER_SIGNAL.get() * 40.0) {
            pool.lastTold = now;
            worst.displayClientMessage(Component.translatable("message.vengefulwoods.channelling")
                    .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), true);
        }
        return pool.focus;
    }

    /**
     * How many extra growth pulses one tree gets out of the pool this visit.
     * <p>
     * Spread thin, that is a fraction of a pulse per tree and the whole wood creeps. Channelled, every tree
     * near the focus can draw as much as it can use, and the pool empties into them.
     */
    static int drawForest(ServerLevel level, BlockPos tree, @Nullable BlockPos focus, Stage stage, int trees) {
        if (!Config.BIOMASS_ENABLED.get() || stage == Stage.DORMANT) {
            return 0;
        }
        Pool pool = pool(level);
        float perSignal = Config.BIOMASS_PER_SIGNAL.get().floatValue();
        if (perSignal <= 0.0F || pool.forest < perSignal) {
            return 0;
        }

        float share;
        if (focus != null) {
            double range = Config.BIOMASS_FOCUS_RANGE.get();
            if (tree.distSqr(focus) > range * range) {
                return 0; // Everything is going somewhere else. This tree gets nothing at all.
            }
            // The whole pool is aimed at a handful of trees, so each may take a real bite of it.
            share = pool.forest * (float) (double) Config.BIOMASS_CHANNEL_SHARE.get();
        } else {
            // Spread across every tree the forest is keeping track of.
            share = pool.forest / Math.max(1, trees);
        }

        int signals = (int) (share / perSignal);
        int most = focus != null ? Config.BIOMASS_CHANNEL_MAX.get() : Config.BIOMASS_SPREAD_MAX.get();
        signals = Math.min(signals, most);
        if (signals <= 0) {
            return 0;
        }
        pool.forest = Math.max(0.0F, pool.forest - signals * perSignal);
        return signals;
    }

    /** The weeds' own pool, drawn on to put extra blocks down near whoever is nearest. */
    static int drawWeeds(ServerLevel level, int most) {
        if (!Config.BIOMASS_ENABLED.get()) {
            return 0;
        }
        Pool pool = pool(level);
        float perBlock = Config.BIOMASS_PER_WEED_BLOCK.get().floatValue();
        if (perBlock <= 0.0F || pool.weeds < perBlock) {
            return 0;
        }
        int blocks = Math.min((int) (pool.weeds / perBlock), most);
        if (blocks <= 0) {
            return 0;
        }
        pool.weeds -= blocks * perBlock;
        return blocks;
    }

    /** For the status readout at an altar. */
    static float forestPool(ServerLevel level) {
        return pool(level).forest;
    }

    static float weedPool(ServerLevel level) {
        return pool(level).weeds;
    }
}
