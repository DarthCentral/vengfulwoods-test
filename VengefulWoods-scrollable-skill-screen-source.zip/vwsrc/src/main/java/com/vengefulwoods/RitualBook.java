package com.vengefulwoods;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * The book you are given on the way in.
 * <p>
 * It is a plain written book rather than anything clever, because the point of it is that you can read it
 * in the first thirty seconds without being taught an interface first. It says what the forest counts, what
 * it will trade, and what each of the four of you is. It does not say everything.
 */
public class RitualBook {

    private static final String TAG = "vengefulwoods_given";

    /** A page, as the written-book format wants it: one JSON text component per page. */
    private static String page(String text) {
        return "{\"text\":\"" + text.replace("\"", "\\\"") + "\"}";
    }

    public static ItemStack book() {
        ItemStack stack = new ItemStack(Items.WRITTEN_BOOK);
        ListTag pages = new ListTag();

        pages.add(StringTag.valueOf(page(
                "§lOn the Woods§r\n\n"
                + "Everything in here keeps count.\n\n"
                + "Fell a tree and it is remembered against you. Burn one, blast one — the same. "
                + "The count is yours alone; your friends have their own.\n\n"
                + "Nine moods, and it climbs.")));

        pages.add(StringTag.valueOf(page(
                "§lMaking peace§r\n\n"
                + "Fertilizer, fed to any tree, buys back one tree's worth of grudge.\n\n"
                + "Do enough of it and the woods start leaving things at the roots for you. "
                + "Keep going and they fight for you.\n\n"
                + "They will not notice an apology once the roots are out.")));

        pages.add(StringTag.valueOf(page(
                "§lThe altar§r\n\n"
                + "Build one from heartwood, fertilizer and logs.\n\n"
                + "Use it empty-handed to open it. Put what you are giving up in the basin — "
                + "timber counts for most, a log being worth three of anything else — "
                + "then pick a rite from the list.\n\n"
                + "Crouch and use it to read where you stand.")));

        pages.add(StringTag.valueOf(page(
                "§lRites§r\n\n"
                + "§oGroves§r calls up saplings.\n"
                + "§oRoots§r sends out rhizomes.\n"
                + "§oThe Bargain§r hands you timber and charges you for it.\n"
                + "§oSeeding§r lays down a weed — whichever the ground answers with.\n"
                + "§oQuiet§r buys back some of its memory. Dearly.")));

        pages.add(StringTag.valueOf(page(
                "§lThe one to be careful of§r\n\n"
                + "§oBlight§r lets kudzu in on purpose.\n\n"
                + "It will not arrive on its own. Somebody has to ask.\n\n"
                + "Whoever asks is remembered for it, and so is whoever lets anything get away from them.")));

        pages.add(StringTag.valueOf(page(
                "§lWhat you are§r\n\n"
                + "§oDruid§r — given more than anyone, and able to point the woods at a thing.\n\n"
                + "§oColonialist§r — hated at nearly twice the rate, paid in timber and fire, "
                + "strongest where there are no trees left.")));

        pages.add(StringTag.valueOf(page(
                "§lWhat you are§r\n\n"
                + "§oInvader§r — the weeds are cheap, they spare you, and they savage "
                + "everything else. While there is less of them than there is of you.\n\n"
                + "There was a fourth thing on the stone. I did not take it and I did not look long at it.")));

        pages.add(StringTag.valueOf(page(
                "§lLearning§r\n\n"
                + "Press §lU§r.\n\n"
                + "Every step up the woods' anger is worth a point, and so is every step up their "
                + "goodwill. They count the furthest you ever got, not where you are now.\n\n"
                + "Four things are open to anyone. The rest depend on what you are.")));

        pages.add(StringTag.valueOf(page(
                "§lLast§r\n\n"
                + "Cut a weed with a tool and nothing drops; cut it by hand and it pays.\n\n"
                + "Any piece of any of them, put back in the ground, becomes all of it again.\n\n"
                + "Do not let anything get away from you.")));

        CompoundTag tag = stack.getOrCreateTag();
        tag.put("pages", pages);
        tag.putString("title", "On the Woods");
        tag.putString("author", "a forester, unnamed");
        tag.putInt("generation", 2);
        return stack;
    }

    /** Handed over the first time somebody joins, and never again. */
    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !Config.RITUAL_BOOK.get()) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        CompoundTag persisted = data.getCompound(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG);
        if (persisted.getBoolean(TAG)) {
            return;
        }
        persisted.putBoolean(TAG, true);
        data.put(net.minecraft.world.entity.player.Player.PERSISTED_NBT_TAG, persisted);

        if (!player.getInventory().add(book())) {
            player.drop(book(), false);
        }
        player.displayClientMessage(Component.translatable("message.vengefulwoods.book_given")
                .withStyle(net.minecraft.ChatFormatting.DARK_GREEN), false);
    }
}
