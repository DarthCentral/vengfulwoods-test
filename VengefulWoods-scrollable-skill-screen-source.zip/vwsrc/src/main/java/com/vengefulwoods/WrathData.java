package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Saved with the world.
 * <p>
 * The forest keeps a separate account for every player: how many trees that person has destroyed, and how
 * many offerings they have made. One player can be hunted while another is looked after. The accounts live
 * in the overworld's copy of this data, so they are shared across dimensions; rhizome tips, pending regrowth
 * and cages are stored per dimension.
 */
public class WrathData extends SavedData {

    private static final String NAME = "vengefulwoods";

    /** One player's standing with the forest. */
    public static final class Account {
        public int felled;
        public int offerings;
        /** Weight of everything given to the altar, which is what the rites are bought with. */
        public int tribute;
        /** What this player came into the woods as. Chosen once, and kept. */
        public String woodsClass = "NONE";
        /** How far the Invader's own weeds have got into him, and how far the Mushroom has got. */
        public int classProgress;
        /**
         * What has been learned: one entry per skill, holding its rank. An array rather than packed bits,
         * because packing capped every skill at rank three and that ceiling kept getting in the way.
         */
        public int[] skillRanks = new int[Skill.values().length];
        /** The furthest this player has ever got, which is what skill points are counted off. */
        public int peakStage;
        public int peakBoon;

        public WoodsClass woodsClass() {
            return WoodsClass.byName(woodsClass);
        }

        public int effectiveFelled() {
            return Math.max(0, felled - offerings * Config.WRATH_PER_OFFERING.get());
        }

        public Stage stage() {
            return Stage.forCount(effectiveFelled());
        }

        public Boon boon() {
            return Boon.forOfferings(offerings, stage());
        }
    }

    /** The growing end of a rhizome. */
    public static final class Tip {
        public BlockPos pos;
        public Direction dir;
        public int length;
        public final String species;
        public float budget;
        public float saplingBudget;

        // Not saved - rebuilt while the game runs.
        public long lastGameTime = -1L;
        public long lastDayTime = -1L;
        public BlockPos target;
        public boolean targetIsPlayer;
        public long targetChecked = -1000L;

        public Tip(BlockPos pos, Direction dir, String species) {
            this.pos = pos;
            this.dir = dir;
            this.species = species;
        }
    }

    /** A destroyed tree that is going to come back. */
    public static final class Regrow {
        public final BlockPos rootPos;
        public final String species;
        public final long dueGameTime;
        public final long dueDayTime;

        public Regrow(BlockPos rootPos, String species, long dueGameTime, long dueDayTime) {
            this.rootPos = rootPos;
            this.species = species;
            this.dueGameTime = dueGameTime;
            this.dueDayTime = dueDayTime;
        }
    }

    /** A block of a temporary cage that has to be taken away again. */
    public static final class Cage {
        public final BlockPos pos;
        public final long expiryGameTime;

        public Cage(BlockPos pos, long expiryGameTime) {
            this.pos = pos;
            this.expiryGameTime = expiryGameTime;
        }
    }

    /**
     * What one escaped species has cost, and what has been done about it. Kept with the world, because an
     * escape that survives a restart should still be hanging over the person who caused it.
     */
    public static final class Escape {
        /** Blocks this species has laid down since it got loose. */
        public int grown;
        /** Blocks players have pulled out of it by hand. */
        public int cleared;
        /** True when somebody put it there on purpose rather than it spreading from elsewhere. */
        public boolean deliberate;
        /** Anger charged to each player on this species' account, and so refundable. */
        public final Map<UUID, Integer> charged = new HashMap<>();
    }

    /** Keyed by species name. */
    public final Map<String, Escape> escapes = new HashMap<>();

    public Escape escape(String species) {
        return escapes.computeIfAbsent(species, key -> new Escape());
    }

    private final Map<UUID, Account> accounts = new HashMap<>();
    public final List<Tip> tips = new ArrayList<>();
    public final List<Regrow> regrows = new ArrayList<>();
    public final List<Cage> cages = new ArrayList<>();

    public WrathData() {
    }

    public static WrathData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(WrathData::load, WrathData::new, NAME);
    }

    /** The copy that holds everyone's standing with the forest. */
    public static WrathData global(MinecraftServer server) {
        return get(server.overworld());
    }

    // ------------------------------------------------------------------------------------------------------------
    // Accounts
    // ------------------------------------------------------------------------------------------------------------

    /**
     * The record everybody shares when the server has turned sharing on. It is kept in with the players so
     * that it saves and loads like any other account, and skipped anywhere the mod is listing people.
     */
    public static final UUID SHARED = new UUID(0L, 0L);

    /**
     * This player's own record, whatever the sharing settings say. Their class, their class progress, and
     * their own private tally of what they personally have done.
     */
    public Account own(UUID id) {
        return accounts.computeIfAbsent(id, key -> new Account());
    }

    /**
     * The record that carries standing - the forest's hate and its favour. One per player normally, or one
     * for the whole server when shareStanding is on, in which case what any one of them does lands on
     * all of them.
     */
    public Account account(UUID id) {
        return own(Config.SHARE_STANDING.get() ? SHARED : id);
    }

    /** The record that carries skill points and ranks. Pooled when shareSkills is on. */
    public Account skills(UUID id) {
        return own(Config.SHARE_SKILLS.get() ? SHARED : id);
    }

    public Map<UUID, Account> accounts() {
        return accounts;
    }

    /** True for the pooled record, which is not a person and should never be listed as one. */
    public static boolean isShared(UUID id) {
        return SHARED.equals(id);
    }

    /**
     * One more tree held against this player. What one tree is worth depends on who felled it: the
     * Colonialist is resented out of all proportion, and the Druid is given the benefit of the doubt.
     */
    public void addFelled(UUID id) {
        Account account = account(id);
        double rate = own(id).woodsClass().angerRate();
        account.felled += Math.max(1, (int) Math.round(rate));
        // Rates below one are handled as a chance, so a Druid genuinely loses some of them.
        if (rate < 1.0 && Math.random() >= rate) {
            account.felled--;
        }
        setDirty();
    }

    /** One offering exactly, with no class or skill rate applied. The callers handle that. */
    public void addOfferingFlat(UUID id) {
        account(id).offerings++;
        setDirty();
    }

    public void addOffering(UUID id) {
        Account account = account(id);
        double rate = own(id).woodsClass().favourRate();
        account.offerings += Math.max(1, (int) Math.round(rate));
        if (rate < 1.0 && Math.random() >= rate) {
            account.offerings--;
        }
        setDirty();
    }

    public void addTribute(UUID id, int amount) {
        account(id).tribute = Math.max(0, account(id).tribute + amount);
        setDirty();
    }

    /** Takes payment for a rite. Returns false and takes nothing if the altar has not been given enough. */
    public boolean spendTribute(UUID id, int cost) {
        Account account = account(id);
        if (account.tribute < cost) {
            return false;
        }
        account.tribute -= cost;
        setDirty();
        return true;
    }

    public void setClass(UUID id, WoodsClass chosen) {
        own(id).woodsClass = chosen.name();
        setDirty();
    }

    public void setClassProgress(UUID id, int progress) {
        own(id).classProgress = Math.max(0, progress);
        setDirty();
    }

    public void setFelled(UUID id, int felled) {
        account(id).felled = Math.max(0, felled);
        setDirty();
    }

    public void setOfferings(UUID id, int offerings) {
        account(id).offerings = Math.max(0, offerings);
        setDirty();
    }

    public void clearAccounts() {
        accounts.clear();
        setDirty();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Reading the forest's mood
    // ------------------------------------------------------------------------------------------------------------

    /** How angry the forest is with this particular player. */
    public static Stage stageOf(MinecraftServer server, @Nullable UUID id) {
        return id == null ? Stage.DORMANT : global(server).account(id).stage();
    }

    /** How fond the forest is of this particular player. */
    public static Boon boonOf(MinecraftServer server, @Nullable UUID id) {
        return id == null ? Boon.NONE : global(server).account(id).boon();
    }

    /**
     * The angriest the forest is with anybody currently online. Used for the things that cannot be aimed at
     * one person, such as how fast trees grow in the world at large.
     */
    public static Stage worstStage(MinecraftServer server) {
        WrathData data = global(server);
        Stage worst = Config.SHARE_STANDING.get() ? data.account(SHARED).stage() : Stage.DORMANT;
        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            Stage stage = data.account(player.getUUID()).stage();
            if (stage.atLeast(worst)) {
                worst = stage;
            }
        }
        return worst;
    }

    /**
     * The mood that applies at a spot in the world: the standing of the nearest player, since the forest reacts
     * to whoever is in front of it.
     */
    public static Stage stageNear(MinecraftServer server, BlockPos pos, List<ServerPlayer> players, double range) {
        ServerPlayer nearest = ForestDirector.nearestPlayer(players, pos, range, false);
        return nearest == null ? Stage.DORMANT : stageOf(server, nearest.getUUID());
    }

    // ------------------------------------------------------------------------------------------------------------
    // Saving
    // ------------------------------------------------------------------------------------------------------------

    public static WrathData load(CompoundTag tag) {
        WrathData data = new WrathData();

        ListTag accountList = tag.getList("accounts", Tag.TAG_COMPOUND);
        for (int i = 0; i < accountList.size(); i++) {
            CompoundTag t = accountList.getCompound(i);
            try {
                Account account = new Account();
                account.felled = t.getInt("felled");
                account.offerings = t.getInt("offerings");
                account.tribute = t.getInt("tribute");
                String chosen = t.getString("class");
                account.woodsClass = chosen.isEmpty() ? "NONE" : chosen;
                account.classProgress = t.getInt("classProgress");
                int[] stored = t.getIntArray("skillRanks");
                for (int slot = 0; slot < stored.length && slot < account.skillRanks.length; slot++) {
                    account.skillRanks[slot] = stored[slot];
                }
                account.peakStage = t.getInt("peakStage");
                account.peakBoon = t.getInt("peakBoon");
                data.accounts.put(UUID.fromString(t.getString("player")), account);
            } catch (RuntimeException ignored) {
                // A broken entry should never stop a world from loading.
            }
        }

        ListTag escapeList = tag.getList("escapes", Tag.TAG_COMPOUND);
        for (int i = 0; i < escapeList.size(); i++) {
            CompoundTag t = escapeList.getCompound(i);
            try {
                Escape escape = new Escape();
                escape.grown = t.getInt("grown");
                escape.cleared = t.getInt("cleared");
                escape.deliberate = t.getBoolean("deliberate");
                ListTag chargedList = t.getList("charged", Tag.TAG_COMPOUND);
                for (int j = 0; j < chargedList.size(); j++) {
                    CompoundTag c = chargedList.getCompound(j);
                    escape.charged.put(UUID.fromString(c.getString("player")), c.getInt("trees"));
                }
                data.escapes.put(t.getString("species"), escape);
            } catch (RuntimeException ignored) {
                // A broken entry should never stop a world from loading.
            }
        }

        ListTag tipList = tag.getList("tips", Tag.TAG_COMPOUND);
        for (int i = 0; i < tipList.size(); i++) {
            CompoundTag t = tipList.getCompound(i);
            Tip tip = new Tip(BlockPos.of(t.getLong("pos")), Direction.from2DDataValue(t.getInt("dir")), t.getString("species"));
            tip.length = t.getInt("length");
            tip.budget = t.getFloat("budget");
            tip.saplingBudget = t.getFloat("saplings");
            data.tips.add(tip);
        }

        ListTag regrowList = tag.getList("regrows", Tag.TAG_COMPOUND);
        for (int i = 0; i < regrowList.size(); i++) {
            CompoundTag t = regrowList.getCompound(i);
            data.regrows.add(new Regrow(BlockPos.of(t.getLong("pos")), t.getString("species"),
                    t.getLong("dueGame"), t.getLong("dueDay")));
        }

        ListTag cageList = tag.getList("cages", Tag.TAG_COMPOUND);
        for (int i = 0; i < cageList.size(); i++) {
            CompoundTag t = cageList.getCompound(i);
            data.cages.add(new Cage(BlockPos.of(t.getLong("pos")), t.getLong("expiry")));
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag accountList = new ListTag();
        for (Map.Entry<UUID, Account> entry : accounts.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putString("player", entry.getKey().toString());
            t.putInt("felled", entry.getValue().felled);
            t.putInt("offerings", entry.getValue().offerings);
            t.putInt("tribute", entry.getValue().tribute);
            t.putString("class", entry.getValue().woodsClass);
            t.putInt("classProgress", entry.getValue().classProgress);
            t.putIntArray("skillRanks", entry.getValue().skillRanks);
            t.putInt("peakStage", entry.getValue().peakStage);
            t.putInt("peakBoon", entry.getValue().peakBoon);
            accountList.add(t);
        }
        tag.put("accounts", accountList);

        ListTag escapeList = new ListTag();
        for (Map.Entry<String, Escape> entry : escapes.entrySet()) {
            CompoundTag t = new CompoundTag();
            t.putString("species", entry.getKey());
            t.putInt("grown", entry.getValue().grown);
            t.putInt("cleared", entry.getValue().cleared);
            t.putBoolean("deliberate", entry.getValue().deliberate);
            ListTag chargedList = new ListTag();
            for (Map.Entry<UUID, Integer> charged : entry.getValue().charged.entrySet()) {
                CompoundTag c = new CompoundTag();
                c.putString("player", charged.getKey().toString());
                c.putInt("trees", charged.getValue());
                chargedList.add(c);
            }
            t.put("charged", chargedList);
            escapeList.add(t);
        }
        tag.put("escapes", escapeList);

        ListTag tipList = new ListTag();
        for (Tip tip : tips) {
            CompoundTag t = new CompoundTag();
            t.putLong("pos", tip.pos.asLong());
            t.putInt("dir", tip.dir.get2DDataValue());
            t.putString("species", tip.species);
            t.putInt("length", tip.length);
            t.putFloat("budget", tip.budget);
            t.putFloat("saplings", tip.saplingBudget);
            tipList.add(t);
        }
        tag.put("tips", tipList);

        ListTag regrowList = new ListTag();
        for (Regrow regrow : regrows) {
            CompoundTag t = new CompoundTag();
            t.putLong("pos", regrow.rootPos.asLong());
            t.putString("species", regrow.species);
            t.putLong("dueGame", regrow.dueGameTime);
            t.putLong("dueDay", regrow.dueDayTime);
            regrowList.add(t);
        }
        tag.put("regrows", regrowList);

        ListTag cageList = new ListTag();
        for (Cage cage : cages) {
            CompoundTag t = new CompoundTag();
            t.putLong("pos", cage.pos.asLong());
            t.putLong("expiry", cage.expiryGameTime);
            cageList.add(t);
        }
        tag.put("cages", cageList);
        return tag;
    }
}
