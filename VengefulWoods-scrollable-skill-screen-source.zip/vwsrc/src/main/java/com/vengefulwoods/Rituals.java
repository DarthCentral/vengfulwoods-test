package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.tree.species.Species;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * The altar, and everything done at it.
 * <p>
 * Three rites, each bought with its own charm: one calls up whatever grows best in this country, one calls up
 * the forest's own roots, and one strikes a bargain - a pile of good timber now, and the forest's lasting
 * opinion of you for it. There is a fourth thing people do at altars, which is kill something on them.
 */
public class Rituals {

    private static final int SACRIFICE_RADIUS = 6;

    // ------------------------------------------------------------------------------------------------------------
    // Using the altar
    // ------------------------------------------------------------------------------------------------------------

    static InteractionResult use(ServerLevel level, BlockPos pos, ServerPlayer player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (Config.CLASSES_ENABLED.get() && ClassChoice.undecided(player)) {
            ClassChoice.open(player); // Nothing else here works until you have decided what you are.
            return InteractionResult.SUCCESS;
        }
        if (stack.isEmpty()) {
            if (player.isShiftKeyDown()) {
                describe(level, pos, player); // Crouch for the numbers.
                return InteractionResult.SUCCESS;
            }
            // Open the bowl. Put in what you are giving up, then use a charm on the altar to work the rite.
            net.minecraft.world.level.block.entity.BlockEntity entity = level.getBlockEntity(pos);
            if (entity instanceof net.minecraft.world.MenuProvider provider) {
                net.minecraftforge.network.NetworkHooks.openScreen(player, provider,
                        buffer -> buffer.writeUtf(WoodsClass.of(player).name()));
            }
            return InteractionResult.SUCCESS;
        }

        // Anything waiting in the bowl is counted and taken the moment a rite is worked.
        swallowBowl(level, pos, player);

        boolean done;
        if (stack.is(VengefulWoods.GROVE_CHARM.get())) {
            done = groveRite(level, pos, player);
        } else if (stack.is(VengefulWoods.ROOT_TOTEM.get())) {
            done = rootRite(level, pos, player);
        } else if (stack.is(VengefulWoods.BARGAIN_IDOL.get())) {
            done = bargainRite(level, pos, player);
        } else if (stack.is(VengefulWoods.SEEDBED_CHARM.get())) {
            done = seedingRite(level, pos, player);
        } else if (stack.is(VengefulWoods.BLIGHT_SEED.get())) {
            done = blightRite(level, pos, player);
        } else if (stack.is(VengefulWoods.SPORE_IDOL.get())) {
            done = originalRite(level, pos, player);
        } else if (!plainOffering(level, pos, player, stack)) {
            done = tributeOffering(level, pos, player, stack);
        } else {
            done = true;
        }

        if (!done) {
            return InteractionResult.CONSUME;
        }
        if (!player.isCreative()) {
            stack.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }

    /**
     * Takes everything left in the altar's bowl as tribute. Timber counts for a log apiece, which is what
     * makes felling a stand and handing the wood over the straightforward way to pay for a rite.
     */
    private static void swallowBowl(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!(level.getBlockEntity(pos) instanceof AltarBlockEntity altar) || altar.isEmpty()) {
            return;
        }
        int total = 0;
        for (int slot = 0; slot < altar.getContainerSize(); slot++) {
            ItemStack stack = altar.getItem(slot);
            if (stack.isEmpty()) {
                continue;
            }
            total += stack.getCount() * worthOf(stack);
            altar.setItem(slot, ItemStack.EMPTY);
        }
        if (total <= 0) {
            return;
        }
        WrathData global = WrathData.global(level.getServer());
        global.addTribute(player.getUUID(), total);
        level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
                18, 0.4, 0.3, 0.4, 0.0);
        Sounds.play(level, pos, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 0.9F, 0.8F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.tribute",
                        total, global.account(player.getUUID()).tribute)
                .withStyle(ChatFormatting.DARK_GREEN), false);
    }

    /**
     * Where you stand, in plain words, with the price of everything you might want next to it. Crouch and
     * use an altar empty-handed for this; the whole mod is otherwise guesswork.
     */
    private static void describe(ServerLevel level, BlockPos pos, ServerPlayer player) {
        MinecraftServer server = level.getServer();
        WrathData global = WrathData.global(server);
        WrathData.Account account = global.account(player.getUUID());
        player.displayClientMessage(Component.literal(Config.SHARE_STANDING.get()
                        ? "--- The forest, on all of you ---" : "--- The forest, on you ---")
                .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.BOLD), false);
        player.displayClientMessage(Component.translatable(global.own(player.getUUID()).woodsClass().key())
                .withStyle(ChatFormatting.GREEN), false);
        player.displayClientMessage(Component.literal("Anger: " + account.stage()
                        + "   (" + account.effectiveFelled() + " trees against you)")
                .withStyle(ChatFormatting.GRAY), false);
        player.displayClientMessage(Component.literal("Favour: " + account.boon()
                        + "   (" + account.offerings + " offerings given)")
                .withStyle(ChatFormatting.GRAY), false);
        player.displayClientMessage(Component.literal("Tribute banked: " + account.tribute
                        + "   (a log is worth " + Config.TRIBUTE_PER_LOG.get() + ")")
                .withStyle(ChatFormatting.GRAY), false);
        player.displayClientMessage(Component.literal("Rites: seeding "
                        + Config.TRIBUTE_BLACKBERRY.get() + "-" + Config.TRIBUTE_KNOTWEED.get()
                        + ", kudzu " + Config.TRIBUTE_KUDZU.get()
                        + "   |  use empty-handed to open the bowl")
                .withStyle(ChatFormatting.DARK_GRAY), false);
        player.displayClientMessage(Component.literal("Biomass in the wood here: "
                        + (int) Biomass.forestPool(level))
                .withStyle(ChatFormatting.DARK_GRAY), false);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
                6, 0.3, 0.2, 0.3, 0.0);
    }

    // ------------------------------------------------------------------------------------------------------------
    // The rites
    // ------------------------------------------------------------------------------------------------------------

    /** Calls up a grove of whatever species belongs in this country. */
    private static boolean groveRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Species species = bestSpeciesFor(level, pos);
        if (species == null) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        ForestDirector.LevelState st = ForestDirector.state(level);
        Stage stage = WrathData.stageOf(level.getServer(), player.getUUID());
        RandomSource random = level.random;
        int planted = 0;

        for (int attempt = 0; attempt < 48 && planted < Config.RITE_GROVE_SIZE.get(); attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = 2.0 + random.nextDouble() * 6.0;
            BlockPos spot = pos.offset((int) Math.round(Math.cos(angle) * distance), 1,
                    (int) Math.round(Math.sin(angle) * distance));
            if (ForestDirector.trySprout(level, st, species, spot, 3, stage, level.getGameTime())) {
                planted++;
            }
        }
        if (planted == 0) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }

        reward(level, player, 1);
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_grove", planted,
                species.getLocalizedName()));
        return true;
    }

    /** Calls the forest's own roots up out of the ground, wherever you are standing. */
    private static boolean rootRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        WrathData data = WrathData.get(level);
        Species species = bestSpeciesFor(level, pos);
        if (species == null) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        int count = Config.RITE_ROOTS.get();
        for (int i = 0; i < count; i++) {
            BlockPos start = pos.offset(level.random.nextInt(5) - 2, -1, level.random.nextInt(5) - 2);
            if (!Rhizomes.canBurrow(level, start, level.getBlockState(start))) {
                continue;
            }
            level.setBlock(start, VengefulWoods.RHIZOME.get().defaultBlockState(), 3);
            data.tips.add(new WrathData.Tip(start,
                    net.minecraft.core.Direction.from2DDataValue(level.random.nextInt(4)),
                    species.getRegistryName().toString()));
        }
        data.setDirty();
        Rhizomes.burst(level, pos.above());
        reward(level, player, 1);
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_roots"));
        return true;
    }

    /** Timber now, and the forest's lasting opinion of you as the price. */
    private static boolean bargainRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Species species = bestSpeciesFor(level, pos);
        Block log = species == null ? null : species.getFamily().getPrimitiveLog().orElse(null);
        ItemStack payment = log != null
                ? new ItemStack(log, Config.RITE_BARGAIN_LOGS.get())
                : new ItemStack(Items.OAK_LOG, Config.RITE_BARGAIN_LOGS.get());

        WrathData global = WrathData.global(level.getServer());
        WrathData.Account account = global.account(player.getUUID());
        Stage before = account.stage();
        global.setFelled(player.getUUID(), account.felled + Config.RITE_BARGAIN_COST.get());
        Stage after = global.account(player.getUUID()).stage();
        SpeciesTuner.apply(WrathData.worstStage(level.getServer()));

        Block.popResource(level, pos.above(), payment);
        level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5,
                24, 0.5, 0.4, 0.5, 0.02);
        Sounds.play(level, pos, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.6F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_bargain")
                .withStyle(ChatFormatting.DARK_RED), false);
        if (after != before) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + after.ordinal())
                    .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
        }
        return true;
    }

    /** Lets the weed in on purpose. The forest will remember that it was you who opened the door. */

    /**
     * Works a rite by name, which is how the altar's own window asks for one. The charms still go through
     * the old path; this is the same thing with the guesswork taken out.
     */
    static boolean perform(ServerLevel level, BlockPos pos, ServerPlayer player, Rite rite) {
        if (!rite.openTo(WoodsClass.of(player))) {
            fail(level, pos, player, "message.vengefulwoods.rite_refused");
            return false;
        }
        swallowBowl(level, pos, player);
        switch (rite) {
            case GROVES:
                return groveRite(level, pos, player);
            case ROOTS:
                return rootRite(level, pos, player);
            case BARGAIN:
                return bargainRite(level, pos, player);
            case SEEDING:
                return seedingRite(level, pos, player);
            case BLIGHT:
                return blightRite(level, pos, player);
            case QUIET:
                return quietRite(level, pos, player);
            case THORNS:
                return thornsRite(level, pos, player);
            case ASH:
                return ashRite(level, pos, player);
            case SWARM:
                return swarmRite(level, pos, player);
            default:
                return originalRite(level, pos, player);
        }
    }

    /** Takes the price, or tells them what it would have been. */
    private static boolean charge(ServerLevel level, BlockPos pos, ServerPlayer player, int cost) {
        if (cost <= 0) {
            return true;
        }
        WrathData global = WrathData.global(level.getServer());
        if (!global.spendTribute(player.getUUID(), cost)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_tribute",
                            cost, global.account(player.getUUID()).tribute)
                    .withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        return true;
    }

    /**
     * The Rite of Quiet. Buys back some of what the forest holds against you, at a price that makes it a
     * last resort rather than a way of life.
     */
    private static boolean quietRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!charge(level, pos, player, Config.RITE_QUIET_COST.get())) {
            return false;
        }
        WrathData global = WrathData.global(level.getServer());
        WrathData.Account account = global.account(player.getUUID());
        int forgiven = Config.RITE_QUIET_TREES.get();
        Stage before = account.stage();
        global.setFelled(player.getUUID(), account.felled - forgiven);
        SpeciesTuner.apply(WrathData.worstStage(level.getServer()));
        Stage after = global.account(player.getUUID()).stage();
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_quiet", forgiven));
        if (after != before) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + after.ordinal())
                    .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
        }
        return true;
    }

    /** Druid: everything hostile within sight is pointed out to the woods at once. */
    private static boolean thornsRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!charge(level, pos, player, 120)) {
            return false;
        }
        int marked = 0;
        for (net.minecraft.world.entity.monster.Monster monster : level.getEntitiesOfClass(
                net.minecraft.world.entity.monster.Monster.class,
                new net.minecraft.world.phys.AABB(pos).inflate(32.0))) {
            Classes.mark(level, monster);
            marked++;
        }
        if (marked == 0) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_thorns", marked));
        return true;
    }

    /** Colonialist: the weeds around the altar go up, and what is left is charcoal. */
    private static boolean ashRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!charge(level, pos, player, 90)) {
            return false;
        }
        int burned = 0;
        for (BlockPos spot : BlockPos.betweenClosed(pos.offset(-16, -6, -16), pos.offset(16, 10, 16))) {
            if (!level.isLoaded(spot)) {
                continue;
            }
            BlockState state = level.getBlockState(spot);
            if (!Kudzu.isKudzu(state) && !Invasives.isInvasive(state)) {
                continue;
            }
            level.destroyBlock(spot.immutable(), false);
            burned++;
        }
        if (burned == 0) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        net.minecraft.world.level.block.Block.popResource(level, pos.above(),
                new ItemStack(net.minecraft.world.item.Items.CHARCOAL, Math.max(1, burned / 24)));
        level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5,
                60, 4.0, 2.0, 4.0, 0.03);
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_ash", burned));
        return true;
    }

    /** Invader: every species he has a use for, laid down at once, all around him. */
    private static boolean swarmRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (!charge(level, pos, player, (int) Math.round(220 * WoodsClass.riteCostRate(player)))) {
            return false;
        }
        int placed = 0;
        for (Invasive kind : Invasive.values()) {
            placed += Invasives.seed(level, pos, kind, Config.RITE_SEEDING_SIZE.get() + 1);
            Invasives.setPlanter(level, kind, player.getUUID());
        }
        if (placed == 0) {
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_swarm", placed));
        return true;
    }

    /**
     * The Original.
     * <p>
     * Only the Mushroom can raise it, it costs most of a playthrough's tribute, and it is the only thing in
     * the mod that is simply stronger than everything else. Nobody is told how to get here.
     */
    private static boolean originalRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        if (WoodsClass.of(player) != WoodsClass.MUSHROOM) {
            fail(level, pos, player, "message.vengefulwoods.rite_refused");
            return false;
        }
        WrathData global = WrathData.global(level.getServer());
        int cost = Config.MUSHROOM_ORIGINAL_COST.get();
        if (!global.spendTribute(player.getUUID(), cost)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_tribute",
                            cost, global.account(player.getUUID()).tribute)
                    .withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        return Mushroom.raiseOriginal(level, pos, player);
    }

    private static boolean blightRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        WrathData tribute = WrathData.global(level.getServer());
        int cost = (int) Math.round(Config.TRIBUTE_KUDZU.get() * WoodsClass.riteCostRate(player));
        if (!tribute.spendTribute(player.getUUID(), cost)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_tribute",
                            cost, tribute.account(player.getUUID()).tribute)
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        if (!Kudzu.triggerNear(level, player)) {
            tribute.addTribute(player.getUUID(), cost);
            fail(level, pos, player, "message.vengefulwoods.rite_failed");
            return false;
        }
        WrathData global = WrathData.global(level.getServer());
        WrathData.Account account = global.account(player.getUUID());
        global.setFelled(player.getUUID(), account.felled + Config.RITE_BLIGHT_COST.get());
        SpeciesTuner.apply(WrathData.worstStage(level.getServer()));

        Sounds.play(level, pos, Sounds.CURSE, SoundSource.HOSTILE, 1.0F, 0.7F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_blight")
                .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), false);
        return true;
    }

    /** Anything green left on the altar is taken as what it is: a small kindness. */
    private static boolean plainOffering(ServerLevel level, BlockPos pos, ServerPlayer player, ItemStack stack) {
        boolean fertilizer = stack.is(VengefulWoods.FERTILIZER.get());
        boolean greenery = stack.is(ItemTags.SAPLINGS) || stack.is(ItemTags.LEAVES) || stack.is(ItemTags.FLOWERS)
                || stack.is(Items.BONE_MEAL) || stack.is(Items.WHEAT_SEEDS) || stack.is(Items.HAY_BLOCK);
        if (!fertilizer && !greenery) {
            return false;
        }
        reward(level, player, fertilizer ? Config.RITE_FERTILIZER_WORTH.get() : 1);
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.accepted"));
        return true;
    }

    /**
     * Anything else is weighed rather than judged. The whole stack goes, and its weight is what pays for the
     * rites that call up something invasive: a chest of goods, or a herd.
     */
    private static boolean tributeOffering(ServerLevel level, BlockPos pos, ServerPlayer player, ItemStack stack) {
        int perItem = worthOf(stack);
        if (perItem <= 0 || stack.isEmpty()) {
            return false;
        }
        int count = stack.getCount();
        WrathData global = WrathData.global(level.getServer());
        global.addTribute(player.getUUID(), count * perItem);
        if (!player.isCreative()) {
            stack.setCount(0);
        }
        level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
                12, 0.4, 0.3, 0.4, 0.0);
        Sounds.play(level, pos, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 0.8F, 0.9F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.tribute",
                        count * perItem, global.account(player.getUUID()).tribute)
                .withStyle(ChatFormatting.DARK_GREEN), true);
        return false; // The stack is already gone; do not shrink it again.
    }

    /**
     * What the altar thinks one of something is worth.
     * <p>
     * Timber counts for three times anything else, and a whole log for six. The forest is not being generous:
     * giving it back its own body is the one offering it takes seriously, which makes felling a stand and
     * handing the wood over the plain way to pay for a rite - and a bleak one, since you are buying a weed
     * with the trees you killed.
     */
    private static int worthOf(ItemStack stack) {
        if (stack.is(ItemTags.LOGS)) {
            return Config.TRIBUTE_PER_LOG.get();
        }
        if (stack.is(ItemTags.PLANKS) || stack.is(ItemTags.WOODEN_SLABS) || stack.is(ItemTags.WOODEN_STAIRS)
                || stack.is(ItemTags.WOODEN_FENCES) || stack.is(ItemTags.WOODEN_DOORS)
                || stack.is(ItemTags.WOODEN_TRAPDOORS) || stack.is(ItemTags.WOODEN_PRESSURE_PLATES)
                || stack.is(ItemTags.WOODEN_BUTTONS) || stack.is(ItemTags.SAPLINGS)) {
            return Config.TRIBUTE_PER_PLANK.get();
        }
        return Config.TRIBUTE_PER_ITEM.get();
    }

    /**
     * The Rite of Seeding. What answers depends on where you stand: still water gives you hyacinth, bare rock
     * gives knotweed, dry open ground gives cheatgrass, and anywhere green gives blackberry.
     */
    private static boolean seedingRite(ServerLevel level, BlockPos pos, ServerPlayer player) {
        Invasive kind = speciesForPlace(level, pos);
        WrathData global = WrathData.global(level.getServer());
        int cost = (int) Math.round(kind.tributeCost() * WoodsClass.riteCostRate(player));
        if (!global.spendTribute(player.getUUID(), cost)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_tribute",
                            cost, global.account(player.getUUID()).tribute)
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }

        int placed = Invasives.seed(level, pos, kind, Config.RITE_SEEDING_SIZE.get());
        Invasives.setPlanter(level, kind, player.getUUID());
        if (placed == 0) {
            global.addTribute(player.getUUID(), cost); // Nothing took; nothing is charged.
            fail(level, pos, player, "message.vengefulwoods.rite_barren");
            return false;
        }
        Block.popResource(level, pos.above(), new ItemStack(kind.block().get(), 4));
        succeed(level, pos, player, Component.translatable("message.vengefulwoods.rite_seeding",
                Component.translatable(kind.block().get().getDescriptionId())));
        return true;
    }

    /** What this place will answer with. */
    private static Invasive speciesForPlace(ServerLevel level, BlockPos pos) {
        int water = 0;
        int rock = 0;
        int green = 0;
        int dry = 0;
        int trunks = 0;
        for (BlockPos check : BlockPos.betweenClosed(pos.offset(-4, -2, -4), pos.offset(4, 2, 4))) {
            BlockState state = level.getBlockState(check);
            if (com.ferreusveritas.dynamictrees.api.TreeHelper.isBranch(state)
                    || state.is(net.minecraft.tags.BlockTags.LOGS)) {
                trunks++;
            } else if (!state.getFluidState().isEmpty()) {
                water++;
            } else if (state.is(net.minecraft.tags.BlockTags.BASE_STONE_OVERWORLD)
                    || state.is(net.minecraft.tags.BlockTags.STONE_BRICKS)) {
                rock++;
            } else if (state.is(net.minecraft.world.level.block.Blocks.GRASS_BLOCK)
                    || state.is(net.minecraft.tags.BlockTags.LEAVES)) {
                green++;
            } else if (state.is(net.minecraft.tags.BlockTags.SAND)
                    || state.is(net.minecraft.tags.BlockTags.TERRACOTTA)) {
                dry++;
            }
        }
        if (water >= 12) {
            return Invasive.WATER_HYACINTH;
        }
        if (trunks >= 10) {
            return Invasive.WISTERIA; // Standing timber to climb: it knows what to do with that.
        }
        if (dry > green && dry >= 10) {
            return Invasive.CHEATGRASS;
        }
        if (rock > green && rock >= 20) {
            return Invasive.KNOTWEED;
        }
        return Invasive.BLACKBERRY;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Killing something on it
    // ------------------------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onDeath(LivingDeathEvent event) {
        if (!Config.SACRIFICES.get() || !(event.getEntity().level() instanceof ServerLevel level)) {
            return;
        }
        LivingEntity victim = event.getEntity();
        if (victim instanceof Player) {
            return; // The forest has no use for that.
        }
        BlockPos altar = findAltar(level, victim.blockPosition());
        if (altar == null) {
            return;
        }
        ServerPlayer killer = killerOf(level, event, victim);
        if (killer == null) {
            return;
        }

        int worth;
        int tribute;
        String message;
        if (victim instanceof TamableAnimal tame && tame.isTame()) {
            // Something that trusted you. The forest understands exactly what that cost.
            worth = Config.SACRIFICE_PET.get();
            tribute = Config.TRIBUTE_PET.get();
            message = "message.vengefulwoods.sacrifice_pet";
        } else if (victim instanceof Animal) {
            worth = Config.SACRIFICE_ANIMAL.get();
            tribute = Config.TRIBUTE_ANIMAL.get();
            message = "message.vengefulwoods.sacrifice_animal";
        } else if (victim instanceof Monster) {
            worth = Config.SACRIFICE_MONSTER.get();
            tribute = Config.TRIBUTE_MONSTER.get();
            message = "message.vengefulwoods.sacrifice_monster";
        } else {
            return;
        }
        if (worth <= 0 && tribute <= 0) {
            return;
        }

        WrathData.global(level.getServer()).addTribute(killer.getUUID(), tribute);
        if (worth > 0) {
            reward(level, killer, worth);
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, altar.getX() + 0.5, altar.getY() + 1.2, altar.getZ() + 0.5,
                20, 0.5, 0.4, 0.5, 0.02);
        Sounds.play(level, altar, Sounds.HEARTBEAT, SoundSource.BLOCKS, 0.8F, 0.6F);
        killer.displayClientMessage(Component.translatable(message).withStyle(ChatFormatting.DARK_GREEN), false);
    }

    @Nullable
    private static ServerPlayer killerOf(ServerLevel level, LivingDeathEvent event, LivingEntity victim) {
        if (event.getSource().getEntity() instanceof ServerPlayer player) {
            return player;
        }
        // Died on the stone without a hand on it: whoever is standing closest answers for it.
        return ForestDirector.nearestPlayer(level.players(), victim.blockPosition(), SACRIFICE_RADIUS * 2.0, false);
    }

    @Nullable
    private static BlockPos findAltar(ServerLevel level, BlockPos around) {
        for (BlockPos pos : BlockPos.betweenClosed(
                around.offset(-SACRIFICE_RADIUS, -3, -SACRIFICE_RADIUS),
                around.offset(SACRIFICE_RADIUS, 3, SACRIFICE_RADIUS))) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            if (level.getBlockState(pos).is(VengefulWoods.ALTAR.get())) {
                return pos.immutable();
            }
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Shared bits
    // ------------------------------------------------------------------------------------------------------------

    /** The species that does best in this biome, which is what the land itself would grow given the chance. */
    @Nullable
    static Species bestSpeciesFor(ServerLevel level, BlockPos pos) {
        List<Species> best = new ArrayList<>();
        float bestScore = 0.0f;
        for (Species species : Species.REGISTRY.getAll()) {
            if (species == null || !species.isValid() || !species.hasSeed()) {
                continue;
            }
            float score;
            try {
                score = species.biomeSuitability(level, pos);
            } catch (RuntimeException e) {
                continue;
            }
            if (score > bestScore + 0.001f) {
                bestScore = score;
                best.clear();
                best.add(species);
            } else if (Math.abs(score - bestScore) <= 0.001f && !best.isEmpty()) {
                best.add(species);
            }
        }
        if (best.isEmpty()) {
            return null;
        }
        return best.get(level.random.nextInt(best.size()));
    }

    /** Credits favour to one player, and tells them if it changed how the forest feels. */
    static void reward(ServerLevel level, ServerPlayer player, int offerings) {
        MinecraftServer server = level.getServer();
        WrathData global = WrathData.global(server);
        UUID id = player.getUUID();
        Boon before = global.account(id).boon();
        double rate = WoodsClass.favourRate(player);
        int given = Math.max(1, (int) Math.round(offerings * rate));
        for (int i = 0; i < given; i++) {
            global.addOfferingFlat(id);
        }
        Boon after = global.account(id).boon();
        SpeciesTuner.apply(WrathData.worstStage(server));

        if (after != before && after != Boon.NONE) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.boon." + after.ordinal())
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.ITALIC), false);
        }
    }

    private static void succeed(ServerLevel level, BlockPos pos, ServerPlayer player, Component message) {
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.2, pos.getZ() + 0.5,
                18, 0.5, 0.4, 0.5, 0.02);
        Sounds.play(level, pos, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 0.9F, 1.2F);
        player.displayClientMessage(message.copy().withStyle(ChatFormatting.DARK_GREEN), false);
    }

    private static void fail(ServerLevel level, BlockPos pos, ServerPlayer player, String key) {
        level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 1.1, pos.getZ() + 0.5,
                8, 0.3, 0.2, 0.3, 0.0);
        player.displayClientMessage(Component.translatable(key).withStyle(ChatFormatting.GRAY), true);
    }
}
