package com.vengefulwoods;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

/**
 * One channel, one message: the key was pressed, open the tree. Everything else the mod does already
 * happens on the server, so there is nothing else to say.
 */
public class WoodsNetwork {

    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(VengefulWoods.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.registerMessage(0, OpenSkills.class, OpenSkills::encode, OpenSkills::decode, OpenSkills::handle);
    }

    /** Sent by the client when the player asks for the tree. Carries nothing. */
    public static final class OpenSkills {

        public OpenSkills() {
        }

        public static void encode(OpenSkills message, FriendlyByteBuf buffer) {
        }

        public static OpenSkills decode(FriendlyByteBuf buffer) {
            return new OpenSkills();
        }

        public static void handle(OpenSkills message, Supplier<NetworkEvent.Context> context) {
            NetworkEvent.Context ctx = context.get();
            ctx.enqueueWork(() -> {
                ServerPlayer sender = ctx.getSender();
                if (sender != null) {
                    Skills.open(sender);
                }
            });
            ctx.setPacketHandled(true);
        }
    }
}
