package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Kudzu: the thing the forest is actually afraid of.
 * <p>
 * It grows the way a tree grows, only sideways and far faster. Runners crawl along the ground, split into
 * side runners, and throw out thick mats of leaf as they go. They cannot simply rise into the air - to get
 * height they have to climb something, which is why they go up trunks and walls - and once they reach the top
 * they spread out across it and put the land underneath into permanent shade.
 * <p>
 * Where a runner meets a trunk it may strangle the tree outright. Where it meets a wall it breaks through, or
 * dives under and comes up on the other side. Trees tear at it and lose.
 */
public class Kudzu {

    /** The growing end of a kudzu runner. Lives in memory; the vines in the world are the real record. */
    private static final class Runner {
        BlockPos pos;
        Direction dir;
        int length;
        int sinceBranch;
        int climb;
        int burrow;
        int stuck;
        /** Runners are short-lived now: they race out, split, and die, and their children carry on. */
        int life;
        @Nullable
        UUID quarry;
        long quarryChecked = -1000L;

        Runner(BlockPos pos, Direction dir, int life) {
            this.pos = pos;
            this.dir = dir;
            this.life = life;
        }
    }

    private static Runner newRunner(ServerLevel level, BlockPos pos, Direction dir) {
        int life = Config.KUDZU_RUNNER_LIFE.get();
        // Vary it so a thicket does not grow in neat rings.
        return new Runner(pos, dir, life + level.random.nextInt(Math.max(1, life / 2)));
    }

    /** Per-dimension working state. */
    private static final class Patch {
        final List<Runner> runners = new ArrayList<>();
        int cursor;
        long nextSeed = -1L;
        long minuteMark;
        int mobsThisMinute;
    }

    private static final Map<ResourceKey<Level>, Patch> PATCHES = new HashMap<>();
    /** Kudzu blocks each player has cleared but not yet been thanked for. */
    private static final Map<UUID, Integer> CLEARED = new HashMap<>();

    public static void clear() {
        PATCHES.clear();
        CLEARED.clear();
    }

    private static Patch patch(ServerLevel level) {
        return PATCHES.computeIfAbsent(level.dimension(), key -> new Patch());
    }

    static boolean isVine(BlockState state) {
        return state.is(VengefulWoods.KUDZU.get());
    }

    static boolean isLeaf(BlockState state) {
        return state.is(VengefulWoods.KUDZU_LEAVES.get());
    }

    /** The part that travels underground. Dig under an infested wall and this is what you find. */
    static boolean isRoot(BlockState state) {
        return state.is(VengefulWoods.KUDZU_ROOT.get());
    }

    static boolean isKudzu(BlockState state) {
        return isVine(state) || isLeaf(state) || isRoot(state);
    }

    /** Vine above ground, root below it: the runner lays whichever suits where it is. */
    private static BlockState bodyFor(ServerLevel level, BlockPos pos, boolean burrowing) {
        boolean buried = burrowing || !isOpen(level.getBlockState(pos.above()));
        return buried ? VengefulWoods.KUDZU_ROOT.get().defaultBlockState()
                : VengefulWoods.KUDZU.get().defaultBlockState();
    }

    /**
     * Called by the chunk scan when a vine is spotted. An outbreak that was interrupted - by a restart, or by
     * everyone walking away - picks itself back up from whatever is still in the ground.
     */
    /**
     * Wakes a piece of kudzu up: a vine or root that a player placed, or one left behind when the rest was
     * cut away, starts running again on its own. Leaf does nothing - it is only ever the skin of the thing.
     */
    static void awaken(ServerLevel level, BlockPos pos, BlockState state) {
        if (!Config.KUDZU_ENABLED.get() || (!isVine(state) && !isRoot(state))) {
            return;
        }
        Patch patch = patch(level);
        if (patch.runners.size() >= Config.KUDZU_MAX_RUNNERS.get()) {
            return;
        }
        Runner runner = newRunner(level, pos.immutable(), Direction.from2DDataValue(level.random.nextInt(4)));
        if (isRoot(state)) {
            runner.burrow = Config.KUDZU_BURROW_LENGTH.get();
        }
        patch.runners.add(runner);
    }

    static void noteFront(ServerLevel level, BlockPos pos, BlockState state) {
        if (!isVine(state) && !isRoot(state)) {
            return; // A leaf mat found lying about does not start anything; the vine under it does.
        }
        Patch patch = patch(level);
        if (patch.runners.size() >= Config.KUDZU_MAX_RUNNERS.get() || level.random.nextInt(24) != 0) {
            return;
        }
        patch.runners.add(newRunner(level, pos.immutable(), Direction.from2DDataValue(level.random.nextInt(4))));
    }

    /**
     * Somebody put a piece of it in the ground on purpose.
     * <p>
     * Any piece. Vine, root, even a handful of leaf: a cutting is a cutting, and this is a plant that grows
     * from a scrap of itself left in a compost heap. Unlike the slow waking of a patch found lying about,
     * this always takes.
     */
    static void plant(ServerLevel level, BlockPos pos, BlockState state) {
        if (!isKudzu(state) || !Config.KUDZU_ENABLED.get()) {
            return;
        }
        Patch patch = patch(level);
        if (patch.runners.size() >= Config.KUDZU_MAX_RUNNERS.get()) {
            return;
        }
        Runner runner = newRunner(level, pos.immutable(), Direction.from2DDataValue(level.random.nextInt(4)));
        if (isRoot(state)) {
            runner.burrow = Config.KUDZU_BURROW_LENGTH.get();
        }
        patch.runners.add(runner);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Every tick
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, List<ServerPlayer> players, long now) {
        if (!Config.KUDZU_ENABLED.get()) {
            return;
        }
        Patch patch = patch(level);

        if (!patch.runners.isEmpty()) {
            int budget = Math.max(1, Config.KUDZU_SPREAD.get() / 20);
            for (int i = 0; i < budget && !patch.runners.isEmpty(); i++) {
                step(level, patch);
            }
        }
        if (players.isEmpty()) {
            return;
        }
        if (now % 60L == 0L) {
            reviveStep(level, patch, players);
        }
        if (now % 10L == 0L) {
            entangleStep(level, players);
        }
        if (now % 20L == 0L) {
            crushStep(level, patch);
            fightBackStep(level, patch);
            feedStep(level, patch);
        }
        if (now % 100L == 0L && Config.KUDZU_MOBS.get()) {
            spawnStep(level, patch, players, now);
        }
        if (Config.KUDZU_SEEDS_ITSELF.get()) {
            seedStep(level, patch, players, now);
        }
    }

    /**
     * Kudzu does not give up.
     * <p>
     * Runners are short-lived on purpose - they race out, fork and die - but if the last of them expires while
     * nobody is looking, the patch would simply sit there being scenery. Every three seconds, any stand with
     * no growing tip left gets one started again from a block of itself near a player. Short of taking every
     * last block out of the ground, it will always be coming back.
     */
    private static void reviveStep(ServerLevel level, Patch patch, List<ServerPlayer> players) {
        if (!patch.runners.isEmpty() || patch.runners.size() >= Config.KUDZU_MAX_RUNNERS.get()) {
            return;
        }
        RandomSource random = level.random;
        ServerPlayer player = players.get(random.nextInt(players.size()));
        BlockPos centre = player.blockPosition();
        int range = Math.max(16, Config.KUDZU_HUNT_RANGE.get());

        // Look for any vine or root still in the ground, and set it going again.
        for (int attempt = 0; attempt < 220; attempt++) {
            BlockPos pos = centre.offset(random.nextInt(range * 2) - range,
                    random.nextInt(24) - 12, random.nextInt(range * 2) - range);
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (!isVine(state) && !isRoot(state)) {
                continue;
            }
            patch.runners.add(newRunner(level, pos.immutable(),
                    Direction.from2DDataValue(random.nextInt(4))));
            return;
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // How a runner moves
    // ------------------------------------------------------------------------------------------------------------

    private static boolean isOpen(BlockState state) {
        return state.isAir() || state.canBeReplaced() || isLeaf(state) || state.is(BlockTags.LEAVES);
    }

    /** Something a vine can get a grip on and haul itself up. */
    private static boolean isClimbable(ServerLevel level, BlockPos pos, BlockState state) {
        if (state.isAir() || isOpen(state)) {
            return false;
        }
        return canTake(level, pos, state) || TreeHelper.isTreePart(state) || isVine(state);
    }

    private static void step(ServerLevel level, Patch patch) {
        if (patch.cursor >= patch.runners.size()) {
            patch.cursor = 0;
        }
        Runner runner = patch.runners.get(patch.cursor);

        BlockState here = level.getBlockState(runner.pos);
        if (!level.isLoaded(runner.pos) || (!isVine(here) && !isRoot(here))) {
            patch.runners.remove(patch.cursor);
            return;
        }
        if (runner.life-- <= 0) {
            patch.runners.remove(patch.cursor);
            return;
        }
        if (!advance(level, patch, runner)) {
            runner.stuck++;
            if (runner.stuck > 6) {
                patch.runners.remove(patch.cursor);
                return;
            }
            // Boxed in this way; try somewhere else next time.
            runner.dir = level.random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
        } else {
            runner.stuck = 0;
        }
        patch.cursor++;
    }

    private static boolean advance(ServerLevel level, Patch patch, Runner runner) {
        RandomSource random = level.random;
        BlockPos pos = runner.pos;

        ServerPlayer quarry = hunt(level, runner);
        if (quarry != null) {
            BlockPos target = quarry.blockPosition();
            int flat = Math.abs(target.getX() - pos.getX()) + Math.abs(target.getZ() - pos.getZ());
            int dy = target.getY() - pos.getY();
            if (flat <= 3 && Math.abs(dy) <= 3) {
                // Close enough. It grows into the space they are standing in.
                bury(level, quarry, random);
                return true;
            }
            // Head for them, over the ground or under it - and put on a turn of speed while doing it.
            // A runner that has found somebody does not amble.
            Direction towards = horizontalToward(pos, target);
            if (towards != null && (flat > 1 || runner.burrow > 0)) {
                runner.dir = towards;
            }
            int extra = Config.KUDZU_HUNT_SPEED.get() - 1;
            for (int rush = 0; rush < extra; rush++) {
                BlockPos next = runner.pos.relative(runner.dir);
                if (!level.isLoaded(next) || !place(level, next, random, runner.burrow > 0)) {
                    break;
                }
                runner.pos = next;
                runner.length++;
            }
            if (runner.burrow <= 0 && dy < -2 && random.nextFloat() < 0.4F) {
                runner.burrow = Config.KUDZU_BURROW_LENGTH.get(); // Go under and come up beneath them.
            }
        } else if (runner.burrow <= 0 && random.nextFloat() < Config.KUDZU_DIVE_CHANCE.get()) {
            // Even without a quarry, a good part of the plant lives below the surface.
            BlockPos below = pos.below();
            if (canTake(level, below, level.getBlockState(below)) && place(level, below, random, true)) {
                runner.pos = below;
                runner.burrow = Config.KUDZU_BURROW_LENGTH.get();
                runner.climb = 0;
                return true;
            }
        }

        // Coming back up after going under something.
        if (runner.burrow > 0) {
            runner.burrow--;
            if (runner.burrow == 0 && random.nextFloat() < 0.6F) {
                // Most runs that go under stay under. That is where the plant really lives.
                runner.burrow = Config.KUDZU_BURROW_LENGTH.get();
            }
            BlockPos ahead = pos.relative(runner.dir);
            if (place(level, ahead, random, true)) {
                runner.pos = ahead;
                runner.length++;
                runner.sinceBranch++;
                rootBranch(level, patch, runner, random);
                return true;
            }
            // Blocked below ground: push up for air, or sideways and keep tunnelling.
            BlockPos up = pos.above();
            if (place(level, up, random)) {
                runner.pos = up;
                runner.burrow = 0;
                leafMat(level, up, random, false);
                return true;
            }
            Direction side = random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
            BlockPos aside = pos.relative(side);
            if (place(level, aside, random, true)) {
                runner.pos = aside;
                runner.dir = side;
                return true;
            }
            return false;
        }

        BlockPos ahead = pos.relative(runner.dir);
        if (!level.isLoaded(ahead)) {
            return false;
        }
        BlockState aheadState = level.getBlockState(ahead);

        if (isOpen(aheadState)) {
            // Open in front. A vine lies on things; it does not hang in mid-air. What happens next depends
            // entirely on whether there is anything under the next block.
            if (!isOpen(level.getBlockState(ahead.below()))) {
                // Ground ahead. Follow the lie of it: step up a block if the ground rises, so the runner
                // tracks the contour instead of cutting through the hillside.
                BlockPos step = ahead;
                if (!isOpen(level.getBlockState(ahead)) && isOpen(level.getBlockState(ahead.above()))) {
                    step = ahead.above();
                }
                return move(level, patch, runner, step, random);
            }

            // Nothing underneath. Look for ground a little lower: the runner drapes down a bank rather than
            // flying off the edge of it.
            for (int drop = 1; drop <= 3; drop++) {
                BlockPos lower = ahead.below(drop);
                if (!level.isLoaded(lower)) {
                    break;
                }
                if (!isOpen(level.getBlockState(lower))) {
                    return move(level, patch, runner, ahead.below(drop - 1), random);
                }
            }

            // A real gap. It may be bridged only if there is something to reach - a trunk, a wall, a branch -
            // within a few blocks, which is how kudzu actually crosses from tree to tree. Anything wider and
            // the runner gives up on the crossing and heads for the ground instead.
            if (canBridge(level, ahead, runner.dir) || runner.climb > 0) {
                return move(level, patch, runner, ahead, random);
            }
            BlockPos under = pos.below();
            if (place(level, under, random, true)) {
                runner.pos = under;      // Down the trunk and onto the floor.
                runner.climb = 0;
                return true;
            }
            return false;
        }

        // Something solid in front.
        if (TreeHelper.isBranch(aheadState) && random.nextFloat() < Config.KUDZU_STRANGLE_CHANCE.get()) {
            strangle(level, ahead);
            return move(level, patch, runner, ahead, random);
        }

        BlockPos up = pos.above();
        if (isClimbable(level, ahead, aheadState) && isOpen(level.getBlockState(up))) {
            runner.climb++;
            return move(level, patch, runner, up, random); // Up the trunk, up the wall.
        }

        if (Rhizomes.isBuiltBlock(aheadState) && canTake(level, ahead, aheadState)) {
            if (Config.KUDZU_BREAKS_BUILDS.get()) {
                level.destroyBlock(ahead, true);
                return move(level, patch, runner, ahead, random);
            }
            // Cannot break it, so go under it instead and come up inside.
            BlockPos below = pos.below();
            if (canTake(level, below, level.getBlockState(below)) && place(level, below, random, true)) {
                runner.pos = below;
                runner.burrow = 4;
                return true;
            }
        }
        return false;
    }

    /**
     * Whether a gap in front is narrow enough to be worth reaching across.
     * <p>
     * Kudzu really does bridge from one tree to the next, and that is the thing that makes a kudzu wood feel
     * sewn shut. What it does not do is march out over a lake. So a runner looks a short way ahead for
     * anything solid to land on, at its own level or one either side of it, and crosses only if it finds
     * something.
     */
    private static boolean canBridge(ServerLevel level, BlockPos from, Direction dir) {
        int reach = Config.KUDZU_GAP.get();
        for (int step = 1; step <= reach; step++) {
            BlockPos probe = from.relative(dir, step);
            if (!level.isLoaded(probe)) {
                return false;
            }
            for (int dy = -1; dy <= 1; dy++) {
                BlockState state = level.getBlockState(probe.above(dy));
                if (!isOpen(state) && !isKudzu(state)) {
                    return true; // Something to get hold of.
                }
            }
        }
        return false;
    }

    /** The player this runner is working its way toward, if any. */
    @Nullable
    private static ServerPlayer hunt(ServerLevel level, Runner runner) {
        if (!Config.KUDZU_HUNTS_PLAYERS.get()) {
            return null;
        }
        long now = level.getGameTime();
        if (now - runner.quarryChecked < 40L && runner.quarry != null) {
            ServerPlayer known = level.getServer().getPlayerList().getPlayer(runner.quarry);
            if (known != null && known.isAlive() && !known.isCreative() && !known.isSpectator()
                    && known.blockPosition().distSqr(runner.pos) < 4096.0) {
                return known;
            }
        }
        runner.quarryChecked = now;
        runner.quarry = null;

        double range = Config.KUDZU_HUNT_RANGE.get();
        ServerPlayer best = ForestDirector.nearestPlayer(level.players(), runner.pos, range, true);
        if (best != null && Skills.has(best, Skill.QUIET_STEP)
                && best.blockPosition().distSqr(runner.pos) > (range * 0.5) * (range * 0.5)) {
            return null; // It has not noticed this one yet.
        }
        if (best != null) {
            runner.quarry = best.getUUID();
        }
        return best;
    }

    /**
     * Grows into the space a player is standing in - one layer at a time, from the feet up. The green comes
     * up around you over several seconds rather than swallowing you whole, which is the only reason it is
     * survivable.
     */
    private static void bury(ServerLevel level, ServerPlayer player, RandomSource random) {
        if (!Config.KUDZU_BURIES_PLAYERS.get() || player.isCreative() || player.isSpectator()) {
            return;
        }
        BlockPos feet = player.blockPosition();
        BlockState leaves = VengefulWoods.KUDZU_LEAVES.get().defaultBlockState();

        // Fill the lowest layer that still has a gap in it. Only when the ground around their boots is solid
        // green does it start on the next one up.
        for (int layer = 0; layer <= 2; layer++) {
            boolean placed = false;
            boolean gap = false;
            for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-1, layer, -1), feet.offset(1, layer, 1))) {
                if (!level.isLoaded(pos)) {
                    continue;
                }
                BlockState state = level.getBlockState(pos);
                if (isKudzu(state)) {
                    continue;
                }
                if (state.isAir() || state.canBeReplaced()) {
                    gap = true;
                    if (!placed || random.nextInt(3) == 0) {
                        level.setBlock(pos.immutable(), leaves, 3);
                        placed = true;
                    }
                }
            }
            if (placed) {
                level.sendParticles(ParticleTypes.COMPOSTER, feet.getX() + 0.5, feet.getY() + layer + 0.5, feet.getZ() + 0.5,
                        12, 0.6, 0.4, 0.6, 0.02);
                Sounds.play(level, feet, Sounds.GRASS_PLACE, SoundSource.HOSTILE, 0.9F, 0.5F);
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 4, true, false, false));
                return;
            }
            if (gap) {
                return; // Something is in the way on this layer; try again next time round.
            }
        }
    }

    /** Underground runs fork too, which is how the root network gets under a whole base. */
    private static void rootBranch(ServerLevel level, Patch patch, Runner runner, RandomSource random) {
        if (runner.sinceBranch < Config.KUDZU_BRANCH_EVERY.get()
                || patch.runners.size() >= Config.KUDZU_MAX_RUNNERS.get()) {
            return;
        }
        runner.sinceBranch = 0;
        Direction side = random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
        Runner child = newRunner(level, runner.pos, side);
        child.burrow = Config.KUDZU_BURROW_LENGTH.get();
        patch.runners.add(child);
    }

    @Nullable
    private static Direction horizontalToward(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dz = to.getZ() - from.getZ();
        if (dx == 0 && dz == 0) {
            return null;
        }
        if (Math.abs(dx) >= Math.abs(dz)) {
            return dx > 0 ? Direction.EAST : Direction.WEST;
        }
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    /** Moves the runner on, lays vine, hangs leaves, and sometimes throws off a side runner. */
    private static boolean move(ServerLevel level, Patch patch, Runner runner, BlockPos to, RandomSource random) {
        if (to.getY() <= level.getMinBuildHeight() + 1 || to.getY() >= level.getMaxBuildHeight() - 1) {
            return false;
        }
        if (!place(level, to, random)) {
            return false;
        }
        if (to.getY() <= runner.pos.getY()) {
            runner.climb = 0;
        }
        runner.pos = to;
        runner.length++;
        runner.sinceBranch++;

        leafMat(level, to, random, runner.climb > 0);

        int branchEvery = Config.KUDZU_BRANCH_EVERY.get();
        if (runner.sinceBranch >= branchEvery && patch.runners.size() < Config.KUDZU_MAX_RUNNERS.get()) {
            runner.sinceBranch = 0;
            Direction side = random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
            Runner child = newRunner(level, to, side);
            if (random.nextFloat() < 0.45F) {
                child.burrow = Config.KUDZU_BURROW_LENGTH.get(); // Nearly half of all new growth goes under.
            }
            patch.runners.add(child);
        }
        // Runners wander rather than ruling straight lines - unless they are following somebody.
        if (runner.quarry == null && random.nextInt(6) == 0) {
            runner.dir = random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
        }
        return true;
    }

    /** Lays vine into a block, taking whatever was there if it is allowed to. */
    private static boolean place(ServerLevel level, BlockPos pos, RandomSource random) {
        return place(level, pos, random, false);
    }

    private static boolean place(ServerLevel level, BlockPos pos, RandomSource random, boolean burrowing) {
        if (!level.isLoaded(pos)) {
            return false;
        }
        BlockState state = level.getBlockState(pos);
        if (isVine(state) || isRoot(state)) {
            return true;
        }
        if (!isOpen(state) && !isLeaf(state)) {
            if (!canTake(level, pos, state)) {
                return false;
            }
            if (isCrop(state)) {
                level.destroyBlock(pos, true); // The harvest is lost, but it drops.
            } else if (TreeHelper.isBranch(state)) {
                strangle(level, pos);
            } else if (Rhizomes.isBuiltBlock(state)) {
                if (!Config.KUDZU_BREAKS_BUILDS.get()) {
                    return false;
                }
                level.destroyBlock(pos, true);
            }
        }
        level.setBlock(pos, bodyFor(level, pos, burrowing), 3);
        return true;
    }

    /** Thick leaf growth hanging off the vine. Heavier up in the canopy, which is what makes the shade. */
    private static void leafMat(ServerLevel level, BlockPos vine, RandomSource random, boolean climbing) {
        int density = Config.KUDZU_LEAF_DENSITY.get();
        if (density <= 0) {
            return;
        }
        int count = climbing ? density + 2 : density;
        BlockState leaves = VengefulWoods.KUDZU_LEAVES.get().defaultBlockState();

        // A cap of leaf straight over the vine, which is what puts the ground into the dark.
        BlockPos over = vine.above();
        if (level.isLoaded(over)) {
            BlockState overState = level.getBlockState(over);
            if (overState.isAir() || overState.canBeReplaced()) {
                level.setBlock(over, leaves, 3);
            }
        }

        // Leaves go on in a fixed order rather than at random, so every length of vine ends up dressed
        // the same way instead of some stretches being bare and others a solid wall of green.
        int laid = 0;
        for (BlockPos spot : LEAF_PATTERN) {
            if (laid >= count) {
                break;
            }
            BlockPos pos = vine.offset(spot.getX(), spot.getY(), spot.getZ());
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (isKudzu(state)) {
                continue;
            }
            if (state.isAir() || state.canBeReplaced() || state.is(BlockTags.LEAVES)) {
                level.setBlock(pos, leaves, 3);
                laid++;
            }
        }
    }

    /**
     * Where leaves hang off a vine, nearest first. Walking this in order gives an even mat: the four sides,
     * then the corners, then the layer below, then the reach-out blocks.
     */
    private static final BlockPos[] LEAF_PATTERN = {
            new BlockPos(1, 0, 0), new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1),
            new BlockPos(1, 0, 1), new BlockPos(-1, 0, -1), new BlockPos(1, 0, -1), new BlockPos(-1, 0, 1),
            new BlockPos(0, -1, 0), new BlockPos(1, -1, 0), new BlockPos(-1, -1, 0),
            new BlockPos(0, -1, 1), new BlockPos(0, -1, -1),
            new BlockPos(2, 0, 0), new BlockPos(-2, 0, 0), new BlockPos(0, 0, 2), new BlockPos(0, 0, -2),
            new BlockPos(1, 1, 0), new BlockPos(-1, 1, 0), new BlockPos(0, 1, 1), new BlockPos(0, 1, -1),
    };

    /** Kudzu may not touch these, whatever it does to everything else. */
    private static boolean canTake(ServerLevel level, BlockPos pos, BlockState state) {
        if (state.is(VengefulWoods.RHIZOME_IMMUNE) || state.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        if (!state.getFluidState().isEmpty()) {
            return false; // It does not swim.
        }
        if (state.hasBlockEntity() && !Config.BREAK_CONTAINERS.get()) {
            return false;
        }
        return !TreeHelper.isRooty(state);
    }

    private static boolean isCrop(BlockState state) {
        return state.is(BlockTags.CROPS) || state.is(Blocks.FARMLAND) || state.is(Blocks.PUMPKIN_STEM)
                || state.is(Blocks.MELON_STEM) || state.is(Blocks.SUGAR_CANE);
    }

    /**
     * A vine reaching a trunk pulls the tree down. Dynamic Trees handles the collapse, and because nobody
     * swung an axe it counts against no player.
     */
    private static void strangle(ServerLevel level, BlockPos pos) {
        level.destroyBlock(pos, false);
        Sounds.play(level, pos, Sounds.ROOTS_BREAK, SoundSource.BLOCKS, 0.8F, 0.6F);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Crushing what it grows over
    // ------------------------------------------------------------------------------------------------------------

    private static void crushStep(ServerLevel level, Patch patch) {
        if (!Config.KUDZU_BREAKS_BUILDS.get()) {
            return;
        }
        BlockPos front = peekRandom(level, patch);
        if (front == null) {
            return;
        }
        int depth = 0;
        while (depth < 3 && isKudzu(level.getBlockState(front.above(depth)))) {
            depth++;
        }
        if (depth < 3) {
            return;
        }
        BlockPos below = front.below();
        if (!level.isLoaded(below)) {
            return;
        }
        BlockState state = level.getBlockState(below);
        if (state.isAir() || isKudzu(state) || !Rhizomes.isBuiltBlock(state) || !canTake(level, below, state)) {
            return;
        }
        level.destroyBlock(below, true);
        level.setBlock(below, bodyFor(level, below, false), 3);
        Sounds.play(level, below, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 0.9F, 0.7F);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Players caught in it
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Being in it.
     * <p>
     * This no longer waits for a growing tip to path exactly onto your feet, which almost never happened and
     * was why being swallowed by kudzu used to work so badly. Standing in the stuff is enough: it closes over
     * you where you are, pulls you down into itself when there is anywhere below to pull you, and the longer
     * it has hold the worse it goes.
     */
    private static void entangleStep(ServerLevel level, List<ServerPlayer> players) {
        BlockState leaves = VengefulWoods.KUDZU_LEAVES.get().defaultBlockState();
        for (ServerPlayer player : players) {
            if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
                GRIP.remove(player.getUUID());
                continue;
            }
            BlockPos feet = player.blockPosition();
            if (!level.isLoaded(feet)) {
                continue;
            }

            // How much of it is actually on you, rather than merely nearby.
            int around = 0;
            for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-1, 0, -1), feet.offset(1, 1, 1))) {
                if (isKudzu(level.getBlockState(pos))) {
                    around++;
                }
            }
            if (around < 3) {
                GRIP.remove(player.getUUID());
                continue;
            }

            int held = GRIP.merge(player.getUUID(), 1, Integer::sum);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3, true, false, false));
            player.setDeltaMovement(player.getDeltaMovement().multiply(0.2, 1.0, 0.2));
            player.hurtMarked = true;

            // It grows over you where you stand, whether or not anything was heading for you.
            if (Config.KUDZU_BURIES_PLAYERS.get()) {
                bury(level, player, level.random);
            }

            // And it takes you down into itself. This is the part that is meant to be frightening: the
            // ground you are standing on opens and the green follows you into the hole.
            if (held >= 3 && Config.KUDZU_DRAGS_DOWN.get()) {
                BlockPos below = feet.below();
                BlockState under = level.getBlockState(below);
                boolean canSink = (under.isAir() || under.canBeReplaced() || isKudzu(under)
                        || canTake(level, below, under)) && below.getY() > level.getMinBuildHeight() + 2;
                if (canSink && level.random.nextInt(2) == 0) {
                    if (!under.isAir() && !under.canBeReplaced()) {
                        level.destroyBlock(below, false);
                    }
                    player.teleportTo(level, player.getX(), below.getY(), player.getZ(),
                            player.getYRot(), player.getXRot());
                    // The hole closes behind you.
                    BlockPos lid = feet.above();
                    if (level.isLoaded(lid) && isOpen(level.getBlockState(lid))) {
                        level.setBlock(lid, leaves, 3);
                    }
                    if (isOpen(level.getBlockState(feet))) {
                        level.setBlock(feet, leaves, 3);
                    }
                    Sounds.play(level, feet, Sounds.GRASS_PLACE, SoundSource.HOSTILE, 1.0F, 0.4F);
                    level.sendParticles(ParticleTypes.COMPOSTER, player.getX(), player.getY() + 0.5, player.getZ(),
                            24, 0.5, 0.6, 0.5, 0.04);
                }
            }

            // Spores. It is not clean down there.
            if (held >= 2) {
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120, 0, true, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0, true, false, false));
                if (held >= 5) {
                    player.addEffect(new MobEffectInstance(MobEffects.POISON, 60, 0, true, false, false));
                    player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 120, 0, true, false, false));
                }
            }

            // Buried to the head: the green closes over and it starts to take you. It gets worse the
            // longer it has you, so digging out early matters.
            if (isKudzu(level.getBlockState(feet)) && isKudzu(level.getBlockState(feet.above()))) {
                float damage = (float) (double) Config.KUDZU_BURY_DAMAGE.get() * 0.5F; // this runs twice a second
                damage *= 1.0F + Math.min(held, 20) * 0.12F;
                DamageSource source = Rhizomes.tendrilDamage(level);
                if (damage > 0.0F && source != null) {
                    player.hurt(source, damage);
                }
            }
        }
    }

    /** Seconds each player has been held, which is what makes a long burial worse than a short one. */
    private static final Map<UUID, Integer> GRIP = new HashMap<>();

    /**
     * What it does to everything else.
     * <p>
     * Kudzu does not care that a zombie is not a tree. Anything caught in it is torn at, and anything that
     * dies in it is simply absorbed - the weed banks the kill as biomass and thickens over the spot.
     */
    private static void feedStep(ServerLevel level, Patch patch) {
        if (!Config.KUDZU_EATS_MOBS.get() || patch.runners.isEmpty()) {
            return;
        }
        RandomSource random = level.random;
        for (int attempt = 0; attempt < 3; attempt++) {
            Runner runner = patch.runners.get(random.nextInt(patch.runners.size()));
            if (!level.isLoaded(runner.pos)) {
                continue;
            }
            List<LivingEntity> caught = level.getEntitiesOfClass(LivingEntity.class,
                    new AABB(runner.pos).inflate(3.0));
            for (LivingEntity living : caught) {
                if (living instanceof Player || !living.isAlive()) {
                    continue;
                }
                BlockPos at = living.blockPosition();
                if (!isKudzu(level.getBlockState(at)) && !isKudzu(level.getBlockState(at.below()))) {
                    continue;
                }
                DamageSource source = Rhizomes.tendrilDamage(level);
                float damage = (float) (double) Config.KUDZU_MOB_DAMAGE.get()
                        * Invader.damageAgainstOthers(level);
                if (source != null && damage > 0.0F) {
                    living.hurt(source, damage);
                }
                living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2, true, false, false));
                if (!living.isAlive()) {
                    // Eaten. The weed is that much bigger for it.
                    Biomass.growWeeds(level, Config.KUDZU_MOB_BIOMASS.get(), 1.0F);
                    leafMat(level, at, random, false);
                    level.sendParticles(ParticleTypes.COMPOSTER, living.getX(), living.getY() + 0.5,
                            living.getZ(), 30, 0.5, 0.5, 0.5, 0.06);
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // What breeds in the dark
    // ------------------------------------------------------------------------------------------------------------

    private static void spawnStep(ServerLevel level, Patch patch, List<ServerPlayer> players, long now) {
        if (!level.getGameRules().getBoolean(GameRules.RULE_DOMOBSPAWNING)) {
            return;
        }
        if (now - patch.minuteMark > 1200L) {
            patch.minuteMark = now;
            patch.mobsThisMinute = 0;
        }
        if (patch.mobsThisMinute >= Config.KUDZU_MOBS_PER_MINUTE.get()) {
            return;
        }

        BlockPos front = peekRandom(level, patch);
        if (front == null) {
            return;
        }
        BlockPos spawnPos = front.below();
        if (!level.isLoaded(spawnPos) || !level.getBlockState(spawnPos).isAir()
                || !level.getBlockState(spawnPos.below()).isAir()) {
            return;
        }
        if (level.getBlockState(spawnPos.below(2)).isAir()
                || level.getBrightness(LightLayer.BLOCK, spawnPos) > 7) {
            return;
        }
        ServerPlayer nearest = ForestDirector.nearestPlayer(players, spawnPos, 64.0, false);
        if (nearest == null || nearest.blockPosition().distSqr(spawnPos) < 100.0) {
            return;
        }

        EntityType<?> type = pickMob(level.random);
        if (type == null) {
            return;
        }
        Entity entity = type.create(level);
        if (entity == null) {
            return;
        }
        entity.moveTo(spawnPos.getX() + 0.5, spawnPos.getY() - 1.0, spawnPos.getZ() + 0.5,
                level.random.nextFloat() * 360.0F, 0.0F);
        if (level.addFreshEntity(entity)) {
            patch.mobsThisMinute++;
        }
    }

    @Nullable
    private static EntityType<?> pickMob(RandomSource random) {
        String[] mobs = {"zombie", "spider", "skeleton", "creeper"};
        try {
            return ForgeRegistries.ENTITY_TYPES.getValue(
                    new ResourceLocation("minecraft", mobs[random.nextInt(mobs.length)]));
        } catch (RuntimeException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // The trees' losing war
    // ------------------------------------------------------------------------------------------------------------

    private static void fightBackStep(ServerLevel level, Patch patch) {
        for (int i = 0; i < 2; i++) {
            BlockPos front = peekRandom(level, patch);
            if (front == null) {
                return;
            }
            if (level.random.nextFloat() > Config.KUDZU_TREE_RESISTANCE.get()) {
                continue;
            }
            boolean touchingWood = false;
            for (Direction dir : Direction.values()) {
                BlockState neighbour = level.getBlockState(front.relative(dir));
                if (TreeHelper.isBranch(neighbour) || TreeHelper.isRooty(neighbour)
                        || neighbour.is(VengefulWoods.RHIZOME.get())) {
                    touchingWood = true;
                    break;
                }
            }
            if (touchingWood && isKudzu(level.getBlockState(front))) {
                level.removeBlock(front, false);
                level.sendParticles(ParticleTypes.COMPOSTER, front.getX() + 0.5, front.getY() + 0.5, front.getZ() + 0.5,
                        4, 0.3, 0.3, 0.3, 0.0);
            }
        }
    }

    /** A rhizome shoving its way through kudzu clears it. */
    static boolean clearForRhizome(ServerLevel level, BlockPos pos) {
        if (!isKudzu(level.getBlockState(pos))) {
            return false;
        }
        level.removeBlock(pos, false);
        return true;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Where it starts
    // ------------------------------------------------------------------------------------------------------------

    private static void seedStep(ServerLevel level, Patch patch, List<ServerPlayer> players, long now) {
        if (patch.nextSeed < 0L) {
            patch.nextSeed = now + Config.KUDZU_SEED_MINUTES.get() * 1200L;
            return;
        }
        if (now < patch.nextSeed) {
            return;
        }
        patch.nextSeed = now + Config.KUDZU_SEED_MINUTES.get() * 1200L;
        if (!patch.runners.isEmpty()) {
            return; // There is already an outbreak here.
        }

        // It goes where the damage is: only players who have been cutting the forest down draw it in.
        int trigger = Config.KUDZU_TRIGGER_TREES.get();
        List<ServerPlayer> candidates = new ArrayList<>();
        WrathData global = WrathData.global(level.getServer());
        for (ServerPlayer player : players) {
            if (trigger <= 0 || global.account(player.getUUID()).felled >= trigger) {
                candidates.add(player);
            }
        }
        if (candidates.isEmpty()) {
            return;
        }
        triggerNear(level, candidates.get(level.random.nextInt(candidates.size())));
    }

    /**
     * Starts an outbreak in the ring around a player - near enough to find them before long, far enough that
     * the first they know of it is a green line on the horizon.
     */
    static boolean triggerNear(ServerLevel level, ServerPlayer player) {
        if (!Config.KUDZU_ENABLED.get()) {
            return false;
        }
        Patch patch = patch(level);
        if (!patch.runners.isEmpty()) {
            return false; // Already growing somewhere; one outbreak at a time is plenty.
        }
        RandomSource random = level.random;
        int min = Config.KUDZU_MIN_DISTANCE.get();
        int max = Math.max(min, Config.KUDZU_MAX_DISTANCE.get());

        for (int attempt = 0; attempt < 16; attempt++) {
            double angle = random.nextDouble() * Math.PI * 2.0;
            double distance = min + random.nextDouble() * (max - min);
            int dx = (int) Math.round(Math.cos(angle) * distance);
            int dz = (int) Math.round(Math.sin(angle) * distance);
            BlockPos spot = findGround(level, player.blockPosition().offset(dx, 0, dz));
            if (spot != null) {
                seed(level, spot, 2);
                VengefulWoods.LOGGER.info("Vengeful Woods: kudzu has taken hold at {}, {} blocks from {}",
                        spot, (int) distance, player.getName().getString());
                return true;
            }
        }
        return false;
    }

    @Nullable
    private static BlockPos findGround(ServerLevel level, BlockPos around) {
        for (int dy = 16; dy >= -16; dy--) {
            BlockPos pos = around.above(dy);
            if (!level.isLoaded(pos)) {
                return null;
            }
            BlockState state = level.getBlockState(pos);
            BlockState below = level.getBlockState(pos.below());
            if ((state.isAir() || state.canBeReplaced()) && !below.isAir() && below.getFluidState().isEmpty()
                    && !Rhizomes.isBuiltBlock(below)) {
                return pos;
            }
        }
        return null;
    }

    static void seed(ServerLevel level, BlockPos center) {
        seed(level, center, 2);
    }

    /** Starts an outbreak: a knot of vine with runners heading out of it in every direction. */
    static void seed(ServerLevel level, BlockPos center, int radius) {
        Patch patch = patch(level);
        RandomSource random = level.random;
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-radius, 0, -radius), center.offset(radius, 0, radius))) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if ((state.isAir() || state.canBeReplaced()) && state.getFluidState().isEmpty()) {
                level.setBlock(pos.immutable(), bodyFor(level, pos.immutable(), false), 3);
                leafMat(level, pos.immutable(), random, false);
            }
        }
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            if (patch.runners.size() < Config.KUDZU_MAX_RUNNERS.get()) {
                patch.runners.add(newRunner(level, center, dir));
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Cutting it back earns the trees' thanks
    // ------------------------------------------------------------------------------------------------------------

    /** A vine or root a player puts down is not decoration. It starts running immediately. */
    @SubscribeEvent
    public void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        plant(level, event.getPos(), event.getPlacedBlock());
    }

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.level().isClientSide() || !isKudzu(event.getState()) || player.isCreative()) {
            return;
        }
        creditClearing(player, 1);
    }

    /**
     * Credits work done against the weed, whether it was done a block at a time by hand or an armful at a
     * time with the right tool. A tool that clears faster earns favour faster; that is the point of it.
     */
    static void creditClearing(Player player, int blocks) {
        if (blocks <= 0 || player.isCreative()) {
            return;
        }
        int needed = Config.KUDZU_PER_OFFERING.get();
        if (needed <= 0) {
            return;
        }
        UUID id = player.getUUID();
        int cleared = CLEARED.merge(id, blocks, Integer::sum);
        if (cleared < needed) {
            return;
        }
        CLEARED.put(id, cleared % needed);

        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        WrathData global = WrathData.global(server);
        Boon before = global.account(id).boon();
        global.addOffering(id);
        Boon after = global.account(id).boon();

        player.displayClientMessage(Component.translatable("message.vengefulwoods.kudzu_thanks")
                .withStyle(ChatFormatting.DARK_GREEN), true);
        if (after != before && after != Boon.NONE) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.boon." + after.ordinal())
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.ITALIC), false);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------------------------

    /** The position of a living runner, taken at random. */
    @Nullable
    private static BlockPos peekRandom(ServerLevel level, Patch patch) {
        if (patch.runners.isEmpty()) {
            return null;
        }
        Runner runner = patch.runners.get(level.random.nextInt(patch.runners.size()));
        return level.isLoaded(runner.pos) ? runner.pos : null;
    }

    /** How many runners this dimension currently has out. */
    static int frontCount(ServerLevel level) {
        Patch patch = PATCHES.get(level.dimension());
        return patch == null ? 0 : patch.runners.size();
    }

    static void wipe(ServerLevel level) {
        Patch patch = PATCHES.get(level.dimension());
        if (patch != null) {
            patch.runners.clear();
        }
    }
}
