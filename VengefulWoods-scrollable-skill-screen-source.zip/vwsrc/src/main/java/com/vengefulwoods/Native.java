package com.vengefulwoods;

import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraftforge.registries.RegistryObject;

/**
 * The plants that belong here.
 * <p>
 * Every one is real, and every one is slow. A trillium takes years to come back from being picked, which is
 * why the forest minds that one most and why picking any of them costs you something. Putting them back is
 * worth a little - never as much as the taking cost, because the forest is not stupid.
 */
public enum Native {

    /** White trillium. Pick it and the plant may not flower again for years, and the woods know it. */
    TRILLIUM,
    /** Wild ginger. Grows in the leaf litter, tastes of itself, keeps. */
    WILD_GINGER,
    /** Ostrich fern. The fiddleheads are food once they are cooked, and poor food before that. */
    FIDDLEHEAD,
    /** Sweetgrass. Braided and dried it burns slowly and sweetly, which is most of the point of it. */
    SWEETGRASS,
    /** Wintergreen. A few leaves chewed will put you back on your feet. */
    WINTERGREEN,
    /** Cattail. Half of it is food and the other half is the best tinder growing anywhere. */
    CATTAIL,
    /** Sea buckthorn. Sour orange berries, and more in them than in anything else on a shore. */
    SEA_BUCKTHORN,
    /** Prickly pear. Both the pad and the fruit are worth having, and both will make you regret haste. */
    PRICKLY_PEAR,
    /** Wild bergamot. Bee balm: the pink heads make a dye and a tea that settles you. */
    BERGAMOT,
    /** Ramps. Wild leek, up for three weeks in spring, and dug out of existence wherever it is found. */
    RAMPS,
    /** Alpine bistort. It carries its own young on the stem, which is how anything survives up there. */
    BISTORT;

    public RegistryObject<Block> block() {
        switch (this) {
            case TRILLIUM:
                return VengefulWoods.TRILLIUM;
            case WILD_GINGER:
                return VengefulWoods.WILD_GINGER;
            case FIDDLEHEAD:
                return VengefulWoods.FIDDLEHEAD;
            case SWEETGRASS:
                return VengefulWoods.SWEETGRASS;
            case WINTERGREEN:
                return VengefulWoods.WINTERGREEN;
            case CATTAIL:
                return VengefulWoods.CATTAIL;
            case SEA_BUCKTHORN:
                return VengefulWoods.SEA_BUCKTHORN;
            case PRICKLY_PEAR:
                return VengefulWoods.PRICKLY_PEAR;
            case BERGAMOT:
                return VengefulWoods.BERGAMOT;
            case RAMPS:
                return VengefulWoods.RAMPS;
            default:
                return VengefulWoods.BISTORT;
        }
    }

    /** What picking it gives you. */
    public RegistryObject<Item> harvest() {
        switch (this) {
            case TRILLIUM:
                return VengefulWoods.TRILLIUM_BLOOM;
            case WILD_GINGER:
                return VengefulWoods.GINGER_ROOT;
            case FIDDLEHEAD:
                return VengefulWoods.FIDDLEHEADS;
            case SWEETGRASS:
                return VengefulWoods.SWEETGRASS_BRAID;
            case WINTERGREEN:
                return VengefulWoods.WINTERGREEN_LEAVES;
            case CATTAIL:
                return VengefulWoods.CATTAIL_ITEM;
            case SEA_BUCKTHORN:
                return VengefulWoods.SEA_BUCKTHORN_ITEM;
            case PRICKLY_PEAR:
                return VengefulWoods.PRICKLY_PEAR_ITEM;
            case BERGAMOT:
                return VengefulWoods.BERGAMOT_ITEM;
            case RAMPS:
                return VengefulWoods.RAMPS_ITEM;
            default:
                return VengefulWoods.BISTORT_ITEM;
        }
    }

    /**
     * How much of the forest's patience each picking uses up. Divided by the picks-per-tree setting, so a
     * handful of flowers is a fraction of a felled tree, not a tree.
     */
    public int pickCost() {
        switch (this) {
            case TRILLIUM:
                return Config.NATIVE_TRILLIUM_COST.get(); // Years to recover. It is not forgiven quickly.
            case WINTERGREEN:
                return 2;
            case RAMPS:
                return 3;   // Dug out of whole valleys in living memory. The woods have noticed.
            case BISTORT:
                return 2;   // Nothing up there grows back quickly.
            default:
                return 1;
        }
    }

    /** The kind of ground a plant will actually take to. Half of these would never grow in leaf litter. */
    public enum Ground {
        /** Woodland and field soil. Most things. */
        SOIL,
        /** Soft wet margins: mud, clay, the sand of a riverbank. */
        WET,
        /** Shingle and beach sand, where the salt wind is. */
        SHORE,
        /** Sand, red sand and baked clay. */
        ARID,
        /** Stone, scree and old snow, above where trees bother. */
        HIGH
    }

    public Ground ground() {
        switch (this) {
            case CATTAIL:
                return Ground.WET;
            case SEA_BUCKTHORN:
                return Ground.SHORE;
            case PRICKLY_PEAR:
                return Ground.ARID;
            case BISTORT:
                return Ground.HIGH;
            default:
                return Ground.SOIL;
        }
    }

    /** What the forest thinks of you putting one in the ground. Never as much as taking one costs. */
    public int plantWorth() {
        if (this == TRILLIUM) {
            return 3;
        }
        return this == RAMPS || this == BISTORT ? 2 : 1;
    }

    public String translationKey() {
        return "message.vengefulwoods.native." + name().toLowerCase(java.util.Locale.ROOT);
    }

    public static Native byName(String name) {
        for (Native plant : values()) {
            if (plant.name().equalsIgnoreCase(name)) {
                return plant;
            }
        }
        return null;
    }
}
