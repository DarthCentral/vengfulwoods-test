package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;

import javax.annotation.Nullable;

/**
 * Points, ranks, and what is allowed to be bought next.
 * <p>
 * Points come from getting somewhere: every rung of the forest's anger and every rung of its goodwill,
 * counted off the furthest you ever reached, plus a slow drip for the sheer volume of felling or giving you
 * have done. Nothing is handed out for standing still.
 */
public class Skills {

    // ------------------------------------------------------------------------------------------------------------
    // Points
    // ------------------------------------------------------------------------------------------------------------

    /** Brings the high-water marks up to date. Called each second, and before the tree is opened. */
    static void sync(ServerPlayer player) {
        if (player.getServer() == null) {
            return;
        }
        WrathData global = WrathData.global(player.getServer());
        WrathData.Account account = global.account(player.getUUID());
        int stage = account.stage().ordinal();
        int boon = account.boon().ordinal();
        if (stage > account.peakStage || boon > account.peakBoon) {
            account.peakStage = Math.max(account.peakStage, stage);
            account.peakBoon = Math.max(account.peakBoon, boon);
            global.setDirty();
            player.displayClientMessage(Component.translatable("message.vengefulwoods.skill_point")
                    .withStyle(ChatFormatting.AQUA, ChatFormatting.ITALIC), true);
        }
    }

    /**
     * What this player may draw on. Normally their own record, but when the server pools skill points and
     * not standing, the pool is the furthest anybody has got plus everything everybody has done, so a group
     * that splits the work up is not punished for it.
     */
    static int earned(WrathData data, java.util.UUID id) {
        if (!Config.SHARE_SKILLS.get() || Config.SHARE_STANDING.get()) {
            return earned(data.account(id));
        }
        int stage = 0;
        int boon = 0;
        int felled = 0;
        int offerings = 0;
        for (java.util.Map.Entry<java.util.UUID, WrathData.Account> entry : data.accounts().entrySet()) {
            if (WrathData.isShared(entry.getKey())) {
                continue;
            }
            WrathData.Account one = entry.getValue();
            stage = Math.max(stage, one.peakStage);
            boon = Math.max(boon, one.peakBoon);
            felled += one.felled;
            offerings += one.offerings;
        }
        return stage + boon
                + felled / Config.SKILL_PER_FELLED.get()
                + offerings / Config.SKILL_PER_OFFERING.get();
    }

    static int earned(WrathData.Account account) {
        // The two ladders, plus a point for every twenty trees and every fifty offerings, so a long game
        // keeps paying even once both ladders are topped out.
        return account.peakStage + account.peakBoon
                + account.felled / Config.SKILL_PER_FELLED.get()
                + account.offerings / Config.SKILL_PER_OFFERING.get();
    }

    static int spent(WrathData.Account account) {
        int total = 0;
        for (Skill skill : Skill.values()) {
            total += rank(account, skill) * skill.costPerRank;
        }
        return total;
    }

    public static int available(WrathData data, java.util.UUID id) {
        return Math.max(0, earned(data, id) - spent(data.skills(id)));
    }

    public static int rank(WrathData.Account account, Skill skill) {
        int index = skill.ordinal();
        return index < account.skillRanks.length ? account.skillRanks[index] : 0;
    }

    /**
     * What rank this player has in a thing. Zero means they do not have it at all, which is now the
     * starting state for every class power in the mod.
     */
    public static int rank(@Nullable Player player, Skill skill) {
        if (!(player instanceof ServerPlayer server) || server.getServer() == null) {
            return 0;
        }
        return rank(WrathData.global(server.getServer()).skills(server.getUUID()), skill);
    }

    public static boolean has(@Nullable Player player, Skill skill) {
        return rank(player, skill) > 0;
    }

    /** True when the branch above this one has been taken, so this one may be bought at all. */
    public static boolean unlocked(WrathData.Account account, Skill skill) {
        return skill.requires == null || rank(account, skill.requires) > 0;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Buying
    // ------------------------------------------------------------------------------------------------------------

    static void buy(ServerPlayer player, Skill skill) {
        if (player.getServer() == null) {
            return;
        }
        WrathData global = WrathData.global(player.getServer());
        WrathData.Account account = global.skills(player.getUUID());
        // The class gate is always the buyer's own class, even when the ranks themselves are pooled.
        if (!skill.openTo(global.own(player.getUUID()).woodsClass())) {
            return;
        }
        int current = rank(account, skill);
        if (current >= skill.maxRank) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.skill_known",
                    Component.translatable(skill.key())).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (!unlocked(account, skill)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.skill_locked",
                    Component.translatable(skill.requires.key())).withStyle(ChatFormatting.DARK_RED), true);
            return;
        }
        if (available(global, player.getUUID()) < skill.costPerRank) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.skill_short",
                    skill.costPerRank).withStyle(ChatFormatting.DARK_RED), true);
            return;
        }
        account.skillRanks[skill.ordinal()] = current + 1;
        global.setDirty();
        player.displayClientMessage(Component.translatable("message.vengefulwoods.skill_learned",
                        Component.translatable(skill.key()), current + 1)
                .withStyle(ChatFormatting.AQUA), false);
    }

    // ------------------------------------------------------------------------------------------------------------
    // The window
    // ------------------------------------------------------------------------------------------------------------

    private static ContainerData readout(ServerPlayer player) {
        return new ContainerData() {
            @Override
            public int get(int index) {
                if (player.getServer() == null) {
                    return 0;
                }
                WrathData global = WrathData.global(player.getServer());
                WrathData.Account account = global.skills(player.getUUID());
                if (index == 0) {
                    return available(global, player.getUUID());
                }
                int skill = index - 1;
                return skill < account.skillRanks.length ? account.skillRanks[skill] : 0;
            }

            @Override
            public void set(int index, int value) {
            }

            @Override
            public int getCount() {
                return SkillMenu.DATA_SIZE;
            }
        };
    }

    private static final class Provider implements MenuProvider {

        private final ServerPlayer player;

        private Provider(ServerPlayer player) {
            this.player = player;
        }

        @Override
        public Component getDisplayName() {
            return Component.translatable("container.vengefulwoods.skills");
        }

        @Nullable
        @Override
        public AbstractContainerMenu createMenu(int id, Inventory inventory, Player clicker) {
            WrathData.Account account = WrathData.global(player.getServer()).own(player.getUUID());
            return new SkillMenu(id, account.woodsClass(), readout(player));
        }
    }

    public static void open(ServerPlayer player) {
        if (!Config.SKILLS_ENABLED.get()) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.skills_off")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        sync(player);
        net.minecraftforge.network.NetworkHooks.openScreen(player, new Provider(player),
                buffer -> buffer.writeUtf(WrathData.global(player.getServer())
                        .own(player.getUUID()).woodsClass().name()));
    }
}
