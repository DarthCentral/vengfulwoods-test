package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.block.DynamicSaplingBlock;
import com.ferreusveritas.dynamictrees.block.rooty.RootyBlock;
import com.ferreusveritas.dynamictrees.init.DTConfigs;
import com.ferreusveritas.dynamictrees.tree.species.Species;
import com.ferreusveritas.dynamictrees.util.SafeChunkBounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Runs the forest. Every tick it:
 * <ul>
 * <li>looks through one chunk near a player for Dynamic Trees (and saplings and torches),</li>
 * <li>gives a few of the known trees their share of growth, saplings and rhizomes for the time that has passed,</li>
 * <li>turns saplings into trees, brings felled trees back, and moves rhizomes and tendrils.</li>
 * </ul>
 * "Per day" amounts are handed out a little at a time, so a tree that is owed 10 saplings a day plants one roughly
 * every 2 minutes. Sleeping through the night counts as time passed.
 */
public class ForestDirector {

    /** What we remember about one tree while it is near a player. */
    static final class TreeRec {
        long lastGameTime = -1L;
        long lastDayTime = -1L;
        long lastLeafAge = -1L;
        float growth;
        float saplings;
        float rhizomes;
    }

    /** Everything we track for one dimension. Rebuilt after a restart. */
    static final class LevelState {
        final Map<BlockPos, TreeRec> trees = new HashMap<>();
        final List<BlockPos> order = new ArrayList<>();
        int treeCursor;
        int scanIndex;
        int tipCursor;
        /** Sapling position -> game time at which it becomes a tree. */
        final Map<BlockPos, Long> saplings = new HashMap<>();
        final Set<BlockPos> torches = new HashSet<>();
        final List<Rhizomes.Tendril> tendrils = new ArrayList<>();
        /** Player -> game time before which no tree may be dropped on them again. */
        final Map<UUID, Long> nextTopple = new HashMap<>();
        /** Player -> game time before which no branch may be dropped on them again. */
        final Map<UUID, Long> nextCanopy = new HashMap<>();
    }

    private static final Map<ResourceKey<Level>, LevelState> STATES = new HashMap<>();

    public static void clear() {
        STATES.clear();
    }

    static LevelState state(ServerLevel level) {
        return STATES.computeIfAbsent(level.dimension(), key -> new LevelState());
    }

    @SubscribeEvent
    public void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.phase != TickEvent.Phase.END || !(event.level instanceof ServerLevel level)) {
            return;
        }
        try {
            tick(level);
        } catch (RuntimeException e) {
            VengefulWoods.LOGGER.error("Vengeful Woods tick failed", e);
        }
    }

    private static void tick(ServerLevel level) {
        MinecraftServer server = level.getServer();
        long now = level.getGameTime();

        // The world at large grows at the pace of whoever the forest is angriest with, since one growth rate
        // has to serve every tree. Everything that can be aimed at a person is decided per person below.
        Stage worst = WrathData.worstStage(server);
        if (level.dimension() == Level.OVERWORLD && now % 200L == 0L) {
            SpeciesTuner.apply(worst);
        }

        LevelState st = state(level);
        List<ServerPlayer> players = level.players();

        if (!players.isEmpty()) {
            // A few chunks a tick, so a wide search still gets through itself in reasonable time.
            for (int i = 0; i < 3; i++) {
                scanStep(level, st, players, worst, now);
            }
        }
        Kudzu.tick(level, players, now);
        Invasives.tick(level, players, now);

        // Everything that belongs to a player rather than to the forest runs whatever mood the woods are
        // in. A new player is Dormant by definition, so anything gated on the forest being angry would
        // never reach them - which is exactly how the class prompt went missing.
        if (!players.isEmpty()) {
            Classes.tick(level, now);
            Invader.tick(level, now);
            ClassChoice.tick(level, players, now);
            Mushroom.tick(level, players, now);
            if (now % 100L == 0L && Config.SKILLS_ENABLED.get()) {
                for (ServerPlayer player : players) {
                    Skills.sync(player);
                }
            }
        }

        if (!players.isEmpty() && (worst != Stage.DORMANT || anyFavour(server, players))) {
            if (worst != Stage.DORMANT) {
                treeStep(level, st, players, now);
                if (now % 20L == 0L) {
                    saplingStep(level, st, now);
                }
                if (now % 100L == 0L) {
                    regrowStep(level, st, now);
                }
            }
        }
        Rhizomes.tick(level, st, players, now);
        Offerings.tick(level, st, players, now);
        Treefall.tick(level, st, players, now);
    }

    private static boolean anyFavour(MinecraftServer server, List<ServerPlayer> players) {
        for (ServerPlayer player : players) {
            if (WrathData.boonOf(server, player.getUUID()) != Boon.NONE) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Finding trees
    // ------------------------------------------------------------------------------------------------------------

    private static boolean isInteresting(BlockState state) {
        Block block = state.getBlock();
        return block instanceof RootyBlock || block instanceof DynamicSaplingBlock
                || Kudzu.isKudzu(state) || Invasives.isInvasive(state) || state.is(VengefulWoods.LIGHT_TARGETS);
    }

    /** Looks through one chunk near one player. All chunks around every player are visited in turn. */
    private static void scanStep(ServerLevel level, LevelState st, List<ServerPlayer> players, Stage stage, long now) {
        // Looks far past where anyone is standing, so trees you have never laid eyes on still get driven.
        int radius = Math.max(1, Config.SCAN_RADIUS.get() / 16);
        int side = radius * 2 + 1;
        int area = side * side;

        if (st.scanIndex >= area * players.size()) {
            st.scanIndex = 0;
        }
        int index = st.scanIndex++;
        ServerPlayer player = players.get(index / area);
        int offset = index % area;
        int chunkX = (player.blockPosition().getX() >> 4) + (offset % side) - radius;
        int chunkZ = (player.blockPosition().getZ() >> 4) + (offset / side) - radius;

        LevelChunk chunk = level.getChunkSource().getChunkNow(chunkX, chunkZ);
        if (chunk == null) {
            return;
        }

        boolean wantSaplings = stage.atLeast(Stage.THICKENING);
        boolean wantTorches = stage.huntsLight();
        if (st.torches.size() > 4096) {
            st.torches.clear();
        }

        int minX = chunk.getPos().getMinBlockX();
        int minZ = chunk.getPos().getMinBlockZ();
        LevelChunkSection[] sections = chunk.getSections();
        for (int i = 0; i < sections.length; i++) {
            LevelChunkSection section = sections[i];
            if (section == null || section.hasOnlyAir() || !section.maybeHas(ForestDirector::isInteresting)) {
                continue;
            }
            int minY = chunk.getSectionYFromSectionIndex(i) << 4;
            for (int y = 0; y < 16; y++) {
                for (int z = 0; z < 16; z++) {
                    for (int x = 0; x < 16; x++) {
                        BlockState blockState = section.getBlockState(x, y, z);
                        Block block = blockState.getBlock();
                        if (block instanceof RootyBlock) {
                            registerTree(st, new BlockPos(minX + x, minY + y, minZ + z));
                        } else if (block instanceof DynamicSaplingBlock) {
                            if (wantSaplings && st.saplings.size() < 2048) {
                                st.saplings.putIfAbsent(new BlockPos(minX + x, minY + y, minZ + z), now + stage.saplingDelayTicks());
                            }
                        } else if (Invasives.isInvasive(blockState)) {
                            if (level.random.nextInt(40) == 0) {
                                Invasives.awaken(level, new BlockPos(minX + x, minY + y, minZ + z), blockState);
                            }
                        } else if (Kudzu.isKudzu(blockState)) {
                            Kudzu.noteFront(level, new BlockPos(minX + x, minY + y, minZ + z), blockState);
                        } else if (wantTorches && blockState.is(VengefulWoods.LIGHT_TARGETS)) {
                            st.torches.add(new BlockPos(minX + x, minY + y, minZ + z));
                        }
                    }
                }
            }
        }
    }

    /** The tree limit, with 0 meaning there isn't one. */
    static boolean roomForMoreTrees(LevelState st) {
        int max = Config.MAX_TREES.get();
        return max <= 0 || st.trees.size() < max;
    }

    static TreeRec registerTree(LevelState st, BlockPos rootPos) {
        TreeRec rec = st.trees.get(rootPos);
        if (rec == null && roomForMoreTrees(st)) {
            rec = new TreeRec();
            st.trees.put(rootPos, rec);
            st.order.add(rootPos);
        }
        return rec;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Driving trees
    // ------------------------------------------------------------------------------------------------------------

    private static void treeStep(ServerLevel level, LevelState st, List<ServerPlayer> players, long now) {
        // Standing timber pays into the pool. A wood that has already taken a valley has more to spend
        // than one that is still a few saplings, which is what makes the late game run away from you.
        if (now % 20L == 0L && !st.order.isEmpty()) {
            Biomass.growForest(level, st.order.size(), 20.0F / 24000.0F);
        }
        BlockPos focus = Biomass.focus(level, players, WrathData.worstStage(level.getServer()), now);

        int count = Math.min(Config.TREES_PER_TICK.get(), st.order.size());
        for (int i = 0; i < count && !st.order.isEmpty(); i++) {
            if (st.treeCursor >= st.order.size()) {
                st.treeCursor = 0;
            }
            BlockPos rootPos = st.order.get(st.treeCursor);
            TreeRec rec = st.trees.get(rootPos);
            if (rec == null || !isLiveTree(level, rootPos, players)) {
                // Swap-remove: quick, and the order of the list does not matter.
                st.trees.remove(rootPos);
                int lastIndex = st.order.size() - 1;
                st.order.set(st.treeCursor, st.order.get(lastIndex));
                st.order.remove(lastIndex);
                continue;
            }
            st.treeCursor++;
            // Whoever is nearest decides how this tree behaves: the forest reacts to the person in front of it.
            Stage stage = WrathData.stageNear(level.getServer(), rootPos, players, Config.ACTIVE_RADIUS.get() + 24.0);
            if (stage == Stage.DORMANT) {
                // Out of everyone's sight it falls back on its general temper, so the spread carries on
                // in the chunks you left behind.
                stage = WrathData.worstStage(level.getServer());
            }
            if (stage != Stage.DORMANT) {
                driveTree(level, st, rootPos, rec, players, stage, now, focus);
            }
        }
    }

    private static boolean isLiveTree(ServerLevel level, BlockPos rootPos, List<ServerPlayer> players) {
        // A tree is kept working as long as its chunk is ticking. Nobody has to be watching: an angry forest
        // spreads just as hard behind your back as it does in front of you.
        if (!level.isPositionEntityTicking(rootPos)) {
            return false;
        }
        BlockState rootState = level.getBlockState(rootPos);
        RootyBlock rooty = TreeHelper.getRooty(rootState);
        if (rooty == null) {
            return false;
        }
        return TreeHelper.isBranch(level.getBlockState(rootPos.relative(rooty.getTrunkDirection(level, rootPos))));
    }

    /** Adds what a tree is owed for the time that passed, without letting it bank more than one day's worth. */
    static float accrue(float current, float perDay, float days) {
        return Math.max(current, Math.min(current + perDay * days, perDay));
    }

    private static void driveTree(ServerLevel level, LevelState st, BlockPos rootPos, TreeRec rec,
                                  List<ServerPlayer> players, Stage stage, long now,
                                  @Nullable BlockPos focus) {
        long dayTime = level.getDayTime();
        if (rec.lastGameTime < 0L) {
            rec.lastGameTime = now;
            rec.lastDayTime = dayTime;
        }
        // Use whichever clock moved further, so sleeping through the night counts but frozen daylight still works.
        long elapsed = Math.max(now - rec.lastGameTime, dayTime - rec.lastDayTime);
        rec.lastGameTime = now;
        rec.lastDayTime = dayTime;
        if (elapsed > 0L) {
            float days = Math.min(elapsed, 24000L) / 24000.0F;
            rec.growth = accrue(rec.growth, stage.growthSignalsPerDay, days);
            rec.saplings = accrue(rec.saplings, stage.saplingsPerDay, days);
            rec.rhizomes = accrue(rec.rhizomes, stage.rhizomesPerDay, days);
        }

        BlockState rootState = level.getBlockState(rootPos);
        RootyBlock rooty = TreeHelper.getRooty(rootState);
        if (rooty == null) {
            return;
        }
        Species species = rooty.getSpecies(rootState, level, rootPos);
        if (species == null || !species.isValid()) {
            return;
        }

        int signals = Math.min((int) rec.growth, 3);
        if (signals > 0) {
            rec.growth -= signals;
        }
        // Whatever the forest has banked, spent here. Spread thin this is a trickle; when the forest is
        // channelling and this tree is where it is aiming, it is everything a thousand trees made.
        signals += Biomass.drawForest(level, rootPos, focus, stage, st.order.size());
        if (signals > 0) {
            forceGrowth(level, rootPos, species, signals);
            // Helping the leaves fill in is costly, so each tree gets it at most once every 10 seconds.
            if (rec.lastLeafAge < 0L || now - rec.lastLeafAge >= LEAF_AGE_INTERVAL) {
                rec.lastLeafAge = now;
                ageLeaves(level, rootPos);
            }
        }
        int toPlant = Math.min((int) rec.saplings, stage.saplingsPerVisit());
        for (int i = 0; i < toPlant && roomForMoreTrees(st); i++) {
            rec.saplings -= 1.0F;
            plantSaplingNear(level, st, rootPos, species, players, stage, now);
        }
        // Where kudzu has reached the trunk, the tree pulls at it. Far too slowly to matter, which is the point.
        if (level.random.nextFloat() < Config.KUDZU_TREE_RESISTANCE.get() * 0.25F) {
            tearAtKudzu(level, rootPos);
        }
        if (rec.rhizomes >= 1.0F) {
            rec.rhizomes -= 1.0F;
            Rhizomes.launch(level, st, rootPos, species, players, stage);
        }
    }

    /**
     * Makes a tree grow right now. Each "signal" is one Dynamic Trees growth pulse, which adds at most one new
     * branch block somewhere on the tree (and thickens the wood it travels through).
     */
    static void forceGrowth(ServerLevel level, BlockPos rootPos, Species species, int signals) {
        if (trunkHeight(level, rootPos) >= Config.MAX_TREE_HEIGHT.get()) {
            return;
        }
        // Dynamic Trees sends (growth rate x its two config multipliers) pulses per update. Pin that product to
        // exactly 1 while we work so "signals" really means signals, then put the real growth rate back.
        float realRate = SpeciesTuner.readGrowthRate(species);
        double factor = DTConfigs.TREE_GROWTH_MULTIPLIER.get() * DTConfigs.TREE_GROWTH_FOLDING.get();
        boolean pinned = !Float.isNaN(realRate) && factor > 0.0001;
        if (pinned) {
            species.setGrowthRate((float) (1.0 / factor));
        }
        try {
            for (int i = 0; i < signals; i++) {
                BlockState rootState = level.getBlockState(rootPos);
                RootyBlock rooty = TreeHelper.getRooty(rootState);
                if (rooty == null) {
                    break;
                }
                // Trees normally stop when their soil is used up. An angry forest never runs out.
                if (rooty.getFertility(rootState, level, rootPos) < 8) {
                    rooty.setFertility(level, rootPos, 15);
                    rootState = level.getBlockState(rootPos);
                    rooty = TreeHelper.getRooty(rootState);
                    if (rooty == null) {
                        break;
                    }
                }
                rooty.updateTree(rootState, level, rootPos, level.random, false);
            }
        } finally {
            if (pinned) {
                species.setGrowthRate(realRate);
            }
        }
    }

    /** Ticks between leaf-ageing passes for one tree. */
    private static final long LEAF_AGE_INTERVAL = 200L;

    /**
     * Helps leaves spread around branches that just grew. Dynamic Trees does the same pass after bone meal.
     * It walks a box of blocks, so it is kept small and throttled.
     */
    private static void ageLeaves(ServerLevel level, BlockPos rootPos) {
        final int halfWidth = 4;
        // Never touch chunks that are not loaded.
        if (!level.isLoaded(rootPos.offset(-halfWidth, 0, -halfWidth)) || !level.isLoaded(rootPos.offset(halfWidth, 0, -halfWidth))
                || !level.isLoaded(rootPos.offset(-halfWidth, 0, halfWidth)) || !level.isLoaded(rootPos.offset(halfWidth, 0, halfWidth))) {
            return;
        }
        int height = Math.min(Math.min(trunkHeight(level, rootPos) + 6, 32), level.getMaxBuildHeight() - rootPos.getY() - 2);
        if (height > 0) {
            TreeHelper.ageVolume(level, rootPos.above(), halfWidth, height, 1, SafeChunkBounds.ANY);
        }
    }

    static int trunkHeight(ServerLevel level, BlockPos rootPos) {
        int limit = Config.MAX_TREE_HEIGHT.get() + 1;
        BlockPos.MutableBlockPos cursor = rootPos.mutable().move(Direction.UP);
        int height = 0;
        while (height < limit && TreeHelper.isBranch(level.getBlockState(cursor))) {
            height++;
            cursor.move(Direction.UP);
        }
        return height;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Saplings
    // ------------------------------------------------------------------------------------------------------------

    private static void plantSaplingNear(ServerLevel level, LevelState st, BlockPos rootPos, Species species,
                                         List<ServerPlayer> players, Stage stage, long now) {
        RandomSource random = level.random;

        // What the forest is reaching for: players at stage 5, torches at stage 4.
        BlockPos lure = null;
        if (stage.huntsPlayers()) {
            ServerPlayer prey = nearestPlayer(players, rootPos, 64.0, true);
            if (prey != null) {
                lure = prey.blockPosition();
            }
        }
        if (lure == null && stage.huntsLight()) {
            lure = Rhizomes.nearestTorch(level, st, rootPos);
        }

        for (int attempt = 0; attempt < 6; attempt++) {
            double angle;
            double distance;
            if (lure != null && random.nextFloat() < 0.6F) {
                angle = Math.atan2(lure.getZ() - rootPos.getZ(), lure.getX() - rootPos.getX()) + (random.nextDouble() - 0.5) * 1.2;
                distance = 3 + random.nextInt(6);
            } else {
                angle = random.nextDouble() * Math.PI * 2.0;
                distance = 2 + random.nextInt(5);
            }
            int dx = (int) Math.round(Math.cos(angle) * distance);
            int dz = (int) Math.round(Math.sin(angle) * distance);
            if (dx == 0 && dz == 0) {
                continue;
            }
            if (trySprout(level, st, species, rootPos.offset(dx, 1, dz), 4, stage, now)) {
                return;
            }
        }
    }

    /**
     * Tries to plant a sapling of the given species in the column of {@code around}, looking up to {@code reach}
     * blocks above and below it for a free spot on soil the species can grow in.
     */
    static boolean trySprout(ServerLevel level, LevelState st, Species species, BlockPos around, int reach, Stage stage, long now) {
        for (int dy = reach; dy >= -reach; dy--) {
            BlockPos pos = around.above(dy);
            if (!level.isLoaded(pos)) {
                return false;
            }
            BlockState here = level.getBlockState(pos);
            if (!here.canBeReplaced() || !here.getFluidState().isEmpty()) {
                continue;
            }
            BlockPos soilPos = pos.below();
            if (!species.isAcceptableSoil(level, soilPos, level.getBlockState(soilPos))) {
                continue;
            }
            if (isCrowded(level, pos)) {
                return false;
            }
            if (Config.AVOID_BASES.get() && favouredNearby(level, pos) && Offerings.nearBase(level, pos)) {
                return false; // Allies keep their roots off your doorstep.
            }
            if (species.plantSapling(level, pos, false)) {
                st.saplings.put(pos.immutable(), now + stage.saplingDelayTicks());
                return true;
            }
            return false;
        }
        return false;
    }

    /**
     * True if another tree or sapling is too close. With minTreeSpacing at 0 - the default - nothing is ever
     * too close, and trunks can stand shoulder to shoulder.
     */
    static boolean isCrowded(ServerLevel level, BlockPos pos) {
        int spacing = Config.MIN_TREE_SPACING.get();
        if (spacing <= 0) {
            return false;
        }
        for (BlockPos check : BlockPos.betweenClosed(pos.offset(-spacing, -spacing, -spacing), pos.offset(spacing, 1, spacing))) {
            Block block = level.getBlockState(check).getBlock();
            if (block instanceof RootyBlock || block instanceof DynamicSaplingBlock) {
                return true;
            }
        }
        return false;
    }

    /** One pull at whatever has grown onto this tree. */
    private static void tearAtKudzu(ServerLevel level, BlockPos rootPos) {
        for (int i = 0; i < 3; i++) {
            BlockPos pos = rootPos.offset(level.random.nextInt(3) - 1, level.random.nextInt(5), level.random.nextInt(3) - 1);
            if (level.isLoaded(pos) && Kudzu.isKudzu(level.getBlockState(pos))) {
                level.removeBlock(pos, false);
                return;
            }
        }
    }

    /** From stage 2 on, saplings do not wait around: they become trees after a short delay. */
    private static void saplingStep(ServerLevel level, LevelState st, long now) {
        Iterator<Map.Entry<BlockPos, Long>> iterator = st.saplings.entrySet().iterator();
        int budget = 8;
        while (iterator.hasNext() && budget > 0) {
            Map.Entry<BlockPos, Long> entry = iterator.next();
            if (entry.getValue() > now) {
                continue;
            }
            BlockPos pos = entry.getKey();
            iterator.remove();
            if (!level.isPositionEntityTicking(pos)) {
                continue;
            }
            budget--;
            if (level.getBlockState(pos).getBlock() instanceof DynamicSaplingBlock sapling) {
                Species species = sapling.getSpecies().selfOrLocationOverride(level, pos);
                if (species.isValid() && species.transitionToTree(level, pos)) {
                    registerTree(st, pos.below());
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Stage 4: destroyed trees come back
    // ------------------------------------------------------------------------------------------------------------

    private static void regrowStep(ServerLevel level, LevelState st, long now) {
        WrathData data = WrathData.get(level);
        if (data.regrows.isEmpty()) {
            return;
        }
        long dayTime = level.getDayTime();
        Iterator<WrathData.Regrow> iterator = data.regrows.iterator();
        while (iterator.hasNext()) {
            WrathData.Regrow regrow = iterator.next();
            if (now < regrow.dueGameTime && dayTime < regrow.dueDayTime) {
                continue;
            }
            if (!level.isPositionEntityTicking(regrow.rootPos)) {
                continue; // Nobody is around. It will happen when someone comes back.
            }
            iterator.remove();
            data.setDirty();
            regrowTree(level, st, regrow);
        }
    }

    private static void regrowTree(ServerLevel level, LevelState st, WrathData.Regrow regrow) {
        BlockPos rootPos = regrow.rootPos;
        BlockPos trunkPos = rootPos.above();
        boolean alive = TreeHelper.isRooty(level.getBlockState(rootPos)) && TreeHelper.isBranch(level.getBlockState(trunkPos));

        if (!alive) {
            Species species = lookupSpecies(regrow.species);
            if (species == null) {
                return;
            }
            // Clear plants, leaves and rhizomes out of the way. Anything a player built there stops the regrowth.
            for (BlockPos pos : new BlockPos[]{trunkPos, trunkPos.above()}) {
                BlockState blockState = level.getBlockState(pos);
                if (blockState.isAir()) {
                    continue;
                }
                if (blockState.canBeReplaced() || TreeHelper.isLeaves(blockState) || blockState.is(VengefulWoods.RHIZOME.get())) {
                    level.removeBlock(pos, false);
                } else {
                    return;
                }
            }
            if (!species.selfOrLocationOverride(level, trunkPos).transitionToTree(level, trunkPos)) {
                return;
            }
        }

        // A burst of growth: the tree is back to a real tree within a minute or two.
        TreeRec rec = registerTree(st, rootPos);
        if (rec != null) {
            rec.growth = Math.max(rec.growth, 48.0F);
        }
        Rhizomes.burst(level, trunkPos);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------------------------------------------------

    @Nullable
    static Species lookupSpecies(String name) {
        try {
            Species species = Species.REGISTRY.get(name);
            return species != null && species.isValid() ? species : null;
        } catch (RuntimeException e) {
            return null;
        }
    }

    /** True if the nearest player is on good enough terms for the forest to keep clear of their building. */
    static boolean favouredNearby(ServerLevel level, BlockPos pos) {
        ServerPlayer nearest = nearestPlayer(level.players(), pos, 48.0, false);
        return nearest != null && WrathData.boonOf(level.getServer(), nearest.getUUID()).atLeast(Boon.ALLIED);
    }

    /**
     * Stage 4 and up: the moment a tree comes down, something takes root on the stump. Not the full
     * resurrection of stage 5, just a sapling that will not wait.
     */
    static void sproutOnStump(ServerLevel level, BlockPos rootPos, Species species, Stage stage, long now) {
        LevelState st = state(level);
        if (!roomForMoreTrees(st)) {
            return;
        }
        trySprout(level, st, species, rootPos.above(), 2, stage, now);
    }

    /** Nearest player within range. With preyOnly, creative and spectator players are ignored. */
    @Nullable
    static ServerPlayer nearestPlayer(List<ServerPlayer> players, BlockPos pos, double range, boolean preyOnly) {
        ServerPlayer best = null;
        double bestDistSq = range * range;
        for (ServerPlayer player : players) {
            if (preyOnly && (player.isCreative() || player.isSpectator() || !player.isAlive())) {
                continue;
            }
            double distSq = player.blockPosition().distSqr(pos);
            if (distSq <= bestDistSq) {
                bestDistSq = distSq;
                best = player;
            }
        }
        return best;
    }
}
