package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.tree.species.Species;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.Iterator;
import java.util.List;

/**
 * Rhizomes: lines of wooden blocks that creep out from a tree just under the surface, burrowing through whatever
 * is in the way and sprouting saplings as they go.
 * <ul>
 * <li>Stage 3: they wander.</li>
 * <li>Stage 4: they head for torches and either knock them off or grow over them.</li>
 * <li>Stage 5: they head for players, burst out of the ground next to them as tendrils, hit them and smash
 * the blocks around them.</li>
 * </ul>
 */
public final class Rhizomes {

    private static final ResourceKey<DamageType> TENDRIL_DAMAGE =
            ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation(VengefulWoods.MODID, "tendril"));

    private static final double PLAYER_SEEK_RANGE = 48.0;
    private static final double TORCH_SEEK_RANGE = 32.0;
    /** How long a tendril keeps lashing after it bursts out (in ticks). */
    private static final int TENDRIL_LIFETIME = 240;

    /** A column of rhizome blocks rising out of the ground to attack. Not saved; after a restart it is just wood. */
    static final class Tendril {
        final BlockPos base;
        int height;
        int maxHeight;
        int age;

        Tendril(BlockPos base, int maxHeight) {
            this.base = base;
            this.maxHeight = maxHeight;
        }
    }

    private Rhizomes() {
    }

    // ------------------------------------------------------------------------------------------------------------
    // Block rules
    // ------------------------------------------------------------------------------------------------------------

    static boolean isRhizome(BlockState state) {
        return state.is(VengefulWoods.RHIZOME.get());
    }

    /** Open space: air, plants, water, leaves - anything a root is not "inside" of. */
    private static boolean isOpen(BlockState state) {
        return state.isAir() || !state.blocksMotion() || state.is(BlockTags.LEAVES);
    }

    /** True for anything a player is likely to have put there, as opposed to natural ground. */
    static boolean isBuiltBlock(BlockState state) {
        return !isNaturalGround(state);
    }

    /** Natural ground that is quietly replaced. Anything else is "built" and gets broken properly, with drops. */
    private static boolean isNaturalGround(BlockState state) {
        return state.isAir() || state.canBeReplaced() || !state.getFluidState().isEmpty()
                || state.is(BlockTags.DIRT) || state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(BlockTags.SAND)
                || state.is(BlockTags.LEAVES) || state.is(BlockTags.SNOW)
                || state.is(Blocks.GRAVEL) || state.is(Blocks.CLAY) || state.is(Blocks.SANDSTONE);
    }

    static boolean canBurrow(ServerLevel level, BlockPos pos, BlockState state) {
        if (state.isAir() || Kudzu.isKudzu(state)) {
            return true; // Roots shove straight through the weed - one of the few fights they win.
        }
        if (TreeHelper.isBranch(state) || TreeHelper.isRooty(state)) {
            return false; // Never eat another tree.
        }
        if (state.is(VengefulWoods.RHIZOME_IMMUNE) || state.getDestroySpeed(level, pos) < 0.0F) {
            return false; // Bedrock and friends.
        }
        if (state.getFluidState().is(FluidTags.LAVA)) {
            return false;
        }
        if (state.hasBlockEntity() && !Config.BREAK_CONTAINERS.get()) {
            return false;
        }
        return isNaturalGround(state) || Config.RHIZOMES_BREAK_BUILDS.get();
    }

    /**
     * Turns the block at pos into rhizome.
     * <p>
     * It mostly just replaces what was there - root grows through soil and stone without anything falling out
     * of it. Only something you built is broken properly, so your own walls come back as items rather than
     * silently disappearing.
     */
    private static void place(ServerLevel level, BlockPos pos, BlockState old) {
        if (isRhizome(old)) {
            return;
        }
        if (!isNaturalGround(old) && Config.RHIZOMES_DROP_BUILDS.get()) {
            level.destroyBlock(pos, true);
        }
        level.setBlock(pos, VengefulWoods.RHIZOME.get().defaultBlockState(), 3);
    }

    /** Splinters and a cracking sound. */
    static void burst(ServerLevel level, BlockPos pos) {
        level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, VengefulWoods.RHIZOME.get().defaultBlockState()),
                pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5, 14, 0.35, 0.35, 0.35, 0.05);
        Sounds.play(level, pos, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.5F);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Starting a rhizome
    // ------------------------------------------------------------------------------------------------------------

    /** A tree sends out a new rhizome from its roots. */
    static void launch(ServerLevel level, ForestDirector.LevelState st, BlockPos rootPos, Species species,
                       List<ServerPlayer> players, Stage stage) {
        WrathData data = WrathData.get(level);
        int maxTips = Config.MAX_TIPS.get();
        if (maxTips > 0 && data.tips.size() >= maxTips) {
            return;
        }
        RandomSource random = level.random;
        Direction dir = Direction.from2DDataValue(random.nextInt(4));

        // Aim at whatever the forest is after right now.
        BlockPos aim = null;
        ServerPlayer prey = huntedPlayer(level, players, rootPos);
        if (prey != null) {
            aim = prey.blockPosition();
        }
        if (aim == null && stage.huntsLight()) {
            aim = nearestTorch(level, st, rootPos);
        }
        if (aim != null) {
            Direction towards = horizontalTowards(rootPos, aim, random);
            if (towards != null) {
                dir = towards;
            }
        }

        for (int i = 0; i < 4; i++) {
            BlockPos start = rootPos.relative(dir);
            BlockState startState = level.getBlockState(start);
            if (isRhizome(startState) || canBurrow(level, start, startState)) {
                place(level, start, startState);
                data.tips.add(new WrathData.Tip(start, dir, species.getRegistryName().toString()));
                data.setDirty();
                return;
            }
            dir = dir.getClockWise();
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Every tick
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players, long now) {
        if (now % 5L == 0L && !st.tendrils.isEmpty()) {
            tickTendrils(level, st, players);
        }
        if (now % 20L == 0L) {
            gripStep(level, players);
        }
        WrathData data = WrathData.get(level);
        if (data.tips.isEmpty()) {
            return;
        }
        int count = Math.min(12, data.tips.size());
        for (int i = 0; i < count && !data.tips.isEmpty(); i++) {
            if (st.tipCursor >= data.tips.size()) {
                st.tipCursor = 0;
            }
            WrathData.Tip tip = data.tips.get(st.tipCursor);
            if (!level.isPositionEntityTicking(tip.pos)) {
                // Nobody near: the rhizome sleeps until someone comes back.
                tip.lastGameTime = -1L;
                st.tipCursor++;
                continue;
            }
            // A rhizome behaves according to whoever it is closest to.
            Stage stage = WrathData.stageNear(level.getServer(), tip.pos, players, 96.0);
            if (!stage.hasRhizomes()) {
                tip.lastGameTime = -1L;
                st.tipCursor++;
                continue;
            }
            if (advance(level, st, tip, players, stage, now)) {
                st.tipCursor++;
            } else {
                data.tips.remove(st.tipCursor);
            }
            data.setDirty();
        }
    }

    /**
     * Stage 6 and up: root underfoot drags at whoever the forest is after.
     * <p>
     * It reads the whole patch of ground under the player rather than the single block they happen to be
     * standing on, so crossing a root mat is a steady heaviness instead of the slowdown flickering on and off
     * every time a footstep lands between two roots. One stray root does nothing at all.
     */
    private static void gripStep(ServerLevel level, List<ServerPlayer> players) {
        for (ServerPlayer player : players) {
            if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
                continue;
            }
            if (!WrathData.stageOf(level.getServer(), player.getUUID()).huntsPlayers()) {
                continue;
            }
            BlockPos feet = player.blockPosition();
            if (!level.isLoaded(feet)) {
                continue;
            }
            int roots = 0;
            for (int dx = -1; dx <= 1; dx++) {
                for (int dz = -1; dz <= 1; dz++) {
                    if (isRhizome(level.getBlockState(feet.offset(dx, -1, dz)))) {
                        roots++;
                    }
                }
            }
            if (isRhizome(level.getBlockState(feet))) {
                roots += 2; // Standing in it, not on it.
            }
            if (roots < 3 || Skills.has(player, Skill.SURE_FOOT)) {
                continue; // Open ground, one root you stepped over, or you have learned to walk on it.
            }
            // Long enough to outlast the gaps between roots, and only ever one level of slowness.
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 70, 0, true, false, false));
        }
    }

    /** Gives a tip the blocks and saplings it is owed and spends them. Returns false when the tip is finished. */
    private static boolean advance(ServerLevel level, ForestDirector.LevelState st, WrathData.Tip tip,
                                   List<ServerPlayer> players, Stage stage, long now) {
        long dayTime = level.getDayTime();
        if (tip.lastGameTime < 0L) {
            tip.lastGameTime = now;
            tip.lastDayTime = dayTime;
        }
        long elapsed = Math.max(now - tip.lastGameTime, dayTime - tip.lastDayTime);
        tip.lastGameTime = now;
        tip.lastDayTime = dayTime;
        if (elapsed > 0L) {
            float days = Math.min(elapsed, 24000L) / 24000.0F;
            tip.budget = ForestDirector.accrue(tip.budget, stage.rhizomeBlocksPerDay, days);
            tip.saplingBudget = ForestDirector.accrue(tip.saplingBudget, stage.tipSaplingsPerDay(), days);
        }

        if (tip.saplingBudget >= 1.0F) {
            tip.saplingBudget -= 1.0F;
            sprout(level, st, tip, stage, now);
        }

        // Roots move in surges now, not a block at a time.
        int steps = Math.min((int) tip.budget, 12);
        for (int i = 0; i < steps; i++) {
            tip.budget -= 1.0F;
            if (!step(level, st, tip, players, stage, now)) {
                return false;
            }
        }

        int maxLength = Config.MAX_RHIZOME_LENGTH.get();
        if (maxLength > 0 && tip.length >= maxLength) {
            sprout(level, st, tip, stage, now); // One last sapling where it ends.
            return false;
        }
        return true;
    }

    /** Each tip grows a sapling above itself (or right beside itself). */
    private static void sprout(ServerLevel level, ForestDirector.LevelState st, WrathData.Tip tip, Stage stage, long now) {
        if (!ForestDirector.roomForMoreTrees(st)) {
            return;
        }
        Species species = ForestDirector.lookupSpecies(tip.species);
        if (species == null) {
            return;
        }
        if (ForestDirector.trySprout(level, st, species, tip.pos.above(2), 2, stage, now)) {
            return;
        }
        for (Direction side : Direction.Plane.HORIZONTAL) {
            if (ForestDirector.trySprout(level, st, species, tip.pos.relative(side).above(2), 2, stage, now)) {
                return;
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Moving a tip one block
    // ------------------------------------------------------------------------------------------------------------

    /** Grows the rhizome by one block. Returns false if the tip is finished (blocked in, or became a tendril). */
    private static boolean step(ServerLevel level, ForestDirector.LevelState st, WrathData.Tip tip,
                                List<ServerPlayer> players, Stage stage, long now) {
        RandomSource random = level.random;
        refreshTarget(level, st, tip, players, stage, now);

        BlockPos pos = tip.pos;
        BlockPos target = tip.target;
        Direction dir;

        if (target != null) {
            int dx = target.getX() - pos.getX();
            int dy = target.getY() - pos.getY();
            int dz = target.getZ() - pos.getZ();
            int flat = Math.abs(dx) + Math.abs(dz);

            if (tip.targetIsPlayer) {
                if (flat <= 2 && !stage.hasTendrils()) {
                    tip.target = null; // Close enough to reach, but not angry enough to strike yet.
                    return true;
                }
                if (flat <= 2) {
                    if (dy >= 0 && dy <= 5) {
                        // Right under (or beside) the player: surface and attack.
                        st.tendrils.add(new Tendril(pos, Mth.clamp(dy + 2, 3, 6)));
                        burst(level, pos.above());
                        return false;
                    }
                    // The player is far above or below: go straight up or down through whatever is there.
                    return moveTo(level, tip, dy > 0 ? pos.above() : pos.below(), null);
                }
            } else {
                if (flat + Math.abs(dy) <= 1) {
                    smother(level, st, target, random);
                    tip.target = null;
                    tip.targetChecked = -1000L;
                    return true;
                }
                if (flat <= 1) {
                    return moveTo(level, tip, dy > 0 ? pos.above() : pos.below(), null);
                }
            }
            Direction towards = horizontalTowards(pos, target, random);
            dir = towards != null ? towards : tip.dir;
        } else {
            // Nothing to chase: wander, mostly straight on.
            float roll = random.nextFloat();
            dir = roll < 0.7F ? tip.dir : (roll < 0.85F ? tip.dir.getClockWise() : tip.dir.getCounterClockWise());
        }

        // Try the chosen direction, then to the right of it, then to the left.
        Direction[] options = {dir, dir.getClockWise(), dir.getCounterClockWise()};
        for (Direction option : options) {
            BlockPos next = followGround(level, pos, option);
            if (moveTo(level, tip, next, next.getY() == pos.getY() ? option : null)) {
                return true;
            }
        }
        return false; // Boxed in on every side.
    }

    /**
     * Picks the next block in the given direction while keeping the rhizome buried about one block deep:
     * it sinks when the ground falls away and rises when it gets too deep.
     */
    private static BlockPos followGround(ServerLevel level, BlockPos pos, Direction dir) {
        BlockPos ahead = pos.relative(dir);
        boolean aheadOpen = isOpen(level.getBlockState(ahead));
        boolean belowOpen = isOpen(level.getBlockState(pos.below()));
        boolean aboveAheadOpen = isOpen(level.getBlockState(ahead.above()));
        int cover = Math.max(1, Config.RHIZOME_DEPTH.get());

        if (aheadOpen) {
            // The ground drops away in front: go down to stay inside it, or bridge the gap if there is
            // nothing below either.
            return belowOpen ? ahead : pos.below();
        }
        if (aboveAheadOpen) {
            // We would come out into daylight: duck down first rather than surfacing.
            return belowOpen ? ahead : pos.below();
        }
        // Count how much ground is over us. It only climbs back up when it is buried deeper than it wants,
        // and it will dive when it is running too shallow, so the line curves down as readily as up.
        int over = 0;
        while (over < cover + 3 && !isOpen(level.getBlockState(pos.above(over + 1)))) {
            over++;
        }
        if (over > cover + 2) {
            return pos.above(); // Too deep. Work back toward the roots.
        }
        if (over < cover && !isOpen(level.getBlockState(pos.below()))) {
            return pos.below(); // Running too close to the surface. Dive.
        }
        return ahead;
    }

    /** Moves the tip into next if that block can be burrowed through. */
    private static boolean moveTo(ServerLevel level, WrathData.Tip tip, BlockPos next, @Nullable Direction newDir) {
        if (next.getY() <= level.getMinBuildHeight() + 1 || next.getY() >= level.getMaxBuildHeight() - 1 || !level.isLoaded(next)) {
            return false;
        }
        BlockState state = level.getBlockState(next);
        if (!isRhizome(state)) {
            if (!canBurrow(level, next, state)) {
                return false;
            }
            Kudzu.clearForRhizome(level, next);
            place(level, next, state);
            if (level.random.nextInt(3) == 0) {
                Sounds.play(level, next, Sounds.ROOTS_BREAK, SoundSource.BLOCKS, 0.7F, 0.5F);
            }
        }
        tip.pos = next;
        tip.length++;
        if (newDir != null) {
            tip.dir = newDir;
        }
        return true;
    }

    /** The horizontal direction that closes the larger gap to the target (with a little wobble), or null if on top of it. */
    @Nullable
    private static Direction horizontalTowards(BlockPos from, BlockPos to, RandomSource random) {
        int dx = to.getX() - from.getX();
        int dz = to.getZ() - from.getZ();
        if (dx == 0 && dz == 0) {
            return null;
        }
        boolean alongX = Math.abs(dx) >= Math.abs(dz);
        if (dx != 0 && dz != 0 && random.nextFloat() < 0.2F) {
            alongX = !alongX;
        }
        if (alongX) {
            return dx > 0 ? Direction.EAST : Direction.WEST;
        }
        return dz > 0 ? Direction.SOUTH : Direction.NORTH;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Targets
    // ------------------------------------------------------------------------------------------------------------

    private static void refreshTarget(ServerLevel level, ForestDirector.LevelState st, WrathData.Tip tip,
                                      List<ServerPlayer> players, Stage stage, long now) {
        if (now - tip.targetChecked < 40L) {
            return;
        }
        tip.targetChecked = now;
        tip.target = null;
        tip.targetIsPlayer = false;

        ServerPlayer prey = huntedPlayer(level, players, tip.pos);
        if (prey != null) {
            tip.target = prey.blockPosition();
            tip.targetIsPlayer = true;
            return;
        }
        if (stage.huntsLight()) {
            tip.target = nearestTorch(level, st, tip.pos);
        }
    }

    /** The nearest player the forest has a real grievance with - others are walked past. */
    @Nullable
    static ServerPlayer huntedPlayer(ServerLevel level, List<ServerPlayer> players, BlockPos from) {
        ServerPlayer best = null;
        double bestDistSq = PLAYER_SEEK_RANGE * PLAYER_SEEK_RANGE;
        for (ServerPlayer player : players) {
            if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
                continue;
            }
            if (!WoodsGear.softened(player, WrathData.stageOf(level.getServer(), player.getUUID())).huntsPlayers()) {
                continue;
            }
            double distSq = player.blockPosition().distSqr(from);
            if (distSq <= bestDistSq) {
                bestDistSq = distSq;
                best = player;
            }
        }
        return best;
    }

    @Nullable
    static BlockPos nearestTorch(ServerLevel level, ForestDirector.LevelState st, BlockPos from) {
        BlockPos best = null;
        double bestDistSq = TORCH_SEEK_RANGE * TORCH_SEEK_RANGE;
        Iterator<BlockPos> iterator = st.torches.iterator();
        while (iterator.hasNext()) {
            BlockPos torch = iterator.next();
            double distSq = torch.distSqr(from);
            if (distSq > bestDistSq) {
                continue;
            }
            if (!level.isLoaded(torch) || !level.getBlockState(torch).is(VengefulWoods.LIGHT_TARGETS)) {
                iterator.remove(); // It is gone already.
                continue;
            }
            bestDistSq = distSq;
            best = torch;
        }
        return best;
    }

    /** A rhizome reached a torch: half the time it knocks it off, half the time it grows right over it. */
    private static void smother(ServerLevel level, ForestDirector.LevelState st, BlockPos torchPos, RandomSource random) {
        st.torches.remove(torchPos);
        BlockState state = level.getBlockState(torchPos);
        if (!state.is(VengefulWoods.LIGHT_TARGETS)) {
            return;
        }
        if (random.nextBoolean()) {
            level.destroyBlock(torchPos, true);
        } else {
            level.setBlock(torchPos, VengefulWoods.RHIZOME.get().defaultBlockState(), 3);
        }
        burst(level, torchPos);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Stage 5: tendrils
    // ------------------------------------------------------------------------------------------------------------

    private static void tickTendrils(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players) {
        Iterator<Tendril> iterator = st.tendrils.iterator();
        while (iterator.hasNext()) {
            Tendril tendril = iterator.next();
            tendril.age += 5;
            if (!level.isLoaded(tendril.base) || tendril.age > TENDRIL_LIFETIME) {
                iterator.remove();
                continue;
            }

            // Rise one block at a time, smashing what is beside it.
            if (tendril.height < tendril.maxHeight) {
                BlockPos next = tendril.base.above(tendril.height + 1);
                BlockState state = level.getBlockState(next);
                if (next.getY() < level.getMaxBuildHeight() - 1 && (isRhizome(state) || canBurrow(level, next, state))) {
                    place(level, next, state);
                    tendril.height++;
                    wreck(level, next);
                    burst(level, next);
                } else {
                    tendril.maxHeight = tendril.height;
                }
            }

            // Lash out twice a second.
            if (tendril.age % 10 == 0) {
                lash(level, tendril, players);
            }
        }
    }

    /** Breaks built blocks right beside a rising tendril ("base blocks"). Natural ground is left alone. */
    private static void wreck(ServerLevel level, BlockPos pos) {
        if (!Config.RHIZOMES_BREAK_BUILDS.get()) {
            return;
        }
        for (Direction side : Direction.Plane.HORIZONTAL) {
            BlockPos beside = pos.relative(side);
            BlockState state = level.getBlockState(beside);
            if (state.isAir() || isRhizome(state) || isNaturalGround(state)) {
                continue;
            }
            if (canBurrow(level, beside, state) && level.random.nextFloat() < 0.6F) {
                level.destroyBlock(beside, true);
            }
        }
    }

    private static void lash(ServerLevel level, Tendril tendril, List<ServerPlayer> players) {
        AABB reach = new AABB(tendril.base).expandTowards(0.0, tendril.height + 1.0, 0.0).inflate(2.0, 1.0, 2.0);
        for (ServerPlayer player : players) {
            if (player.isCreative() || player.isSpectator() || !player.isAlive() || !reach.contains(player.position())) {
                continue;
            }
            Stage stage = WoodsGear.softened(player, WrathData.stageOf(level.getServer(), player.getUUID()));
            if (!stage.hasTendrils()) {
                continue; // It has no quarrel with this one.
            }
            float damage = Config.TENDRIL_DAMAGE.get().floatValue() * stage.tendrilDamageFactor();
            DamageSource damageSource = tendrilDamage(level);
            if (damage > 0.0F && damageSource != null) {
                player.hurt(damageSource, damage);
            }
            // Roots wrap around their legs.
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            Sounds.play(level, player.blockPosition(), Sounds.WOOD_BREAK, SoundSource.HOSTILE, 1.0F, 0.4F);
        }
    }

    @Nullable
    static DamageSource tendrilDamage(ServerLevel level) {
        try {
            return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(TENDRIL_DAMAGE));
        } catch (RuntimeException e) {
            // The mod's own damage type should always be there; if something removed it, fall back to a plain one.
            try {
                return level.damageSources().generic();
            } catch (RuntimeException ignored) {
                return null;
            }
        }
    }
}
