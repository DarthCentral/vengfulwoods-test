package com.vengefulwoods;

import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.block.Block;

import javax.annotation.Nullable;

/** A plant you can put back in the ground or put in the fire. Sweetgrass is both. */
public class FuelBlockItem extends BlockItem {

    private final int burnTicks;

    public FuelBlockItem(Block block, int burnTicks) {
        super(block, new Item.Properties());
        this.burnTicks = burnTicks;
    }

    @Override
    public int getBurnTime(ItemStack stack, @Nullable RecipeType<?> recipeType) {
        return burnTicks;
    }
}
