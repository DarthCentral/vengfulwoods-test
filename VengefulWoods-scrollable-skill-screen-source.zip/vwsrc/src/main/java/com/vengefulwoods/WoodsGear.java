package com.vengefulwoods;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;

/**
 * Heartwood gear. The armour is grown rather than forged, and the forest knows its own: a player wearing the
 * full set is treated as one step less hated than they really are.
 */
public enum WoodsGear implements ArmorMaterial {

    /**
     * Grown, given, and recognised by the forest as its own. It protects better than diamond and takes
     * enchantment better than anything, but it is living wood and it wears: the forest expects you to come
     * back for more, which is the point of it.
     */
    HEARTWOOD(26, new int[]{3, 7, 8, 3}, 22, 2.5F),
    /**
     * Woven: wisteria withy laid over a little iron. The vine is strong enough to pull a mature oak over,
     * and worked flat it turns a blade better than plate does. Thorns cannot find you through it either.
     */
    WOVEN(24, new int[]{3, 6, 7, 3}, 15, 1.0F);

    /**
     * The tier heartwood tools are cut at. It mines what iron mines - the forest has no interest in your
     * obsidian - but it bites harder than diamond and takes enchantment better than anything you could
     * forge, because what you are holding is a piece of something that was alive and is still angry.
     */
    public static final Tier HEARTWOOD_TIER = new Tier() {
        public int getUses() {
            return 1100;
        }

        public float getSpeed() {
            return 7.5F;
        }

        public float getAttackDamageBonus() {
            return 3.5F;
        }

        public int getLevel() {
            return 2; // Iron's reach. Heartwood is not a pickaxe material.
        }

        public int getEnchantmentValue() {
            return 22;
        }

        public Ingredient getRepairIngredient() {
            return Ingredient.of(VengefulWoods.HEARTWOOD.get());
        }
    };

    private static final int[] DURABILITY = {13, 15, 16, 11};
    /** Knockback resistance. Heartwood is heavy: things bounce off it. */
    private static final float HEARTWOOD_KNOCKBACK = 0.1F;

    private final int durabilityFactor;
    private final int[] protection;
    private final int enchantmentValue;
    private final float toughness;

    WoodsGear(int durabilityFactor, int[] protection, int enchantmentValue, float toughness) {
        this.durabilityFactor = durabilityFactor;
        this.protection = protection;
        this.enchantmentValue = enchantmentValue;
        this.toughness = toughness;
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return DURABILITY[Math.min(type.ordinal(), DURABILITY.length - 1)] * durabilityFactor;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return protection[Math.min(type.ordinal(), protection.length - 1)];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantmentValue;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return this == HEARTWOOD
                ? Ingredient.of(VengefulWoods.HEARTWOOD.get())
                : Ingredient.of(VengefulWoods.WISTERIA.get());
    }

    @Override
    public String getName() {
        return VengefulWoods.MODID + ":" + (this == HEARTWOOD ? "heartwood" : "woven");
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return this == HEARTWOOD ? HEARTWOOD_KNOCKBACK : 0.0F;
    }

    /** True if every piece being worn is of this material. */
    public static boolean fullSet(Player player, WoodsGear material) {
        for (ItemStack stack : player.getArmorSlots()) {
            if (!(stack.getItem() instanceof ArmorItem armor) || armor.getMaterial() != material) {
                return false;
            }
        }
        return true;
    }

    /** Woven armour turns thorns. Anyone wearing a full set walks through a blackberry thicket unscratched. */
    public static boolean turnsThorns(Player player) {
        for (ItemStack stack : player.getArmorSlots()) {
            if (stack.getItem() instanceof ArmorItem armor && armor.getMaterial() == WOVEN) {
                return true;
            }
        }
        return false;
    }

    /**
     * How angry the forest acts toward this player, allowing for what they are wearing. Heartwood takes the
     * edge off by one stage - enough to matter, never enough to make you safe.
     */
    public static Stage softened(Player player, Stage stage) {
        if (!Config.ARMOUR_SOFTENS.get() || stage == Stage.DORMANT || !fullSet(player, HEARTWOOD)) {
            return stage;
        }
        return Stage.values()[Math.max(0, stage.ordinal() - 1)];
    }
}
