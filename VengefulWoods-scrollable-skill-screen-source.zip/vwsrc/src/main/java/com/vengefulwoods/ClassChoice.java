package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.DispenserMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;

/**
 * Choosing what you are.
 * <p>
 * Three things are laid out in a ring:
 * <pre>
 *     .    Druid    .
 *  Colonialist  ( )  Invader
 *     .      .      .
 * </pre>
 * The space in the middle of them is not empty. Nothing says so.
 */
public class ClassChoice {

    /** Grid slots, in a 3x3: top-middle, left-middle, right-middle, and the hole in the centre. */
    private static final int DRUID_SLOT = 1;
    private static final int COLONIALIST_SLOT = 3;
    private static final int HIDDEN_SLOT = 4;
    private static final int INVADER_SLOT = 5;

    /** Players who have logged in without a class yet, waiting a moment before the choice is put to them. */
    private static final List<Pending> WAITING = new ArrayList<>();

    private record Pending(ServerPlayer player, long when) {
    }

    public static void clear() {
        WAITING.clear();
    }

    // ------------------------------------------------------------------------------------------------------------
    // The menu
    // ------------------------------------------------------------------------------------------------------------

    private static SimpleContainer tokens() {
        SimpleContainer container = new SimpleContainer(9);
        container.setItem(DRUID_SLOT, named(new ItemStack(VengefulWoods.TRILLIUM_BLOOM.get()), WoodsClass.DRUID));
        container.setItem(COLONIALIST_SLOT, named(new ItemStack(Items.FLINT_AND_STEEL), WoodsClass.COLONIALIST));
        container.setItem(INVADER_SLOT, named(new ItemStack(VengefulWoods.KUDZU_ITEM.get()), WoodsClass.INVADER));
        return container;
    }

    private static ItemStack named(ItemStack stack, WoodsClass chosen) {
        stack.setHoverName(Component.translatable(chosen.key()).withStyle(ChatFormatting.GREEN));
        return stack;
    }

    /**
     * A dispenser grid the player cannot actually take anything out of. Every click on the grid is read as a
     * choice and nothing else, which is also what lets the empty middle slot mean something.
     */
    private static final class Menu extends DispenserMenu {

        private final ServerPlayer player;

        private Menu(int id, Inventory inventory, SimpleContainer container, ServerPlayer player) {
            super(id, inventory, container);
            this.player = player;
        }

        @Override
        public void clicked(int slotId, int dragType, ClickType clickType, Player clicker) {
            if (slotId < 0 || slotId > 8) {
                super.clicked(slotId, dragType, clickType, clicker);
                return;
            }
            WoodsClass chosen;
            switch (slotId) {
                case DRUID_SLOT:
                    chosen = WoodsClass.DRUID;
                    break;
                case COLONIALIST_SLOT:
                    chosen = WoodsClass.COLONIALIST;
                    break;
                case INVADER_SLOT:
                    chosen = WoodsClass.INVADER;
                    break;
                case HIDDEN_SLOT:
                    chosen = WoodsClass.MUSHROOM;
                    break;
                default:
                    return; // The corners are nothing. Clicking them does nothing.
            }
            choose(player, chosen);
            player.closeContainer();
        }

        @Override
        public boolean stillValid(Player clicker) {
            return true;
        }
    }

    private static final class Provider implements MenuProvider {

        private final ServerPlayer player;

        private Provider(ServerPlayer player) {
            this.player = player;
        }

        @Override
        public Component getDisplayName() {
            return Component.translatable("container.vengefulwoods.choice");
        }

        @Nullable
        @Override
        public AbstractContainerMenu createMenu(int id, Inventory inventory, Player clicker) {
            return new Menu(id, inventory, tokens(), player);
        }
    }

    /** Puts the choice in front of a player. */
    public static void open(ServerPlayer player) {
        net.minecraftforge.network.NetworkHooks.openScreen(player, new Provider(player));
    }

    /** True while this player still has not decided, which is when the altar offers the choice instead. */
    public static boolean undecided(ServerPlayer player) {
        return player.getServer() != null
                && WrathData.global(player.getServer()).own(player.getUUID()).woodsClass() == WoodsClass.NONE;
    }

    private static void choose(ServerPlayer player, WoodsClass chosen) {
        if (player.getServer() == null) {
            return;
        }
        WrathData.global(player.getServer()).setClass(player.getUUID(), chosen);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.chose",
                Component.translatable(chosen.key())).withStyle(ChatFormatting.DARK_GREEN), false);
        player.displayClientMessage(Component.translatable(chosen.key() + ".desc")
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), false);
        if (chosen == WoodsClass.MUSHROOM) {
            // Nobody is told this is here, so whoever found it should be told they found something.
            Sounds.play(player.serverLevel(), player.blockPosition(), Sounds.ROOTS_BREAK,
                    net.minecraft.sounds.SoundSource.PLAYERS, 1.0F, 0.5F);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Catching people as they arrive
    // ------------------------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (!Config.CLASSES_ENABLED.get() || !(event.getEntity() instanceof ServerPlayer player)) {
            return;
        }
        if (!undecided(player)) {
            return;
        }
        // A beat before the choice appears, so it does not fight with the world still loading in.
        WAITING.add(new Pending(player, player.serverLevel().getGameTime() + 60L));
    }

    /**
     * Opens the menu for anyone whose moment has come, and picks up anybody the login event missed.
     * <p>
     * The sweep matters: this used to hang entirely off the login event, and if that was missed - or if the
     * code that ran it was gated behind something else, which it was - an undecided player simply never got
     * asked and the whole class system was invisible. Now the world checks every five seconds for anyone
     * still unchosen, every thirty seconds, and puts it to them again.
     */
    static void tick(net.minecraft.server.level.ServerLevel level,
                     java.util.List<ServerPlayer> players, long now) {
        if (!Config.CLASSES_ENABLED.get()) {
            return;
        }
        if (now % 600L == 0L) {
            for (ServerPlayer player : players) {
                if (!player.isAlive() || !undecided(player)) {
                    continue;
                }
                boolean queued = false;
                for (Pending pending : WAITING) {
                    if (pending.player() == player) {
                        queued = true;
                        break;
                    }
                }
                if (!queued) {
                    WAITING.add(new Pending(player, now + 40L));
                }
            }
        }
        if (WAITING.isEmpty()) {
            return;
        }
        WAITING.removeIf(pending -> {
            if (now < pending.when()) {
                return false;
            }
            ServerPlayer player = pending.player();
            if (player.isAlive() && undecided(player)) {
                player.displayClientMessage(Component.translatable("message.vengefulwoods.choose_prompt")
                        .withStyle(ChatFormatting.DARK_GREEN), false);
                open(player);
            }
            return true;
        });
    }
}
