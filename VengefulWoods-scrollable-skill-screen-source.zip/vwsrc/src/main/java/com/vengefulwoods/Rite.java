package com.vengefulwoods;

import net.minecraft.world.item.Item;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * Everything an altar can be asked to do.
 * <p>
 * Four are open to anyone, two are the bad bargains, and the last one belongs to whatever you chose to be.
 * The charms still work if you would rather hold one and use the stone directly; the list is simply so that
 * you can see what is on offer and what it costs without having to already know.
 */
public enum Rite {

    GROVES("groves", null, 0, () -> VengefulWoods.GROVE_CHARM.get()),
    ROOTS("roots", null, 0, () -> VengefulWoods.ROOT_TOTEM.get()),
    BARGAIN("bargain", null, 0, () -> VengefulWoods.BARGAIN_IDOL.get()),
    SEEDING("seeding", null, -1, () -> VengefulWoods.SEEDBED_CHARM.get()),
    QUIET("quiet", null, -2, () -> VengefulWoods.FERTILIZER.get()),
    BLIGHT("blight", null, -3, () -> VengefulWoods.BLIGHT_SEED.get()),

    THORNS("thorns", WoodsClass.DRUID, 120, () -> VengefulWoods.GROVE_CHARM.get()),
    ASH("ash", WoodsClass.COLONIALIST, 90, () -> VengefulWoods.HEARTWOOD_AXE.get()),
    SWARM("swarm", WoodsClass.INVADER, 220, () -> VengefulWoods.SEEDBED_CHARM.get()),
    ORIGINAL("original", WoodsClass.MUSHROOM, -4, () -> VengefulWoods.SPORE_IDOL.get());

    private final String id;
    @Nullable
    public final WoodsClass only;
    /** A flat tribute price, or a negative marker for one that has to be worked out at the altar. */
    private final int price;
    private final Supplier<Item> icon;

    Rite(String id, @Nullable WoodsClass only, int price, Supplier<Item> icon) {
        this.id = id;
        this.only = only;
        this.price = price;
        this.icon = icon;
    }

    public String key() {
        return "rite.vengefulwoods." + id;
    }

    public Item icon() {
        return icon.get();
    }

    /** What this costs right now, for this player. -1 means it depends on where they are standing. */
    public int cost(net.minecraft.world.entity.player.Player player) {
        switch (this) {
            case SEEDING:
                return -1; // Whatever the ground here answers with.
            case QUIET:
                return Config.RITE_QUIET_COST.get();
            case BLIGHT:
                return (int) Math.round(Config.TRIBUTE_KUDZU.get() * WoodsClass.riteCostRate(player));
            case ORIGINAL:
                return Config.MUSHROOM_ORIGINAL_COST.get();
            default:
                return price;
        }
    }

    public boolean openTo(WoodsClass chosen) {
        return only == null || only == chosen;
    }

    /** Every rite this player may be shown, in the order they are listed. */
    public static List<Rite> forClass(WoodsClass chosen) {
        List<Rite> open = new ArrayList<>();
        for (Rite rite : values()) {
            if (rite.openTo(chosen)) {
                open.add(rite);
            }
        }
        return open;
    }
}
