package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.util.RandomSource;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * What the Druid and the Colonialist actually get for their trouble.
 * <p>
 * The Druid is paid in the forest's goodwill and can point it at something. The Colonialist is paid in
 * timber and fire for doing the one thing the forest cannot forgive, and is strongest standing in ground he
 * has already cleared - which is a problem, because the forest's entire purpose is that there is less of
 * that every day.
 */
public class Classes {

    /** What the woods have been told to kill, when they were told, and by whom. */
    private static final Map<UUID, Long> MARKED = new HashMap<>();
    private static final Map<UUID, UUID> MARKED_BY = new HashMap<>();

    public static void clear() {
        MARKED.clear();
        MARKED_BY.clear();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Druid: marking something for the trees
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Use a grove charm on a living thing and the forest takes an interest in it. Nothing is consumed: the
     * charm is a pointer, not a payment. What happens next is whatever the trees nearby are capable of,
     * which at the low stages is very little and later is a tree coming down on its head.
     */
    /** An empty hand thrown at nothing is the Mushroom's cloud. */
    @SubscribeEvent
    public void onEmptySwing(PlayerInteractEvent.RightClickItem event) {
        if (!(event.getEntity() instanceof ServerPlayer player)
                || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        if (WoodsClass.of(player) != WoodsClass.MUSHROOM || !player.getItemInHand(event.getHand()).isEmpty()) {
            return;
        }
        Mushroom.sporeCloud(level, player);
    }

    @SubscribeEvent
    public void onMark(PlayerInteractEvent.EntityInteract event) {
        Player player = event.getEntity();
        if (player.level().isClientSide() || !(player instanceof ServerPlayer marker)) {
            return;
        }
        if (WoodsClass.of(marker) != WoodsClass.DRUID || !Skills.has(marker, Skill.MARKING)) {
            return;
        }
        // An empty hand is the whole gesture. You point at it.
        ItemStack stack = player.getItemInHand(event.getHand());
        if (!stack.isEmpty()) {
            return;
        }
        Entity target = event.getTarget();
        if (!(target instanceof LivingEntity living) || living == player) {
            return;
        }
        mark(marker.serverLevel(), living);
        MARKED_BY.put(living.getUUID(), marker.getUUID());
        marker.displayClientMessage(Component.translatable("message.vengefulwoods.marked",
                living.getName()).withStyle(ChatFormatting.DARK_GREEN), true);
        event.setCancellationResult(InteractionResult.SUCCESS);
        event.setCanceled(true);
    }

    static void mark(ServerLevel level, LivingEntity target) {
        MARKED.put(target.getUUID(), level.getGameTime());
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER,
                target.getX(), target.getY() + 1.0, target.getZ(), 14, 0.4, 0.6, 0.4, 0.02);
        Sounds.play(level, target.blockPosition(), Sounds.ROOTS_BREAK,
                net.minecraft.sounds.SoundSource.HOSTILE, 0.8F, 1.4F);
    }

    /**
     * What the woods do about a mark, each second it stands.
     * <p>
     * At the first rank it is only a pointer: the trees go for it the way they would go for anything they
     * dislike. At the second, branches reach out over it and come down. At the third, root comes up
     * underneath and takes it into the ground.
     */
    static void workMarks(ServerLevel level, long now) {
        if (MARKED.isEmpty() || now % 20L != 0L) {
            return;
        }
        for (java.util.Map.Entry<UUID, UUID> entry : new java.util.HashMap<>(MARKED_BY).entrySet()) {
            ServerPlayer marker = level.getServer() == null ? null
                    : level.getServer().getPlayerList().getPlayer(entry.getValue());
            int rank = Skills.rank(marker, Skill.MARKING);
            if (rank < 2) {
                continue;
            }
            for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                    new net.minecraft.world.phys.AABB(marker == null ? BlockPos.ZERO : marker.blockPosition())
                            .inflate(40.0))) {
                if (!target.getUUID().equals(entry.getKey()) || !isMarked(level, target)) {
                    continue;
                }
                BlockPos at = target.blockPosition();
                // Branches over its head, brought down on it.
                Treefall.canopyDropOn(level, at);
                if (rank >= 3) {
                    // And root up through the floor, to take it down into the ground.
                    Rhizomes.burst(level, at);
                    target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 3,
                            true, false, false));
                    if (level.getBlockState(at.below()).isAir() || level.random.nextInt(3) == 0) {
                        target.teleportTo(target.getX(), target.getY() - 1.0, target.getZ());
                    }
                    net.minecraft.world.damagesource.DamageSource source = Rhizomes.tendrilDamage(level);
                    if (source != null) {
                        target.hurt(source, 2.0F * rank);
                    }
                }
            }
        }
    }

    /** True while the forest is still angry at this thing on somebody else's behalf. */
    public static boolean isMarked(ServerLevel level, LivingEntity target) {
        Long when = MARKED.get(target.getUUID());
        if (when == null) {
            return false;
        }
        long life = Config.DRUID_MARK_SECONDS.get() * 20L;
        UUID by = MARKED_BY.get(target.getUUID());
        if (by != null && level.getServer() != null) {
            ServerPlayer marker = level.getServer().getPlayerList().getPlayer(by);
            if (Skills.rank(marker, Skill.MARKING) >= 2) {
                life *= 3L; // It does not lose interest.
            }
        }
        if (level.getGameTime() - when > life) {
            MARKED.remove(target.getUUID());
            return false;
        }
        return true;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Colonialist: the clearing, and the fire
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Paid for felling. Fire and strength, for about as long as it takes to start on the next one, so the
     * way to stay strong is to keep going - which is also the way to make everything worse.
     */
    static void paidForFelling(ServerPlayer player) {
        if (WoodsClass.of(player) != WoodsClass.COLONIALIST) {
            return;
        }
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 400, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 300, 0, true, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 400, 0, true, false, true));
    }

    /**
     * Once a second, for each Colonialist: open ground is his. Standing where there is no tree within the
     * clearing radius he mends and moves quickly; standing under canopy he gets nothing at all.
     */
    static void tick(ServerLevel level, long now) {
        if (now % 40L != 0L || !Config.CLASSES_ENABLED.get()) {
            return;
        }
        int base = Config.COLONIALIST_CLEARING.get();
        for (ServerPlayer player : level.players()) {
            if (WoodsClass.of(player) != WoodsClass.COLONIALIST || !player.isAlive()) {
                continue;
            }
            int clearing = Skills.rank(player, Skill.CLEARING);
            if (clearing <= 0) {
                continue; // Open ground does nothing for you until you have learned to use it.
            }
            int radius = base * clearing;
            if (treeNear(level, player.blockPosition(), radius)) {
                continue; // Under their branches, he is nobody.
            }
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, clearing - 1,
                    true, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 60, clearing - 1,
                    true, false, true));
        }

        wildfireStep(level, now);
        workMarks(level, now);

        // A Druid who has learned it is mended by any canopy at all, whatever the forest thinks of them.
        for (ServerPlayer player : level.players()) {
            if (Skills.has(player, Skill.GROVEBORN) && player.isAlive()
                    && treeNear(level, player.blockPosition(), 10)) {
                player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, 0, true, false, true));
            }
        }
    }

    private static boolean treeNear(ServerLevel level, BlockPos centre, int radius) {
        int step = Math.max(2, radius / 4);
        for (int dx = -radius; dx <= radius; dx += step) {
            for (int dz = -radius; dz <= radius; dz += step) {
                for (int dy = -4; dy <= 8; dy += 4) {
                    BlockPos pos = centre.offset(dx, dy, dz);
                    if (level.isLoaded(pos) && TreeHelper.isBranch(level.getBlockState(pos))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * The Mushroom is hard to actually land anything on.
     * <p>
     * Half of everything aimed at it does not connect - the blow goes through where it was a moment ago.
     * Nothing is blocked or reduced: it simply misses.
     */
    @SubscribeEvent
    public void onHurt(net.minecraftforge.event.entity.living.LivingHurtEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || !Config.CLASSES_ENABLED.get()) {
            return;
        }
        if (WoodsClass.of(player) != WoodsClass.MUSHROOM) {
            return;
        }
        int rank = Skills.rank(player, Skill.SPOREBORNE);
        if (rank <= 0) {
            return; // Not learned. Everything lands.
        }
        double chance = Math.min(0.85, Config.MUSHROOM_DODGE.get() * rank / 3.0 + 0.1 * rank);
        if (chance <= 0.0 || player.serverLevel().random.nextDouble() >= chance) {
            return;
        }
        event.setCanceled(true);
        player.serverLevel().sendParticles(net.minecraft.core.particles.ParticleTypes.PORTAL,
                player.getX(), player.getY() + 1.0, player.getZ(), 10, 0.3, 0.5, 0.3, 0.2);
    }

    /**
     * The axe, out in the open.
     * <p>
     * Standing clear of the trees a Colonialist's axe hits harder and sets what it hits alight. Under
     * canopy it is an ordinary axe, which is the whole bargain of the class in one swing.
     */
    @SubscribeEvent
    public void onSwing(net.minecraftforge.event.entity.living.LivingHurtEvent event) {
        if (!(event.getSource().getEntity() instanceof ServerPlayer player)) {
            return;
        }
        int rank = Skills.rank(player, Skill.EMBER_AXE);
        if (rank <= 0 || WoodsClass.of(player) != WoodsClass.COLONIALIST) {
            return;
        }
        if (!(player.getMainHandItem().getItem() instanceof net.minecraft.world.item.AxeItem)) {
            return;
        }
        if (!(player.level() instanceof ServerLevel level)) {
            return;
        }
        int radius = Config.COLONIALIST_CLEARING.get()
                * Math.max(1, Skills.rank(player, Skill.CLEARING));
        if (treeNear(level, player.blockPosition(), radius)) {
            return; // No. Not here.
        }
        event.setAmount(event.getAmount() + 2.0F * rank);
        event.getEntity().setSecondsOnFire(2 + rank * 2);
        level.sendParticles(net.minecraft.core.particles.ParticleTypes.FLAME,
                event.getEntity().getX(), event.getEntity().getY() + 1.0, event.getEntity().getZ(),
                10 + rank * 6, 0.3, 0.5, 0.3, 0.02);
    }

    /** The Colonialist's fire takes hold in wood far more readily than anyone else's. */
    static boolean burnsHot(ServerLevel level, BlockPos pos) {
        if (!Config.CLASSES_ENABLED.get()) {
            return false;
        }
        for (ServerPlayer player : level.players()) {
            if (Skills.has(player, Skill.WILDFIRE)
                    && player.blockPosition().distSqr(pos) < 64.0 * 64.0) {
                return true;
            }
        }
        return false;
    }

    /**
     * Wildfire: a Colonialist who has learned it burns the forest's own works out of the ground. Root and
     * standing timber near them catch and go, which nothing else in the mod can do.
     */
    static void wildfireStep(ServerLevel level, long now) {
        if (now % 40L != 0L) {
            return;
        }
        RandomSource random = level.random;
        for (ServerPlayer player : level.players()) {
            int rank = Skills.rank(player, Skill.WILDFIRE);
            if (rank <= 0 || !player.isAlive()) {
                continue;
            }
            if (!player.isOnFire() && !nearFlame(level, player.blockPosition())) {
                continue; // It spreads from fire you are standing in, not from nothing.
            }
            int reach = 6 + rank * 4;
            int taken = 0;
            for (int attempt = 0; attempt < 60 && taken < 3 + rank * 2; attempt++) {
                BlockPos spot = player.blockPosition().offset(random.nextInt(reach * 2) - reach,
                        random.nextInt(9) - 4, random.nextInt(reach * 2) - reach);
                if (!level.isLoaded(spot)) {
                    continue;
                }
                BlockState state = level.getBlockState(spot);
                boolean root = state.is(VengefulWoods.RHIZOME.get());
                boolean branch = com.ferreusveritas.dynamictrees.api.TreeHelper.isBranch(state);
                if (!root && !branch) {
                    continue;
                }
                level.destroyBlock(spot.immutable(), false);
                if (random.nextInt(3) == 0 && level.getBlockState(spot).isAir()) {
                    level.setBlock(spot.immutable(), Blocks.FIRE.defaultBlockState(), 3);
                }
                taken++;
            }
        }
    }

    private static boolean nearFlame(ServerLevel level, BlockPos centre) {
        for (BlockPos pos : BlockPos.betweenClosed(centre.offset(-3, -2, -3), centre.offset(3, 2, 3))) {
            if (level.getBlockState(pos).is(Blocks.FIRE)) {
                return true;
            }
        }
        return false;
    }
}
