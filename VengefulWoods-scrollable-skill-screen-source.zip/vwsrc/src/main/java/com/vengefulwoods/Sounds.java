package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;

/**
 * Sounds are looked up by name instead of being named in code, so a sound that a future Minecraft version
 * renames simply goes quiet instead of breaking the mod.
 */
public final class Sounds {

    public static final String WOOD_BREAK = "block.wood.break";
    public static final String ROOTS_BREAK = "block.rooted_dirt.break";
    public static final String HEARTBEAT = "entity.warden.heartbeat";
    public static final String CURSE = "entity.elder_guardian.curse";
    public static final String GRASS_PLACE = "block.grass.place";

    private Sounds() {
    }

    @Nullable
    public static SoundEvent get(String id) {
        try {
            return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(id));
        } catch (RuntimeException e) {
            return null;
        }
    }

    public static void play(Level level, BlockPos pos, String id, SoundSource source, float volume, float pitch) {
        SoundEvent sound = get(id);
        if (sound != null) {
            level.playSound(null, pos, sound, source, volume, pitch);
        }
    }
}
