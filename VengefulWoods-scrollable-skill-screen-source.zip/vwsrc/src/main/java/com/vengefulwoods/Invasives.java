package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.EnumSet;
import java.util.Set;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Keeps the lesser invasives moving.
 * <p>
 * A patch you planted deliberately behaves exactly like one that got loose, because there is no difference:
 * the only thing that decides whether a bramble hedge is a crop or a disaster is whether you walled it in.
 */
public class Invasives {

    private static final class Runner {
        final Invasive kind;
        BlockPos pos;
        Direction dir;
        int life;
        /** Game time this one may take its next block. Wisteria sets it; the quick weeds leave it alone. */
        long next;

        Runner(Invasive kind, BlockPos pos, Direction dir, int life) {
            this.kind = kind;
            this.pos = pos;
            this.dir = dir;
            this.life = life;
        }
    }

    private static final class Patch {
        final List<Runner> runners = new ArrayList<>();
        int cursor;
        final Map<Invasive, Integer> counts = new EnumMap<>(Invasive.class);
        final Map<Invasive, Long> warned = new EnumMap<>(Invasive.class);
        /** Species that have got away from somebody and are now running wild. */
        final Set<Invasive> rampant = EnumSet.noneOf(Invasive.class);
        /** The players present this tick. Wisteria steers by them; nothing else looks. */
        List<ServerPlayer> present = List.of();
        /** Who let each species out. The forest does not hold it against anybody else. */
        final Map<Invasive, UUID> planter = new EnumMap<>(Invasive.class);
        long lastReckoning;
    }

    private static final Map<ResourceKey<Level>, Patch> PATCHES = new HashMap<>();
    private static final Map<UUID, Integer> CLEARED = new HashMap<>();

    public static void clear() {
        PATCHES.clear();
        CLEARED.clear();
        GRIPPED.clear();
    }

    private static Patch patch(ServerLevel level) {
        return PATCHES.computeIfAbsent(level.dimension(), key -> new Patch());
    }

    @Nullable
    static Invasive kindOf(BlockState state) {
        return state.getBlock() instanceof InvasiveBlock block ? block.kind : null;
    }

    static boolean isInvasive(BlockState state) {
        return state.getBlock() instanceof InvasiveBlock;
    }

    /** A patch that was placed, random-ticked or found by the scan starts running from there. */
    static void awaken(ServerLevel level, BlockPos pos, BlockState state) {
        Invasive kind = kindOf(state);
        if (kind == null || !Config.INVASIVES_ENABLED.get()) {
            return;
        }
        // Every part counts. A cutting is a cutting: a length of woody vine, a spray of flower, a shoot
        // snapped off a cane - put any of it in the ground and the whole plant starts again from there.
        Patch patch = patch(level);
        if (patch.runners.size() >= kind.maxRunners()) {
            return;
        }
        patch.runners.add(new Runner(kind, pos.immutable(),
                Direction.from2DDataValue(level.random.nextInt(4)), Config.INVASIVE_RUNNER_LIFE.get()));
    }

    // ------------------------------------------------------------------------------------------------------------
    // Every tick
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, List<ServerPlayer> players, long now) {
        if (!Config.INVASIVES_ENABLED.get()) {
            return;
        }
        Patch patch = patch(level);
        patch.present = players;
        if (patch.runners.isEmpty()) {
            return;
        }
        int budget = 0;
        for (Invasive kind : Invasive.values()) {
            int rate = kind.spreadPerSecond();
            if (patch.rampant.contains(kind)) {
                rate = (int) (rate * (double) Config.RAMPANT_SPEED.get());
            }
            budget += Math.max(1, rate / 20);
        }
        // The weeds bank what they have in the ground too, and spend it in surges rather than evenly.
        if (now % 20L == 0L) {
            int blocks = 0;
            for (Integer count : patch.counts.values()) {
                blocks += count;
            }
            Biomass.growWeeds(level, Math.max(patch.runners.size(), blocks), 20.0F / 24000.0F);
        }
        budget += Biomass.drawWeeds(level, Math.max(1, budget));
        for (int i = 0; i < budget && !patch.runners.isEmpty(); i++) {
            step(level, patch, now);
        }
        if (now % 20L == 0L && !players.isEmpty()) {
            gripStep(level, players);
        }
        if (now % 40L == 0L) {
            crushStep(level, patch);
        }
        if (now % 200L == 0L && !players.isEmpty()) {
            warnAboutEscapes(level, patch, players, now);
            checkContained(level, patch);
        }
    }

    private static void step(ServerLevel level, Patch patch, long now) {
        if (patch.cursor >= patch.runners.size()) {
            patch.cursor = 0;
        }
        Runner runner = patch.runners.get(patch.cursor);
        BlockState here = level.isLoaded(runner.pos) ? level.getBlockState(runner.pos) : null;
        if (here == null || !runner.kind.isBody(here) || runner.life <= 0) {
            patch.runners.remove(patch.cursor);
            return;
        }
        if (now < runner.next) {
            patch.cursor++; // Still working on the block it is on.
            return;
        }
        if (!advance(level, patch, runner)) {
            runner.life -= 2;
            runner.dir = level.random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise();
        }
        if (runner.kind == Invasive.WISTERIA) {
            runner.next = now + Config.WISTERIA_STEP_TICKS.get();
        }
        patch.cursor++;
    }

    private static boolean advance(ServerLevel level, Patch patch, Runner runner) {
        RandomSource random = level.random;
        Invasive kind = runner.kind;

        Direction steer = kind == Invasive.WISTERIA ? wisteriaSteer(level, patch, runner, random) : null;

        for (int attempt = 0; attempt < 3; attempt++) {
            Direction dir = attempt == 0 ? (steer != null ? steer : runner.dir)
                    : (random.nextBoolean() ? runner.dir.getClockWise() : runner.dir.getCounterClockWise());
            BlockPos ahead = runner.pos.relative(dir);

            // Knotweed drives down through made ground; the rest keep to the surface.
            // A runner that has picked something out deliberately is not talked out of it by any of this.
            boolean deliberate = attempt == 0 && steer != null;
            if (kind == Invasive.KNOTWEED && random.nextInt(4) == 0) {
                ahead = runner.pos.below();
            } else if (!deliberate && kind.climbs() && random.nextInt(3) == 0) {
                ahead = runner.pos.above(); // Wisteria goes up whatever it is holding.
            } else if (!deliberate && random.nextInt(8) == 0) {
                ahead = runner.pos.above();
            }

            if (!level.isLoaded(ahead) || ahead.getY() <= level.getMinBuildHeight() + 1
                    || ahead.getY() >= level.getMaxBuildHeight() - 1) {
                continue;
            }
            BlockState target = level.getBlockState(ahead);
            if (kind.isBody(target)) {
                runner.pos = ahead;
                runner.dir = dir;
                return true;
            }
            // Anything that gets hold of a tree can kill it. Wisteria mostly does.
            if (com.ferreusveritas.dynamictrees.api.TreeHelper.isBranch(target)) {
                double chance = kind.strangleChance() * (patch.rampant.contains(kind) ? 2.0 : 1.0);
                if (random.nextDouble() < chance) {
                    level.destroyBlock(ahead, false);
                    level.setBlock(ahead, kind.block().get().defaultBlockState(), 3);
                    runner.pos = ahead;
                    runner.dir = dir;
                    runner.life--;
                    patch.counts.merge(kind, 1, Integer::sum);
                    noteGrowth(level, patch, kind);
                    return true;
                }
                continue;
            }
            if (!canTake(level, ahead, target, kind)) {
                continue;
            }

            boolean tookSomethingBuilt = !target.isAir() && !target.canBeReplaced()
                    && Rhizomes.isBuiltBlock(target);
            if (!target.isAir() && !target.canBeReplaced()) {
                // Knotweed breaks up whatever it comes through, and the rubble is yours if you want it.
                level.destroyBlock(ahead, kind == Invasive.KNOTWEED && Config.KNOTWEED_DROPS_RUBBLE.get());
            }
            level.setBlock(ahead, bodyFor(level, ahead, kind), 3);
            runner.pos = ahead;
            runner.dir = dir;
            runner.life--;
            patch.counts.merge(kind, 1, Integer::sum);
            noteGrowth(level, patch, kind);
            shoot(level, ahead, kind, random);
            if (kind == Invasive.WISTERIA) {
                twine(level, ahead, dir, random);
                thicken(level, ahead, random);
                if (tookSomethingBuilt) {
                    collapse(level, ahead, random);
                }
            }

            if (runner.life > 4 && patch.runners.size() < kind.maxRunners() && random.nextInt(9) == 0) {
                patch.runners.add(new Runner(kind, ahead,
                        random.nextBoolean() ? dir.getClockWise() : dir.getCounterClockWise(), runner.life / 2));
            }
            return true;
        }
        return false;
    }

    /**
     * Which way a wisteria runner wants to go. It would rather have a wall than open ground, and failing a wall
     * it works toward whoever is nearest. Neither urge is reliable, which is what keeps it from running in a line.
     */
    @Nullable
    private static Direction wisteriaSteer(ServerLevel level, Patch patch, Runner runner, RandomSource random) {
        // A wall it is already touching beats everything else.
        if (random.nextDouble() < Config.WISTERIA_BASE_PRIORITY.get()) {
            Direction found = null;
            int seen = 0;
            for (Direction dir : Direction.values()) {
                BlockPos side = runner.pos.relative(dir);
                if (!level.isLoaded(side)) {
                    continue;
                }
                BlockState state = level.getBlockState(side);
                if (state.isAir() || state.canBeReplaced() || isInvasive(state) || !Rhizomes.isBuiltBlock(state)) {
                    continue;
                }
                if (!canTake(level, side, state, Invasive.WISTERIA)) {
                    continue;
                }
                // One of the touching walls at random, so it does not always pick the same face.
                if (random.nextInt(++seen) == 0) {
                    found = dir;
                }
            }
            if (found != null) {
                return found;
            }
        }

        if (!Config.WISTERIA_HUNTS.get() || random.nextInt(4) == 0) {
            return null; // Wanders, which is why the runners come in crooked.
        }
        int range = Config.WISTERIA_HUNT_RANGE.get();
        if (range <= 0 || patch.present.isEmpty()) {
            return null;
        }
        ServerPlayer nearest = null;
        double best = (double) range * range;
        for (ServerPlayer player : patch.present) {
            if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
                continue;
            }
            double dist = player.blockPosition().distSqr(runner.pos);
            if (dist < best) {
                best = dist;
                nearest = player;
            }
        }
        if (nearest == null) {
            return null;
        }
        double dx = nearest.getX() - (runner.pos.getX() + 0.5);
        double dy = nearest.getY() - (runner.pos.getY() + 0.5);
        double dz = nearest.getZ() - (runner.pos.getZ() + 0.5);
        if (dy > 2.5 && Math.abs(dy) > Math.max(Math.abs(dx), Math.abs(dz))) {
            return Direction.UP; // Up the wall after somebody standing above it.
        }
        if (Math.abs(dx) > Math.abs(dz)) {
            return dx > 0.0 ? Direction.EAST : Direction.WEST;
        }
        return dz > 0.0 ? Direction.SOUTH : Direction.NORTH;
    }

    /**
     * What wisteria pulls out of a structure takes the rest with it. The course above the hole comes down, and
     * at every level there is a chance of taking a block to the side as well, which is how it opens walls.
     */
    private static void collapse(ServerLevel level, BlockPos pos, RandomSource random) {
        if (!Config.WISTERIA_COLLAPSES.get()) {
            return;
        }
        int height = Config.WISTERIA_COLLAPSE_HEIGHT.get();
        double chance = 0.9;
        boolean any = false;
        for (int up = 1; up <= height; up++) {
            BlockPos above = pos.above(up);
            if (!level.isLoaded(above) || random.nextDouble() > chance) {
                break;
            }
            BlockState state = level.getBlockState(above);
            if (state.isAir() || isInvasive(state) || !Rhizomes.isBuiltBlock(state)
                    || !canTake(level, above, state, Invasive.WISTERIA)) {
                break; // Stops at the sky, or at anything that was not built.
            }
            level.destroyBlock(above, true);
            any = true;
            // And a bite out of the course beside it, so the hole spreads sideways into the wall.
            if (random.nextInt(3) == 0) {
                BlockPos side = above.relative(Direction.from2DDataValue(random.nextInt(4)));
                if (level.isLoaded(side)) {
                    BlockState beside = level.getBlockState(side);
                    if (!beside.isAir() && !isInvasive(beside) && Rhizomes.isBuiltBlock(beside)
                            && canTake(level, side, beside, Invasive.WISTERIA)) {
                        level.destroyBlock(side, true);
                    }
                }
            }
            chance *= 0.82;
        }
        if (any) {
            Sounds.play(level, pos, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 1.1F, 0.55F);
        }
    }

    /**
     * Shoots.
     * <p>
     * Knotweed is a cane two or three metres tall in life, and bramble throws arching canes over everything
     * it covers, so neither of them should read as a carpet on the floor. Every block they lay has a chance
     * of sending something up out of it.
     */
    /**
     * Which part of the plant belongs at a given spot. Buried, it is root; at the surface, the plant proper.
     * This is why a knotweed stand looks like a knotweed stand rather than a sheet of one block.
     */
    private static BlockState bodyFor(ServerLevel level, BlockPos pos, Invasive kind) {
        net.minecraftforge.registries.RegistryObject<net.minecraft.world.level.block.Block> root = kind.root();
        if (root != null && !isOpenAbove(level, pos)) {
            return root.get().defaultBlockState();
        }
        return kind.block().get().defaultBlockState();
    }

    /** True when there is sky, or at least air, directly over this block. */
    private static boolean isOpenAbove(ServerLevel level, BlockPos pos) {
        BlockPos above = pos.above();
        if (!level.isLoaded(above)) {
            return true;
        }
        BlockState state = level.getBlockState(above);
        return state.isAir() || state.canBeReplaced() || isInvasive(state);
    }

    private static void shoot(ServerLevel level, BlockPos from, Invasive kind, RandomSource random) {
        int most = Config.INVASIVE_SHOOT_HEIGHT.get();
        if (most <= 0 || kind.needsWater()) {
            return; // Hyacinth lies flat on the water and that is all it does.
        }
        double chance = kind == Invasive.KNOTWEED ? 0.55 : kind == Invasive.BLACKBERRY ? 0.35 : 0.15;
        if (kind == Invasive.KNOTWEED) {
            // Thin and tall, not a hedge: a cane only every few blocks, and nothing in between.
            int spacing = Config.KNOTWEED_CANE_SPACING.get();
            if (Math.floorMod(from.getX(), spacing) != 0 || Math.floorMod(from.getZ(), spacing) != 0) {
                return;
            }
            chance = 1.0;
            most = Config.KNOTWEED_CANE_HEIGHT.get();
        }
        if (random.nextDouble() >= chance) {
            return;
        }
        net.minecraftforge.registries.RegistryObject<net.minecraft.world.level.block.Block> stem = kind.stem();
        BlockState body = (stem != null ? stem.get() : kind.block().get()).defaultBlockState();
        int height = kind == Invasive.KNOTWEED ? Math.max(3, most - random.nextInt(3))
                : 1 + random.nextInt(most);
        for (int up = 1; up <= height; up++) {
            BlockPos pos = from.above(up);
            if (!level.isLoaded(pos)) {
                return;
            }
            BlockState state = level.getBlockState(pos);
            if (!state.isAir() && !state.canBeReplaced()) {
                return; // Something over it. The cane stops where it stops.
            }
            level.setBlock(pos.immutable(), body, 3);
        }
    }

    /**
     * Twining.
     * <p>
     * A wisteria tip throws out a thin runner that wraps round whatever it meets, and what was thin last
     * week is a wrist-thick rope this week. New growth goes down as flower; where the vine has been for a
     * while the flower is replaced by wood, and the wood spreads sideways into its neighbours. Stand still
     * and you can watch a curtain turn into a cage.
     */
    private static void twine(ServerLevel level, BlockPos tip, Direction dir, RandomSource random) {
        BlockState bloom = VengefulWoods.WISTERIA_BLOOM.get().defaultBlockState();
        BlockState wood = VengefulWoods.WISTERIA.get().defaultBlockState();

        // The new reach: thin, flowering, curling off at an angle from the tip.
        Direction curl = random.nextBoolean() ? dir.getClockWise() : dir.getCounterClockWise();
        BlockPos run = tip;
        int reach = 2 + random.nextInt(3);
        for (int i = 0; i < reach; i++) {
            run = run.relative(i % 2 == 0 ? dir : curl);
            if (random.nextInt(3) == 0) {
                run = run.above();
            }
            if (!level.isLoaded(run)) {
                return;
            }
            BlockState state = level.getBlockState(run);
            if (!state.isAir() && !state.canBeReplaced()) {
                break;
            }
            level.setBlock(run.immutable(), bloom, 3);
        }

        // And the hardening: older flower behind the tip turns to wood, and the wood widens.
        for (int attempt = 0; attempt < 4; attempt++) {
            BlockPos behind = tip.offset(random.nextInt(5) - 2, random.nextInt(3) - 1, random.nextInt(5) - 2);
            if (!level.isLoaded(behind) || !level.getBlockState(behind).is(VengefulWoods.WISTERIA_BLOOM.get())) {
                continue;
            }
            int woodNear = 0;
            for (Direction side : Direction.values()) {
                if (level.getBlockState(behind.relative(side)).is(VengefulWoods.WISTERIA.get())) {
                    woodNear++;
                }
            }
            // It only hardens where it is already holding on to something woody.
            if (woodNear >= 2 && random.nextInt(3) == 0) {
                level.setBlock(behind.immutable(), wood, 3);
            }
        }
    }

    /** Wisteria does not run thin. Every block it lays puts more of itself around it. */
    private static void thicken(ServerLevel level, BlockPos centre, RandomSource random) {
        int extra = Config.WISTERIA_THICKNESS.get();
        BlockState body = VengefulWoods.WISTERIA.get().defaultBlockState();
        BlockState bloom = VengefulWoods.WISTERIA_BLOOM.get().defaultBlockState();
        for (int i = 0; i < extra; i++) {
            BlockPos pos = centre.offset(random.nextInt(3) - 1, random.nextInt(3) - 1, random.nextInt(3) - 1);
            if (pos.equals(centre) || !level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (Invasive.WISTERIA.isBody(state) || Kudzu.isKudzu(state)) {
                continue;
            }
            if (state.isAir() || state.canBeReplaced()) {
                // Woody vine where it is holding on, flower where it is hanging free.
                boolean hanging = pos.getY() < centre.getY()
                        && level.getBlockState(pos.below()).isAir();
                level.setBlock(pos.immutable(), hanging ? bloom : body, 3);
            }
        }
        // And a curtain of flower under the vine itself, which is what the thing is known for.
        BlockPos under = centre.below();
        if (level.isLoaded(under) && level.getBlockState(under).isAir()
                && level.getBlockState(under.below()).isAir() && random.nextInt(3) == 0) {
            level.setBlock(under.immutable(), bloom, 3);
        }
    }

    /** The weight of the thing. Three courses of wisteria and whatever is underneath gives way. */
    private static void crushStep(ServerLevel level, Patch patch) {
        if (!Config.WISTERIA_CRUSHES.get()) {
            return;
        }
        for (int i = 0; i < 2; i++) {
            Runner runner = pickRunner(level, patch, Invasive.WISTERIA);
            if (runner == null) {
                return;
            }
            int depth = 0;
            while (depth < 3 && Invasive.WISTERIA.isBody(level.getBlockState(runner.pos.above(depth)))) {
                depth++;
            }
            if (depth < 3) {
                continue;
            }
            BlockPos below = runner.pos.below();
            if (!level.isLoaded(below)) {
                continue;
            }
            BlockState state = level.getBlockState(below);
            if (state.isAir() || Invasive.WISTERIA.isBody(state) || state.hasBlockEntity()
                    || state.is(VengefulWoods.RHIZOME_IMMUNE) || state.getDestroySpeed(level, below) < 0.0F) {
                continue;
            }
            boolean built = Rhizomes.isBuiltBlock(state);
            level.destroyBlock(below, true);
            level.setBlock(below, VengefulWoods.WISTERIA.get().defaultBlockState(), 3);
            Sounds.play(level, below, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 0.9F, 0.6F);
            if (built) {
                collapse(level, below, level.random);
            }
        }
    }

    @Nullable
    private static Runner pickRunner(ServerLevel level, Patch patch, Invasive kind) {
        for (int attempt = 0; attempt < 6 && !patch.runners.isEmpty(); attempt++) {
            Runner runner = patch.runners.get(level.random.nextInt(patch.runners.size()));
            if (runner.kind == kind && level.isLoaded(runner.pos)) {
                return runner;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Standing still in it
    // ------------------------------------------------------------------------------------------------------------

    /** Seconds each player has spent in thick wisteria without stepping out of it. */
    private static final Map<UUID, Integer> GRIPPED = new HashMap<>();

    /**
     * Wisteria does not chase anybody. It simply keeps growing, and a person who stays put is a thing it can
     * grow around. The longer you stand in it the tighter it gets.
     */
    private static void gripStep(ServerLevel level, List<ServerPlayer> players) {
        int gripSeconds = Config.WISTERIA_GRIP_SECONDS.get();
        for (ServerPlayer player : players) {
            UUID id = player.getUUID();
            if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
                GRIPPED.remove(id);
                continue;
            }
            BlockPos feet = player.blockPosition();
            if (!level.isLoaded(feet)) {
                continue;
            }
            int around = 0;
            for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-2, -1, -2), feet.offset(2, 2, 2))) {
                if (Invasive.WISTERIA.isBody(level.getBlockState(pos))) {
                    around++;
                }
            }
            if (around < 6) {
                // Out of it, or near enough. The vine loses its hold twice as fast as it gained it.
                Integer held = GRIPPED.get(id);
                if (held != null) {
                    if (held <= 2) {
                        GRIPPED.remove(id);
                    } else {
                        GRIPPED.put(id, held - 2);
                    }
                }
                continue;
            }

            int held = GRIPPED.merge(id, 1, Integer::sum);
            if (held == gripSeconds) {
                player.displayClientMessage(Component.translatable("message.vengefulwoods.wisteria_closing")
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), true);
            }
            if (held < gripSeconds) {
                continue;
            }

            // It closes in: a block at a time, from the ground up, and then it leans on you.
            close(level, feet, level.random);
            player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 3, true, false, false));
            float damage = (float) (double) Config.WISTERIA_CRUSH_DAMAGE.get()
                    * (1.0F + Math.min(2.0F, (held - gripSeconds) / 20.0F));
            DamageSource source = Rhizomes.tendrilDamage(level);
            if (damage > 0.0F && source != null) {
                player.hurt(source, damage);
            }
        }
    }

    /** Fills the lowest gap around someone the vine has decided to grow through. */
    private static void close(ServerLevel level, BlockPos feet, RandomSource random) {
        BlockState body = VengefulWoods.WISTERIA.get().defaultBlockState();
        for (int layer = 0; layer <= 2; layer++) {
            for (BlockPos pos : BlockPos.betweenClosed(feet.offset(-1, layer, -1), feet.offset(1, layer, 1))) {
                if (!level.isLoaded(pos)) {
                    continue;
                }
                BlockState state = level.getBlockState(pos);
                if (Invasive.WISTERIA.isBody(state)) {
                    continue;
                }
                if (state.isAir() || state.canBeReplaced()) {
                    level.setBlock(pos.immutable(), body, 3);
                    Sounds.play(level, pos, Sounds.ROOTS_BREAK, SoundSource.HOSTILE, 0.7F, 0.5F);
                    return;
                }
            }
        }
    }

    private static boolean canTake(ServerLevel level, BlockPos pos, BlockState state, Invasive kind) {
        if (state.is(VengefulWoods.RHIZOME_IMMUNE) || state.getDestroySpeed(level, pos) < 0.0F) {
            return false;
        }
        if (state.hasBlockEntity() || isInvasive(state) || Kudzu.isKudzu(state)) {
            return false;
        }
        if (kind.needsWater()) {
            // Hyacinth is a raft, not a creeper: it only ever lies on still water.
            boolean water = !state.getFluidState().isEmpty() && state.canBeReplaced();
            BlockState below = level.isLoaded(pos.below()) ? level.getBlockState(pos.below()) : null;
            boolean floatingOnWater = state.isAir() && below != null && !below.getFluidState().isEmpty();
            if (!water && !floatingOnWater) {
                return false;
            }
            return !kind.isBarrier(level, pos, state);
        }
        if (kind.isBarrier(level, pos, state)) {
            return false; // The one wall it will not pass.
        }
        if (kind == Invasive.WISTERIA && Config.WISTERIA_CRUSHES.get()
                && !state.isAir() && !state.canBeReplaced() && !kind.canTravel(state)) {
            return true; // Heavy enough to go through the rest of it.
        }
        if (state.isAir() || state.canBeReplaced()) {
            // Only into open air that is resting against ground it likes, so patches creep rather than float.
            for (Direction dir : Direction.values()) {
                BlockPos side = pos.relative(dir);
                if (level.isLoaded(side) && kind.canTravel(level.getBlockState(side))) {
                    return true;
                }
            }
            return false;
        }
        return kind.canTravel(state);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Noticing that it got out
    // ------------------------------------------------------------------------------------------------------------

    private static void warnAboutEscapes(ServerLevel level, Patch patch, List<ServerPlayer> players, long now) {
        int threshold = Config.INVASIVE_ESCAPE_SIZE.get();
        for (Invasive kind : Invasive.values()) {
            int count = patch.counts.getOrDefault(kind, 0);
            if (count < threshold) {
                continue;
            }
            Long last = patch.warned.get(kind);
            if (last != null && now - last < 6000L) {
                continue;
            }
            patch.warned.put(kind, now);
            patch.counts.put(kind, 0);
            boolean first = patch.rampant.add(kind);

            for (ServerPlayer player : players) {
                player.displayClientMessage(Component.translatable(kind.translationKey())
                        .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), false);
            }
            if (first) {
                blame(level, patch, kind, players, Config.ESCAPE_ANGER.get());
            }
        }

        // While something is loose, the forest's opinion of whoever let it out keeps getting worse.
        if (!patch.rampant.isEmpty() && now - patch.lastReckoning > 2400L) {
            patch.lastReckoning = now;
            for (Invasive kind : patch.rampant) {
                blame(level, patch, kind, players, Config.RAMPANT_ANGER.get());
            }
        }
    }

    /**
     * The trees hold an escape against the person who planted it. If nobody owns up - or the planter is long
     * gone - whoever is standing closest to the mess answers for it.
     */
    private static void blame(ServerLevel level, Patch patch, Invasive kind, List<ServerPlayer> players, int trees) {
        if (trees <= 0 || players.isEmpty()) {
            return;
        }
        WrathData global = WrathData.global(level.getServer());
        WrathData.Escape escape = global.escape(kind.name());
        if (escape.deliberate) {
            // You did not find this here. You brought it, and the forest can tell the difference.
            trees = (int) Math.round(trees * (double) Config.DELIBERATE_ANGER.get());
        }
        UUID planter = patch.planter.get(kind);
        ServerPlayer target = planter == null ? null : level.getServer().getPlayerList().getPlayer(planter);
        if (target == null) {
            target = players.get(0);
        }

        WrathData.Account account = global.account(target.getUUID());
        Stage before = account.stage();
        global.setFelled(target.getUUID(), account.felled + trees);
        escape.charged.merge(target.getUUID(), trees, Integer::sum);
        Stage after = global.account(target.getUUID()).stage();
        SpeciesTuner.apply(WrathData.worstStage(level.getServer()));

        target.displayClientMessage(Component.translatable(
                        escape.deliberate ? "message.vengefulwoods.blamed_planted" : "message.vengefulwoods.blamed",
                        Component.translatable(kind.block().get().getDescriptionId()))
                .withStyle(ChatFormatting.DARK_RED), false);
        if (after != before) {
            target.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + after.ordinal())
                    .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
        }
    }

    /** Records who called a species up, so an escape lands on the right head. */
    static void setPlanter(ServerLevel level, Invasive kind, UUID planter) {
        patch(level).planter.put(kind, planter);
        if (level.getServer() != null) {
            WrathData.global(level.getServer()).escape(kind.name()).deliberate = true;
        }
    }

    /**
     * Counts a block of an escaped species taken out of the ground toward buying back what letting it out
     * cost. The brush hook reports its own work here, because clearing a disaster with the right tool should
     * not count for less than doing it by hand.
     */
    static void noteCleared(ServerLevel level, Invasive kind, int blocks) {
        if (blocks <= 0 || level.getServer() == null) {
            return;
        }
        WrathData global = WrathData.global(level.getServer());
        WrathData.Escape escape = global.escapes.get(kind.name());
        if (escape == null || escape.charged.isEmpty()) {
            return;
        }
        escape.cleared += blocks;
        global.setDirty();
    }

    /** Every block this species lays while it is loose counts toward how big a mess it became. */
    private static void noteGrowth(ServerLevel level, Patch patch, Invasive kind) {
        if (!patch.rampant.contains(kind) || level.getServer() == null) {
            return;
        }
        WrathData global = WrathData.global(level.getServer());
        global.escape(kind.name()).grown++;
        global.setDirty();
    }

    /** True while a species is loose and behaving at its worst. */
    static boolean isRampant(ServerLevel level, Invasive kind) {
        Patch patch = PATCHES.get(level.dimension());
        return patch != null && patch.rampant.contains(kind);
    }

    /** Cutting every last runner of a species out brings it back under control. */
    private static void checkContained(ServerLevel level, Patch patch) {
        Set<Invasive> alive = EnumSet.noneOf(Invasive.class);
        for (Runner runner : patch.runners) {
            alive.add(runner.kind);
        }
        patch.rampant.retainAll(alive);
        if (Config.AMENDS_ENABLED.get() && level.getServer() != null) {
            for (Invasive kind : Invasive.values()) {
                if (!alive.contains(kind)) {
                    checkAmends(level, kind);
                }
            }
        }
    }

    /**
     * Making it right.
     * <p>
     * The forest will give back every point of anger an escape cost you, but only for a mess that was real and
     * only once you have taken it out yourself. Both halves are the same number: it has to have grown that
     * many blocks, and you have to have pulled that many blocks of it up. Planting a weed, letting it tick over
     * the warning line and immediately digging it up again proves nothing, and earns nothing.
     */
    private static void checkAmends(ServerLevel level, Invasive kind) {
        WrathData global = WrathData.global(level.getServer());
        WrathData.Escape escape = global.escapes.get(kind.name());
        if (escape == null || escape.charged.isEmpty()) {
            return;
        }
        int needed = Config.AMENDS_SIZE.get();
        if (escape.grown < needed || escape.cleared < needed) {
            return;
        }

        for (Map.Entry<UUID, Integer> entry : escape.charged.entrySet()) {
            UUID id = entry.getKey();
            WrathData.Account account = global.account(id);
            Stage before = account.stage();
            global.setFelled(id, account.felled - entry.getValue());
            Stage after = global.account(id).stage();

            ServerPlayer player = level.getServer().getPlayerList().getPlayer(id);
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.vengefulwoods.amends",
                                Component.translatable(kind.block().get().getDescriptionId()), entry.getValue())
                        .withStyle(ChatFormatting.GREEN), false);
                if (after != before) {
                    player.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + after.ordinal())
                            .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
                }
            }
        }
        global.escapes.remove(kind.name()); // Settled. The next one starts from nothing.
        global.setDirty();
        SpeciesTuner.apply(WrathData.worstStage(level.getServer()));
    }

    // ------------------------------------------------------------------------------------------------------------
    // Cutting them back
    // ------------------------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        Invasive kind = kindOf(event.getPlacedBlock());
        if (kind != null && event.getEntity() instanceof ServerPlayer player && !player.isCreative()) {
            // Putting it in the ground yourself is as deliberate as a rite, and owns the consequences.
            setPlanter(level, kind, player.getUUID());
        }
        awaken(level, event.getPos(), event.getPlacedBlock());
    }

    /** The forest thinks better of anyone who pulls these up, though it values it less than kudzu work. */
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.level().isClientSide() || player.isCreative()
                || !isInvasive(event.getState()) || player.getServer() == null) {
            return;
        }
        Invasive broken = kindOf(event.getState());
        if (broken != null && Skills.has(player, Skill.FORAGER) && player.level() instanceof ServerLevel forage) {
            // Learned hands get twice out of the same cane.
            net.minecraft.world.level.block.Block.popResource(forage, event.getPos(),
                    new net.minecraft.world.item.ItemStack(broken.harvest().get()));
        }
        if (broken == Invasive.WISTERIA && player.level() instanceof ServerLevel woody) {
            regrowInto(woody, event.getPos());
        }
        if (broken != null && player.level() instanceof ServerLevel here) {
            noteCleared(here, broken, 1);
        }
        creditWeeding(player, 1);
    }

    /** The same credit, for a tool that takes a whole stand out at once rather than a block at a time. */
    static void creditWeeding(Player player, int blocks) {
        if (blocks <= 0 || player.isCreative()) {
            return;
        }
        int needed = Config.INVASIVE_PER_OFFERING.get();
        if (needed <= 0) {
            return;
        }
        UUID id = player.getUUID();
        int cleared = CLEARED.merge(id, blocks, Integer::sum);
        if (cleared < needed) {
            return;
        }
        CLEARED.put(id, cleared % needed);
        int earned = cleared / needed;
        if (player instanceof ServerPlayer serverPlayer && serverPlayer.level() instanceof ServerLevel level) {
            Rituals.reward(level, serverPlayer, earned);
            serverPlayer.displayClientMessage(Component.translatable("message.vengefulwoods.weeded")
                    .withStyle(ChatFormatting.DARK_GREEN), true);
        }
    }

    /**
     * Cutting wisteria out leaves the rest of the plant holding the gap. A neighbouring stem starts running
     * again, pointed at the hole you just made, so clearing a patch means taking all of it in one go.
     */
    private static void regrowInto(ServerLevel level, BlockPos gap) {
        if (level.random.nextDouble() >= Config.WISTERIA_REGROW.get()) {
            return;
        }
        Patch patch = patch(level);
        if (patch.runners.size() >= Invasive.WISTERIA.maxRunners()) {
            return;
        }
        for (Direction dir : Direction.values()) {
            BlockPos side = gap.relative(dir);
            if (!level.isLoaded(side) || !Invasive.WISTERIA.isBody(level.getBlockState(side))) {
                continue;
            }
            patch.runners.add(new Runner(Invasive.WISTERIA, side.immutable(), dir.getOpposite(),
                    Config.INVASIVE_RUNNER_LIFE.get()));
            return;
        }
    }

    /**
     * Lays down a starting stand and sets runners going from it. Returns how many blocks took, so a rite
     * performed somewhere nothing will grow can refund itself.
     */
    static int seed(ServerLevel level, BlockPos centre, Invasive kind, int radius) {
        Patch patch = patch(level);
        int placed = 0;
        for (BlockPos pos : BlockPos.betweenClosed(centre.offset(-radius, -1, -radius), centre.offset(radius, 1, radius))) {
            if (!level.isLoaded(pos) || level.random.nextFloat() < 0.45F) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (kind.isBody(state) || !canTake(level, pos, state, kind)) {
                continue;
            }
            if (!state.isAir() && !state.canBeReplaced()) {
                continue; // A rite plants; it does not dig.
            }
            level.setBlock(pos.immutable(), kind.block().get().defaultBlockState(), 3);
            placed++;
            if (patch.runners.size() < kind.maxRunners() && placed % 3 == 0) {
                patch.runners.add(new Runner(kind, pos.immutable(),
                        Direction.from2DDataValue(level.random.nextInt(4)), Config.INVASIVE_RUNNER_LIFE.get()));
            }
        }
        return placed;
    }

    /** An allied forest pulls these up around you without being asked. */
    static void wardenSweep(ServerLevel level, ServerPlayer player) {
        BlockPos centre = player.blockPosition();
        int radius = 6;
        for (int i = 0; i < 12; i++) {
            BlockPos pos = centre.offset(level.random.nextInt(radius * 2 + 1) - radius,
                    level.random.nextInt(7) - 3, level.random.nextInt(radius * 2 + 1) - radius);
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (isInvasive(state) || Kudzu.isKudzu(state)) {
                level.destroyBlock(pos.immutable(), true);
                return;
            }
        }
    }
}
