package com.vengefulwoods;

/**
 * The other half of the forest's mood: how much it likes you.
 * <p>
 * Favour is earned by giving trees fertilizer. It only counts while the forest is calm enough to notice —
 * once rhizomes are out (stage 3 and up) the forest is too angry to be anyone's friend, so keep giving until
 * the aggression drops back down.
 */
public enum Boon {
    NONE,
    TOLERATED,  // the trees start leaving you presents
    ALLIED,     // they clear your way, keep away from your base, and fight what comes at you
    GUARDIAN,   // they will throw themselves at whatever is hunting you
    WARDEN,     // they weed the invasives out around you, and keep their own roots off your land
    HEARTBOUND; // the woods themselves hold you up while you stand under them

    public boolean atLeast(Boon other) {
        return this.ordinal() >= other.ordinal();
    }

    /** Offerings needed to reach this level of favour. */
    public int threshold() {
        switch (this) {
            case TOLERATED:
                return Config.BOON_1.get();
            case ALLIED:
                return Config.BOON_2.get();
            case GUARDIAN:
                return Config.BOON_3.get();
            case WARDEN:
                return Config.BOON_4.get();
            case HEARTBOUND:
                return Config.BOON_5.get();
            default:
                return 0;
        }
    }

    /** Whether the forest will pull invasives up around this player of its own accord. */
    public boolean weedsForYou() {
        return atLeast(WARDEN);
    }

    /** Whether standing under the canopy does a player good. */
    public boolean blesses() {
        return atLeast(HEARTBOUND);
    }

    public static Boon forOfferings(int offerings, Stage stage) {
        if (stage.atLeast(Stage.CREEPING)) {
            return NONE; // Too angry to care about gifts.
        }
        Boon result = NONE;
        for (Boon boon : values()) {
            if (boon != NONE && offerings >= boon.threshold()) {
                result = boon;
            }
        }
        return result;
    }
}
