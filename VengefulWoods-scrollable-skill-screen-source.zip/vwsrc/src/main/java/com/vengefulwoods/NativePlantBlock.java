package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * A plant that belongs here. It breaks in one hit, it needs ground under it, and left alone it slowly fills
 * the ground around it back in - which is the whole reason the forest tolerates you picking any of it.
 */
public class NativePlantBlock extends Block {

    public final Native plant;
    private final VoxelShape shape;

    public NativePlantBlock(Native plant, MapColor colour, int height) {
        super(BlockBehaviour.Properties.of()
                .mapColor(colour)
                .noCollission()
                .pushReaction(PushReaction.DESTROY)
                .instabreak()
                .sound(SoundType.GRASS)
                .randomTicks()
                .noOcclusion());
        this.plant = plant;
        this.shape = Block.box(2.0D, 0.0D, 2.0D, 14.0D, height, 14.0D);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return shape;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        return isGoodGround(level.getBlockState(pos.below()));
    }

    /** Each one is fussy about what it will root in, and they do not all want the same thing. */
    private boolean isGoodGround(BlockState state) {
        switch (plant.ground()) {
            case WET:
                return soil(state) || state.is(Blocks.CLAY) || state.is(Blocks.SAND)
                        || state.is(Blocks.GRAVEL);
            case SHORE:
                return state.is(Blocks.SAND) || state.is(Blocks.GRAVEL) || state.is(Blocks.STONE)
                        || state.is(Blocks.COARSE_DIRT) || soil(state);
            case ARID:
                return state.is(Blocks.SAND) || state.is(Blocks.RED_SAND) || state.is(Blocks.TERRACOTTA)
                        || state.is(Blocks.COARSE_DIRT);
            case HIGH:
                return state.is(Blocks.STONE) || state.is(Blocks.GRAVEL) || state.is(Blocks.SNOW_BLOCK)
                        || state.is(Blocks.COARSE_DIRT) || soil(state);
            default:
                return soil(state);
        }
    }

    private static boolean soil(BlockState state) {
        return state.is(BlockTags.DIRT) || state.is(Blocks.FARMLAND) || state.is(Blocks.MUD);
    }

    @Override
    public void neighborChanged(BlockState state, Level level, BlockPos pos, Block from, BlockPos fromPos,
                                boolean moving) {
        if (!level.isClientSide() && !canSurvive(state, level, pos)) {
            level.destroyBlock(pos, true); // The ground went out from under it.
        }
    }

    /** Left to itself, it creeps back across the ground it came from. Slowly. */
    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (random.nextDouble() >= (double) Config.NATIVE_SPREAD_CHANCE.get()) {
            return;
        }
        int cap = Config.NATIVE_DENSITY.get();
        int seen = 0;
        for (BlockPos near : BlockPos.betweenClosed(pos.offset(-2, -1, -2), pos.offset(2, 1, 2))) {
            if (level.getBlockState(near).is(this)) {
                seen++;
            }
        }
        if (seen >= cap) {
            return; // A stand this thick does not need any more of itself.
        }
        BlockPos spot = pos.offset(random.nextInt(5) - 2, random.nextInt(3) - 1, random.nextInt(5) - 2);
        if (!level.isLoaded(spot) || !level.getBlockState(spot).isAir()) {
            return;
        }
        if (!isGoodGround(level.getBlockState(spot.below()))) {
            return;
        }
        level.setBlock(spot.immutable(), defaultBlockState(), 3);
    }
}
