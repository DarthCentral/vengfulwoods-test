package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;

/**
 * The altar's bowl.
 * <p>
 * Rites used to be paid for by standing there feeding the stone one item at a time, which was tedious and
 * told you nothing about how far along you were. Now you open it, put what you are giving up inside, and work
 * the rite. Whatever is in the bowl is counted and taken at that moment, timber at a log's worth apiece.
 */
public class AltarBlockEntity extends BlockEntity implements Container, MenuProvider {

    public static final int SIZE = 27;

    private final NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);

    public AltarBlockEntity(BlockPos pos, BlockState state) {
        super(VengefulWoods.ALTAR_BLOCK_ENTITY.get(), pos, state);
    }

    public NonNullList<ItemStack> contents() {
        return items;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Container
    // ------------------------------------------------------------------------------------------------------------

    @Override
    public int getContainerSize() {
        return SIZE;
    }

    @Override
    public boolean isEmpty() {
        for (ItemStack stack : items) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    @Override
    public ItemStack getItem(int slot) {
        return items.get(slot);
    }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack taken = ContainerHelper.removeItem(items, slot, amount);
        if (!taken.isEmpty()) {
            setChanged();
        }
        return taken;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) {
            stack.setCount(getMaxStackSize());
        }
        setChanged();
    }

    @Override
    public boolean stillValid(Player player) {
        if (level == null || level.getBlockEntity(worldPosition) != this) {
            return false;
        }
        return player.distanceToSqr(worldPosition.getX() + 0.5, worldPosition.getY() + 0.5,
                worldPosition.getZ() + 0.5) <= 64.0;
    }

    @Override
    public void clearContent() {
        items.clear();
        setChanged();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Saving
    // ------------------------------------------------------------------------------------------------------------

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        items.clear();
        ContainerHelper.loadAllItems(tag, items);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, items);
    }

    // ------------------------------------------------------------------------------------------------------------
    // Opening it
    // ------------------------------------------------------------------------------------------------------------

    @Override
    public Component getDisplayName() {
        return Component.translatable("container.vengefulwoods.altar");
    }

    /** What the window shows along its edges: tribute, anger, favour, stage. */
    private ContainerData readout(Player player) {
        return new ContainerData() {
            @Override
            public int get(int index) {
                if (level == null || level.getServer() == null) {
                    return 0;
                }
                WrathData.Account account = WrathData.global(level.getServer()).account(player.getUUID());
                switch (index) {
                    case 0:
                        return account.tribute;
                    case 1:
                        return account.effectiveFelled();
                    case 2:
                        return account.offerings;
                    default:
                        return account.stage().ordinal();
                }
            }

            @Override
            public void set(int index, int value) {
            }

            @Override
            public int getCount() {
                return AltarMenu.DATA_SIZE;
            }
        };
    }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory playerInventory, Player player) {
        return new AltarMenu(id, playerInventory, this, readout(player),
                Rite.forClass(WoodsClass.of(player)));
    }
}
