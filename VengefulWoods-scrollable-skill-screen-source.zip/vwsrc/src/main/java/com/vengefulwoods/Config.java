package com.vengefulwoods;

import net.minecraftforge.common.ForgeConfigSpec;

/** Everything here ends up in config/vengefulwoods-common.toml. */
public final class Config {

    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.IntValue STAGE_1;
    public static final ForgeConfigSpec.IntValue STAGE_2;
    public static final ForgeConfigSpec.IntValue STAGE_3;
    public static final ForgeConfigSpec.IntValue STAGE_4;
    public static final ForgeConfigSpec.IntValue STAGE_5;
    public static final ForgeConfigSpec.IntValue STAGE_6;
    public static final ForgeConfigSpec.IntValue STAGE_7;
    public static final ForgeConfigSpec.IntValue STAGE_8;

    public static final ForgeConfigSpec.IntValue MIN_BRANCHES;
    public static final ForgeConfigSpec.BooleanValue FIRE_NEEDS_PLAYER;
    public static final ForgeConfigSpec.IntValue FIRE_MEMORY_MINUTES;
    public static final ForgeConfigSpec.BooleanValue ALL_EXPLOSIONS;

    public static final ForgeConfigSpec.DoubleValue NATURAL_GROWTH_MULTIPLIER;
    public static final ForgeConfigSpec.IntValue MAX_TREE_HEIGHT;
    public static final ForgeConfigSpec.IntValue SAPLING_GROW_SECONDS;
    public static final ForgeConfigSpec.DoubleValue REGROW_CHANCE;

    public static final ForgeConfigSpec.IntValue MAX_TIPS;
    public static final ForgeConfigSpec.IntValue MAX_RHIZOME_LENGTH;
    public static final ForgeConfigSpec.IntValue MIN_TREE_SPACING;
    public static final ForgeConfigSpec.BooleanValue RHIZOMES_BREAK_BUILDS;
    public static final ForgeConfigSpec.BooleanValue BREAK_CONTAINERS;
    public static final ForgeConfigSpec.DoubleValue TENDRIL_DAMAGE;

    public static final ForgeConfigSpec.IntValue WRATH_PER_OFFERING;
    public static final ForgeConfigSpec.IntValue BOON_1;
    public static final ForgeConfigSpec.IntValue BOON_2;
    public static final ForgeConfigSpec.IntValue BOON_3;
    public static final ForgeConfigSpec.IntValue BOON_4;
    public static final ForgeConfigSpec.IntValue BOON_5;
    public static final ForgeConfigSpec.IntValue GIFT_MINUTES;
    public static final ForgeConfigSpec.BooleanValue CLEAR_PATHS;
    public static final ForgeConfigSpec.BooleanValue AVOID_BASES;

    public static final ForgeConfigSpec.BooleanValue DEFEND_PLAYERS;
    public static final ForgeConfigSpec.BooleanValue TOPPLE_ON_MOBS;
    public static final ForgeConfigSpec.BooleanValue TOPPLE_ON_PLAYERS;
    public static final ForgeConfigSpec.IntValue TOPPLE_COOLDOWN;
    public static final ForgeConfigSpec.IntValue CAGE_SECONDS;
    public static final ForgeConfigSpec.BooleanValue RHIZOMES_DROP_BUILDS;
    public static final ForgeConfigSpec.IntValue RHIZOME_DEPTH;
    public static final ForgeConfigSpec.IntValue GRUDGE_MINUTES;
    public static final ForgeConfigSpec.DoubleValue CRUSH_DAMAGE;

    public static final ForgeConfigSpec.BooleanValue KUDZU_ENABLED;
    public static final ForgeConfigSpec.IntValue KUDZU_SPREAD;
    public static final ForgeConfigSpec.DoubleValue KUDZU_STRANGLE_CHANCE;
    public static final ForgeConfigSpec.DoubleValue KUDZU_TREE_RESISTANCE;
    public static final ForgeConfigSpec.BooleanValue KUDZU_BREAKS_BUILDS;
    public static final ForgeConfigSpec.BooleanValue KUDZU_MOBS;
    public static final ForgeConfigSpec.IntValue KUDZU_MOBS_PER_MINUTE;
    public static final ForgeConfigSpec.BooleanValue KUDZU_SEEDS_ITSELF;
    public static final ForgeConfigSpec.IntValue KUDZU_SEED_MINUTES;
    public static final ForgeConfigSpec.IntValue KUDZU_PER_OFFERING;
    public static final ForgeConfigSpec.IntValue KUDZU_MAX_RUNNERS;
    public static final ForgeConfigSpec.IntValue KUDZU_BRANCH_EVERY;
    public static final ForgeConfigSpec.IntValue KUDZU_LEAF_DENSITY;
    public static final ForgeConfigSpec.DoubleValue KUDZU_BURY_DAMAGE;
    public static final ForgeConfigSpec.IntValue KUDZU_TRIGGER_TREES;
    public static final ForgeConfigSpec.IntValue KUDZU_MIN_DISTANCE;
    public static final ForgeConfigSpec.IntValue KUDZU_MAX_DISTANCE;
    public static final ForgeConfigSpec.IntValue KUDZU_RUNNER_LIFE;
    public static final ForgeConfigSpec.IntValue KUDZU_BURROW_LENGTH;
    public static final ForgeConfigSpec.IntValue KUDZU_GAP;
    public static final ForgeConfigSpec.IntValue KUDZU_HUNT_SPEED;
    public static final ForgeConfigSpec.BooleanValue KUDZU_DRAGS_DOWN;
    public static final ForgeConfigSpec.BooleanValue KUDZU_EATS_MOBS;
    public static final ForgeConfigSpec.DoubleValue KUDZU_MOB_DAMAGE;
    public static final ForgeConfigSpec.IntValue KUDZU_MOB_BIOMASS;
    public static final ForgeConfigSpec.DoubleValue KUDZU_DIVE_CHANCE;
    public static final ForgeConfigSpec.BooleanValue KUDZU_HUNTS_PLAYERS;
    public static final ForgeConfigSpec.IntValue KUDZU_HUNT_RANGE;
    public static final ForgeConfigSpec.BooleanValue KUDZU_BURIES_PLAYERS;

    public static final ForgeConfigSpec.IntValue RITE_GROVE_SIZE;
    public static final ForgeConfigSpec.IntValue RITE_SEEDING_SIZE;
    public static final ForgeConfigSpec.IntValue RITE_ROOTS;
    public static final ForgeConfigSpec.IntValue RITE_BARGAIN_LOGS;
    public static final ForgeConfigSpec.IntValue RITE_BARGAIN_COST;
    public static final ForgeConfigSpec.IntValue RITE_BLIGHT_COST;
    public static final ForgeConfigSpec.IntValue RITE_FERTILIZER_WORTH;
    public static final ForgeConfigSpec.IntValue RITE_QUIET_COST;
    public static final ForgeConfigSpec.IntValue RITE_QUIET_TREES;
    public static final ForgeConfigSpec.BooleanValue SACRIFICES;
    public static final ForgeConfigSpec.IntValue SACRIFICE_MONSTER;
    public static final ForgeConfigSpec.IntValue SACRIFICE_ANIMAL;
    public static final ForgeConfigSpec.IntValue SACRIFICE_PET;
    public static final ForgeConfigSpec.BooleanValue ARMOUR_SOFTENS;
    public static final ForgeConfigSpec.IntValue BRUSH_HOOK_RADIUS;

    public static final ForgeConfigSpec.BooleanValue INVASIVES_ENABLED;
    public static final ForgeConfigSpec.IntValue INVASIVE_MAX_RUNNERS;
    public static final ForgeConfigSpec.IntValue INVASIVE_RUNNER_LIFE;
    public static final ForgeConfigSpec.IntValue INVASIVE_ESCAPE_SIZE;
    public static final ForgeConfigSpec.IntValue INVASIVE_SHOOT_HEIGHT;
    public static final ForgeConfigSpec.IntValue KNOTWEED_CANE_HEIGHT;
    public static final ForgeConfigSpec.IntValue KNOTWEED_CANE_SPACING;
    public static final ForgeConfigSpec.IntValue INVASIVE_PER_OFFERING;
    public static final ForgeConfigSpec.IntValue BLACKBERRY_SPREAD;
    public static final ForgeConfigSpec.DoubleValue BLACKBERRY_DAMAGE;
    public static final ForgeConfigSpec.IntValue KNOTWEED_SPREAD;
    public static final ForgeConfigSpec.BooleanValue KNOTWEED_DROPS_RUBBLE;
    public static final ForgeConfigSpec.IntValue CHEATGRASS_SPREAD;
    public static final ForgeConfigSpec.BooleanValue CHEATGRASS_IGNITES;
    public static final ForgeConfigSpec.DoubleValue CHEATGRASS_FIRE_CHANCE;
    public static final ForgeConfigSpec.IntValue HYACINTH_SPREAD;
    public static final ForgeConfigSpec.IntValue WISTERIA_SPREAD;
    public static final ForgeConfigSpec.DoubleValue WISTERIA_STRANGLE;
    public static final ForgeConfigSpec.BooleanValue WISTERIA_CRUSHES;
    public static final ForgeConfigSpec.IntValue WISTERIA_THICKNESS;
    public static final ForgeConfigSpec.IntValue WISTERIA_GRIP_SECONDS;
    public static final ForgeConfigSpec.DoubleValue WISTERIA_CRUSH_DAMAGE;
    public static final ForgeConfigSpec.IntValue WISTERIA_STEP_TICKS;
    public static final ForgeConfigSpec.BooleanValue WISTERIA_HUNTS;
    public static final ForgeConfigSpec.IntValue WISTERIA_HUNT_RANGE;
    public static final ForgeConfigSpec.DoubleValue WISTERIA_BASE_PRIORITY;
    public static final ForgeConfigSpec.BooleanValue WISTERIA_COLLAPSES;
    public static final ForgeConfigSpec.IntValue WISTERIA_COLLAPSE_HEIGHT;
    public static final ForgeConfigSpec.DoubleValue WISTERIA_REGROW;
    public static final ForgeConfigSpec.BooleanValue WISTERIA_FIREPROOF;
    public static final ForgeConfigSpec.DoubleValue STRANGLE_OTHERS;
    public static final ForgeConfigSpec.DoubleValue RAMPANT_SPEED;
    public static final ForgeConfigSpec.IntValue ESCAPE_ANGER;
    public static final ForgeConfigSpec.IntValue RAMPANT_ANGER;
    public static final ForgeConfigSpec.DoubleValue DELIBERATE_ANGER;
    public static final ForgeConfigSpec.IntValue AMENDS_SIZE;
    public static final ForgeConfigSpec.BooleanValue AMENDS_ENABLED;

    public static final ForgeConfigSpec.BooleanValue CLASSES_ENABLED;
    public static final ForgeConfigSpec.BooleanValue SKILLS_ENABLED;
    public static final ForgeConfigSpec.BooleanValue RITUAL_BOOK;
    public static final ForgeConfigSpec.IntValue SKILL_PER_FELLED;
    public static final ForgeConfigSpec.IntValue SKILL_PER_OFFERING;
    public static final ForgeConfigSpec.DoubleValue DRUID_FAVOUR;
    public static final ForgeConfigSpec.IntValue DRUID_MARK_SECONDS;
    public static final ForgeConfigSpec.DoubleValue COLONIALIST_ANGER;
    public static final ForgeConfigSpec.DoubleValue COLONIALIST_HEARTWOOD;
    public static final ForgeConfigSpec.IntValue COLONIALIST_CLEARING;
    public static final ForgeConfigSpec.DoubleValue INVADER_RITE_COST;
    public static final ForgeConfigSpec.DoubleValue INVADER_WEED_DAMAGE;
    public static final ForgeConfigSpec.IntValue GREEN_HAND_COOLDOWN;
    public static final ForgeConfigSpec.IntValue GREEN_HAND_MINIMUM;
    public static final ForgeConfigSpec.DoubleValue GREEN_HAND_MAX_POWER;
    public static final ForgeConfigSpec.DoubleValue GREEN_HAND_BACKFIRE;
    public static final ForgeConfigSpec.DoubleValue GREEN_HAND_BACKFIRE_CAP;
    public static final ForgeConfigSpec.IntValue INVADER_CONSUMED_AT;
    public static final ForgeConfigSpec.IntValue MUSHROOM_SPREAD_SECONDS;
    public static final ForgeConfigSpec.IntValue MUSHROOM_ORIGINAL_COST;
    public static final ForgeConfigSpec.IntValue MUSHROOM_HAZE_RANGE;
    public static final ForgeConfigSpec.BooleanValue MUSHROOM_SHIELD;
    public static final ForgeConfigSpec.DoubleValue MUSHROOM_SHIELD_RANGE;
    public static final ForgeConfigSpec.DoubleValue MUSHROOM_DODGE;
    public static final ForgeConfigSpec.BooleanValue ORIGINAL_MUSIC;
    public static final ForgeConfigSpec.IntValue ORIGINAL_HEIGHT;
    public static final ForgeConfigSpec.IntValue ORIGINAL_CAP;
    public static final ForgeConfigSpec.IntValue ORIGINAL_GIRTH;
    public static final ForgeConfigSpec.BooleanValue ORIGINAL_WORDS;
    public static final ForgeConfigSpec.IntValue ORIGINAL_LIMIT;
    public static final ForgeConfigSpec.IntValue ORIGINAL_BREED_MINUTES;
    public static final ForgeConfigSpec.BooleanValue MUSHROOM_OPPORTUNISM;
    public static final ForgeConfigSpec.IntValue MUSHROOM_IMBALANCE;

    public static final ForgeConfigSpec.BooleanValue BIOMASS_ENABLED;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_PER_TREE;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_PER_WEED;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_CAP;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_PER_SIGNAL;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_PER_WEED_BLOCK;
    public static final ForgeConfigSpec.DoubleValue BIOMASS_CHANNEL_SHARE;
    public static final ForgeConfigSpec.IntValue BIOMASS_CHANNEL_MAX;
    public static final ForgeConfigSpec.IntValue BIOMASS_SPREAD_MAX;
    public static final ForgeConfigSpec.IntValue BIOMASS_FOCUS_RANGE;
    public static final ForgeConfigSpec.IntValue BIOMASS_FOCUS_SECONDS;

    public static final ForgeConfigSpec.BooleanValue NATIVES_ENABLED;
    public static final ForgeConfigSpec.IntValue NATIVE_PICKS_PER_TREE;
    public static final ForgeConfigSpec.IntValue NATIVE_TRILLIUM_COST;
    public static final ForgeConfigSpec.IntValue NATIVE_PLANTS_PER_OFFERING;
    public static final ForgeConfigSpec.IntValue NATIVE_FAVOUR_PER_DAY;
    public static final ForgeConfigSpec.DoubleValue NATIVE_SPREAD_CHANCE;
    public static final ForgeConfigSpec.IntValue NATIVE_DENSITY;
    public static final ForgeConfigSpec.DoubleValue HEARTWOOD_FROM_FELLING;
    public static final ForgeConfigSpec.IntValue TRIBUTE_BLACKBERRY;
    public static final ForgeConfigSpec.IntValue TRIBUTE_KNOTWEED;
    public static final ForgeConfigSpec.IntValue TRIBUTE_CHEATGRASS;
    public static final ForgeConfigSpec.IntValue TRIBUTE_HYACINTH;
    public static final ForgeConfigSpec.IntValue TRIBUTE_WISTERIA;
    public static final ForgeConfigSpec.IntValue TRIBUTE_KUDZU;
    public static final ForgeConfigSpec.IntValue TRIBUTE_PER_ITEM;
    public static final ForgeConfigSpec.IntValue TRIBUTE_PER_LOG;
    public static final ForgeConfigSpec.IntValue TRIBUTE_PER_PLANK;
    public static final ForgeConfigSpec.IntValue TRIBUTE_ANIMAL;
    public static final ForgeConfigSpec.IntValue TRIBUTE_PET;
    public static final ForgeConfigSpec.IntValue TRIBUTE_MONSTER;

    public static final ForgeConfigSpec.IntValue SCAN_RADIUS;
    public static final ForgeConfigSpec.IntValue ACTIVE_RADIUS;
    public static final ForgeConfigSpec.IntValue MAX_TREES;
    public static final ForgeConfigSpec.IntValue TREES_PER_TICK;
    public static final ForgeConfigSpec.BooleanValue ANNOUNCE;
    public static final ForgeConfigSpec.BooleanValue SHOW_COUNTER;

    public static final ForgeConfigSpec.BooleanValue SHARE_STANDING;
    public static final ForgeConfigSpec.BooleanValue SHARE_SKILLS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Destroyed trees needed for each stage. Counted separately for every player.").push("stages");
        STAGE_1 = b.comment("Stirring - trees grow faster and never run out of soil.")
                .defineInRange("stage1", 6, 1, 1000000);
        STAGE_2 = b.comment("Thickening - trees grow huge and plant a sapling a day.")
                .defineInRange("stage2", 14, 1, 1000000);
        STAGE_3 = b.comment("Creeping - rhizomes burrow out from the roots.")
                .defineInRange("stage3", 22, 1, 1000000);
        STAGE_4 = b.comment("Snarling - stumps sprout at once and the forest goes after torches.")
                .defineInRange("stage4", 30, 1, 1000000);
        STAGE_5 = b.comment("Relentless - felled trees come back from the dead.")
                .defineInRange("stage5", 40, 1, 1000000);
        STAGE_6 = b.comment("Grasping - growth turns toward you, roots drag at your feet, branches fall on you.")
                .defineInRange("stage6", 52, 1, 1000000);
        STAGE_7 = b.comment("Hunting - tendrils attack and whole trees are thrown at you.")
                .defineInRange("stage7", 66, 1, 1000000);
        STAGE_8 = b.comment("Wrathful - no let-up: the woods grow over you while you watch, and keep coming down on you.")
                .defineInRange("stage8", 84, 1, 1000000);
        b.pop();

        b.comment("What counts as destroying a tree.").push("counting");
        MIN_BRANCHES = b.comment("A felled piece must contain at least this many branch blocks to count as a tree.",
                        "Stops one-block saplings and twigs from being counted.")
                .defineInRange("minBranchBlocks", 3, 1, 64);
        FIRE_NEEDS_PLAYER = b.comment("true = a burned tree only counts if a player used flint and steel, a fire charge or a lava",
                        "bucket nearby. false = every tree that burns counts, even from lightning.")
                .define("fireNeedsPlayer", true);
        FIRE_MEMORY_MINUTES = b.comment("How long (in real minutes) the forest remembers where a player started a fire.")
                .defineInRange("fireMemoryMinutes", 20, 1, 600);
        ALL_EXPLOSIONS = b.comment("false = only TNT counts. true = any explosion that destroys a tree counts (creepers too).")
                .define("countAllExplosions", false);
        b.pop();

        b.comment("How the trees themselves behave.").push("trees");
        NATURAL_GROWTH_MULTIPLIER = b.comment("From stage 1 on, the normal Dynamic Trees growth rate is multiplied by this",
                        "(and by twice this at stage 5).")
                .defineInRange("naturalGrowthMultiplier", 2.0, 1.0, 20.0);
        MAX_TREE_HEIGHT = b.comment("From stage 2 on trees are allowed to grow this tall (in blocks).")
                .defineInRange("maxTreeHeight", 60, 8, 200);
        SAPLING_GROW_SECONDS = b.comment("From stage 2 on a sapling turns into a tree after about this many seconds",
                        "(half that at stage 5).")
                .defineInRange("saplingGrowSeconds", 60, 1, 3600);
        REGROW_CHANCE = b.comment("From the Relentless stage on, the chance a destroyed tree grows back one day later.")
                .defineInRange("regrowChance", 0.5, 0.0, 1.0);
        MIN_TREE_SPACING = b.comment("Blocks that must separate one tree from the next. 0 = trees may grow shoulder to shoulder,",
                        "which is what makes a forest genuinely impassable.")
                .defineInRange("minTreeSpacing", 0, 0, 8);
        b.pop();

        b.comment("Rhizomes and tendrils.").push("rhizomes");
        MAX_TIPS = b.comment("Most rhizome tips that may be growing in one dimension at the same time.",
                        "0 = no limit. Unlimited rhizomes on a busy server will cost you frames.")
                .defineInRange("maxActiveTips", 0, 0, 100000);
        MAX_RHIZOME_LENGTH = b.comment("A rhizome stops growing after this many blocks. 0 = it never stops.")
                .defineInRange("maxLength", 0, 0, 100000);
        RHIZOMES_DROP_BUILDS = b.comment("Root breaks a built block properly, so it drops as an item, instead of",
                        "simply replacing it. Natural ground is always just replaced - root grows through soil",
                        "and stone without anything falling out of it.")
                .define("builtBlocksDrop", true);
        RHIZOME_DEPTH = b.comment("How many blocks of ground a rhizome tries to keep over itself. Higher means it",
                        "stays buried, surfacing only where it has a reason to.")
                .defineInRange("burialDepth", 3, 1, 16);
        RHIZOMES_BREAK_BUILDS = b.comment("true = rhizomes and tendrils break through anything in their way (planks, glass, doors...).",
                        "false = they only move through natural ground and go around everything else.")
                .define("breakBuiltBlocks", true);
        BREAK_CONTAINERS = b.comment("true = chests, furnaces and other blocks that store things can be broken too.",
                        "Leave this false unless you want players to lose their storage.")
                .define("breakContainers", false);
        TENDRIL_DAMAGE = b.comment("Damage a tendril does each time it lashes a player (2.0 = one heart).")
                .defineInRange("tendrilDamage", 3.0, 0.0, 100.0);
        b.pop();

        b.comment("Fertilizer offerings, and what the forest does once it likes you. Favour is per player.").push("offerings");
        WRATH_PER_OFFERING = b.comment("How many destroyed trees one fertilizer makes up for, for the player who gives it.")
                .defineInRange("wrathPerOffering", 1, 0, 1000);
        BOON_1 = b.comment("Offerings needed before the trees start leaving you gifts.")
                .defineInRange("giftsAt", 45, 1, 100000);
        BOON_2 = b.comment("Offerings needed before they clear your way, avoid your base and fight for you.")
                .defineInRange("alliedAt", 120, 1, 100000);
        BOON_3 = b.comment("Offerings needed before they will throw whole trees at what is hunting you.")
                .defineInRange("guardianAt", 240, 1, 100000);
        BOON_4 = b.comment("Offerings needed before the forest weeds invasives out around you unasked.")
                .defineInRange("wardenAt", 450, 1, 100000);
        BOON_5 = b.comment("Offerings needed before the canopy itself keeps you on your feet.")
                .defineInRange("heartboundAt", 800, 1, 100000);
        GIFT_MINUTES = b.comment("Roughly how many minutes between gifts for one player.")
                .defineInRange("giftMinutes", 3, 1, 240);
        CLEAR_PATHS = b.comment("Allied forests pull leaves out of your way as you walk.")
                .define("clearPaths", true);
        AVOID_BASES = b.comment("Allied forests stop planting saplings right next to anything you built.")
                .define("avoidBases", true);
        b.pop();

        b.comment("Trees fighting back against mobs and players.").push("retaliation");
        DEFEND_PLAYERS = b.comment("Trees attack hostile mobs (to defend you, or out of spite after a mob damages them).")
                .define("defendAgainstMobs", true);
        TOPPLE_ON_MOBS = b.comment("Trees may throw themselves on top of a mob. This destroys the tree.")
                .define("toppleOnMobs", true);
        TOPPLE_ON_PLAYERS = b.comment("At the final stage, trees may deliberately fall on players.")
                .define("toppleOnPlayers", true);
        TOPPLE_COOLDOWN = b.comment("Seconds before the same player can have another tree dropped on them.")
                .defineInRange("toppleCooldownSeconds", 120, 5, 100000);
        CAGE_SECONDS = b.comment("Left over from the caging that used to happen. Nothing is caged any more;",
                        "this only controls how long any columns still standing in an old world take to rot away.")
                .defineInRange("cageSeconds", 12, 1, 600);
        GRUDGE_MINUTES = b.comment("How long trees stay angry at mobs after a mob (a creeper, say) destroys one of them.")
                .defineInRange("grudgeMinutes", 10, 1, 600);
        CRUSH_DAMAGE = b.comment("Damage from being under falling wood (2.0 = one heart). A dropped branch does half this.",
                        "A whole toppled tree uses Dynamic Trees' own falling-tree damage when that is switched on,",
                        "and this number when it is switched off.")
                .defineInRange("crushDamage", 8.0, 0.0, 100.0);
        b.pop();

        b.comment("Kudzu: the invasive weed that is beating the forest.").push("kudzu");
        KUDZU_ENABLED = b.comment("Turn the whole kudzu system on or off.")
                .define("enabled", true);
        KUDZU_SPREAD = b.comment("Blocks of kudzu that may appear per second, per dimension. This is the main dial:",
                        "40 is a creeping dread, 200 is a world-ending green tide.")
                .defineInRange("spreadPerSecond", 180, 1, 5000);
        KUDZU_STRANGLE_CHANCE = b.comment("Chance that kudzu reaching a trunk pulls the whole tree down.")
                .defineInRange("strangleChance", 0.35, 0.0, 1.0);
        KUDZU_TREE_RESISTANCE = b.comment("Chance a tree tears off a piece of kudzu touching it, each time the forest is checked.",
                        "Deliberately far slower than the weed grows: the trees are losing.")
                .defineInRange("treeResistance", 0.25, 0.0, 1.0);
        KUDZU_BREAKS_BUILDS = b.comment("Kudzu breaks through built blocks, and crushes what it piles on top of.")
                .define("breaksBuiltBlocks", true);
        KUDZU_MOBS = b.comment("Things breed in the dark under a kudzu canopy.")
                .define("spawnsMobs", true);
        KUDZU_MOBS_PER_MINUTE = b.comment("Most mobs kudzu may add per minute, per dimension.")
                .defineInRange("mobsPerMinute", 3, 0, 60);
        KUDZU_SEEDS_ITSELF = b.comment("Kudzu turns up on its own. Off by default: the only way into a world now is",
                        "the rite at an altar, which costs more than anyone should be willing to pay.")
                .define("appearsOnItsOwn", false);
        KUDZU_TRIGGER_TREES = b.comment("Trees a player must destroy before kudzu will find them on its own.",
                        "Only matters when appearsOnItsOwn is switched back on.")
                .defineInRange("arrivesAfterTrees", 40, 0, 100000);
        KUDZU_MIN_DISTANCE = b.comment("Closest an outbreak may begin to the player who caused it.")
                .defineInRange("minDistance", 40, 4, 256);
        KUDZU_MAX_DISTANCE = b.comment("Furthest an outbreak may begin from the player who caused it.")
                .defineInRange("maxDistance", 60, 4, 256);
        KUDZU_SEED_MINUTES = b.comment("Minutes between attempts for a new outbreak to start, when there is none.")
                .defineInRange("outbreakMinutes", 20, 1, 1000);
        KUDZU_PER_OFFERING = b.comment("Kudzu blocks a player must clear to earn the same favour as one fertilizer. 0 = off.")
                .defineInRange("blocksPerFavour", 20, 0, 10000);
        KUDZU_MAX_RUNNERS = b.comment("Most growing vine tips one dimension may have at once. Each one branches into more,",
                        "so this is the real brake on how explosive an outbreak gets.")
                .defineInRange("maxRunners", 2000, 1, 50000);
        KUDZU_BRANCH_EVERY = b.comment("A runner throws off a side runner after this many blocks. Lower means denser thickets.")
                .defineInRange("branchEvery", 3, 2, 100);
        KUDZU_LEAF_DENSITY = b.comment("Leaf blocks hung around each vine as it grows. This is what makes the mats and the shade.")
                .defineInRange("leafDensity", 5, 0, 16);

        KUDZU_BURY_DAMAGE = b.comment("Damage per second while a player is buried in kudzu (2.0 = one heart a second).",
                        "The leaf itself does not suffocate you: being buried is meant to be a fight to dig out,",
                        "not the instant death a solid block in your head would normally be.")
                .defineInRange("buryDamagePerSecond", 1.0, 0.0, 40.0);
        KUDZU_RUNNER_LIFE = b.comment("Blocks a single runner grows before it gives out. Short-lived runners that branch often",
                        "make a tangle of small threads rather than a few long ropes.")
                .defineInRange("runnerLife", 24, 4, 10000);
        KUDZU_HUNT_SPEED = b.comment("Blocks a runner lays per step once it has found somebody, against one",
                        "while it is only wandering. A runner that has your scent does not amble.")
                .defineInRange("huntSpeed", 3, 1, 20);
        KUDZU_DRAGS_DOWN = b.comment("Kudzu pulls anyone it has hold of down into itself, closing the hole over",
                        "them. This is the thing it does that actually kills people.")
                .define("dragsPlayersUnder", true);
        KUDZU_EATS_MOBS = b.comment("Kudzu tears at anything caught in it, and absorbs whatever dies there.",
                        "A kudzu wood feeds itself on the things breeding under its own canopy.")
                .define("eatsMobs", true);
        KUDZU_MOB_DAMAGE = b.comment("Damage a second to a mob standing in kudzu.")
                .defineInRange("mobDamagePerSecond", 2.0, 0.0, 100.0);
        KUDZU_MOB_BIOMASS = b.comment("Biomass the weed banks for something that dies in it.")
                .defineInRange("biomassPerKill", 25, 0, 100000);
        KUDZU_GAP = b.comment("Furthest a runner will reach across open air to get hold of something - a trunk,",
                        "a wall, a branch. Beyond this it gives up on the crossing and heads for the ground,",
                        "so vines bridge from tree to tree but never march out over open water.")
                .defineInRange("bridgeableGap", 3, 0, 32);
        KUDZU_BURROW_LENGTH = b.comment("Blocks a runner travels underground once it dives, laying root as it goes.")
                .defineInRange("burrowLength", 26, 1, 500);
        KUDZU_DIVE_CHANCE = b.comment("Chance per step that a surface runner dives underground of its own accord.",
                        "Higher means more of the plant is hidden below ground where you cannot cut it.")
                .defineInRange("diveChance", 0.45, 0.0, 1.0);
        KUDZU_HUNTS_PLAYERS = b.comment("Runners work their way toward players and try to grow into the space they stand in.")
                .define("huntsPlayers", true);
        KUDZU_HUNT_RANGE = b.comment("How far off a runner can sense a player.")
                .defineInRange("huntRange", 48, 4, 192);
        KUDZU_BURIES_PLAYERS = b.comment("A runner that reaches a player fills the space around them with leaf.",
                        "Blocks in your head suffocate you, so this can and will kill.")
                .define("buriesPlayers", true);
        b.pop();

        b.comment("The lesser invasives: worth growing, and worth penning in.").push("invasives");
        INVASIVES_ENABLED = b.comment("Bramble, gildvine and emberthorn exist and spread.")
                .define("enabled", true);
        INVASIVE_MAX_RUNNERS = b.comment("Most growing tips the lesser invasives may have at once, per dimension.")
                .defineInRange("maxRunners", 300, 1, 20000);
        INVASIVE_RUNNER_LIFE = b.comment("Blocks one tip grows before it gives out. They are far less persistent than kudzu.")
                .defineInRange("runnerLife", 30, 2, 5000);
        INVASIVE_ESCAPE_SIZE = b.comment("Blocks one species may add before everybody is told it has got away.")
                .defineInRange("escapeWarningSize", 120, 10, 100000);
        KNOTWEED_CANE_HEIGHT = b.comment("Tallest knotweed cane. In life it is three metres of bamboo-like stem,",
                        "so it should be looking over your head.")
                .defineInRange("knotweedCaneHeight", 7, 1, 32);
        KNOTWEED_CANE_SPACING = b.comment("Blocks between knotweed canes. Higher means a thin stand of tall poles",
                        "rather than a solid hedge.")
                .defineInRange("knotweedCaneSpacing", 3, 1, 16);
        INVASIVE_SHOOT_HEIGHT = b.comment("Tallest shoot a weed sends up out of a block it has just laid. Knotweed does it",
                        "most, bramble next. 0 turns shoots off and leaves everything flat on the floor.")
                .defineInRange("shootHeight", 3, 0, 16);
        INVASIVE_PER_OFFERING = b.comment("Blocks of the lesser invasives a player clears to earn one offering of favour.")
                .defineInRange("blocksPerFavour", 40, 0, 10000);

        BLACKBERRY_SPREAD = b.comment("Himalayan blackberry blocks per second. Slow, relentless, and full of fruit.")
                .defineInRange("blackberrySpread", 2, 0, 2000);
        BLACKBERRY_DAMAGE = b.comment("Damage a second to anything standing in a blackberry thicket.")
                .defineInRange("blackberryDamage", 1.0, 0.0, 40.0);
        KNOTWEED_SPREAD = b.comment("Japanese knotweed blocks per second. It comes up through whatever you laid down.")
                .defineInRange("knotweedSpread", 1, 0, 2000);
        KNOTWEED_DROPS_RUBBLE = b.comment("Knotweed drops what it breaks through, ore included. Off, and the stone it",
                        "comes up through is simply gone.")
                .define("knotweedDropsRubble", false);
        CHEATGRASS_SPREAD = b.comment("Cheatgrass blocks per second.")
                .defineInRange("cheatgrassSpread", 7, 0, 2000);
        CHEATGRASS_IGNITES = b.comment("Cheatgrass cures to tinder and starts fires, which is the entire reason it matters.")
                .define("cheatgrassBurns", true);
        CHEATGRASS_FIRE_CHANCE = b.comment("Chance per random tick that a stand of cheatgrass sets something alight.")
                .defineInRange("cheatgrassFireChance", 0.08, 0.0, 1.0);
        HYACINTH_SPREAD = b.comment("Water hyacinth blocks per second. It doubles in a fortnight in real life; it will",
                        "seal a river here just as happily.")
                .defineInRange("hyacinthSpread", 20, 0, 2000);
        WISTERIA_SPREAD = b.comment("Chinese wisteria blocks per second. It climbs, and what it climbs dies.")
                .defineInRange("wisteriaSpread", 20, 0, 2000);
        WISTERIA_STRANGLE = b.comment("Chance wisteria that reaches a trunk girdles the tree and brings it down.")
                .defineInRange("wisteriaStrangleChance", 0.5, 0.0, 1.0);
        WISTERIA_CRUSHES = b.comment("Wisteria breaks through built blocks, and crushes what it piles onto.",
                        "A mature vine weighs tons; a roof under one does not stay a roof.")
                .define("wisteriaCrushes", true);
        WISTERIA_THICKNESS = b.comment("Extra blocks of wisteria laid around each one it grows, which is what makes",
                        "the thick woody mats rather than a thin runner.")
                .defineInRange("wisteriaThickness", 3, 0, 10);
        WISTERIA_GRIP_SECONDS = b.comment("Seconds a player may stand in thick wisteria before it begins closing around them.",
                        "Walk away and the count unwinds; stay and it will have you.")
                .defineInRange("wisteriaGripSeconds", 12, 1, 600);
        WISTERIA_CRUSH_DAMAGE = b.comment("Damage a second once wisteria has closed over a player. It climbs the longer",
                        "they stay, so standing still is the mistake, not being caught once.")
                .defineInRange("wisteriaCrushDamage", 1.5, 0.0, 40.0);
        WISTERIA_STEP_TICKS = b.comment("Ticks each wisteria stem takes over a single block. Twenty is a second.",
                        "This is what makes it slow: it never hurries, and it never stops either.")
                .defineInRange("wisteriaTicksPerBlock", 22, 1, 1200);
        WISTERIA_HUNTS = b.comment("Wisteria works its way toward players. It is slow about it, and it does not stop.")
                .define("wisteriaHunts", true);
        WISTERIA_HUNT_RANGE = b.comment("How far off a wisteria runner can sense somebody to grow toward.")
                .defineInRange("wisteriaHuntRange", 64, 0, 256);
        WISTERIA_BASE_PRIORITY = b.comment("Chance a runner takes a built block over open ground when it has the choice.",
                        "High, because what it really wants is your walls.")
                .defineInRange("wisteriaPrefersBuildings", 0.8, 0.0, 1.0);
        WISTERIA_COLLAPSES = b.comment("What wisteria takes out from under a structure brings the rest down with it.")
                .define("wisteriaCausesCollapses", true);
        WISTERIA_COLLAPSE_HEIGHT = b.comment("How far up a collapse travels through built blocks.")
                .defineInRange("collapseHeight", 6, 1, 64);
        WISTERIA_REGROW = b.comment("Chance that cutting a piece of wisteria out sets the rest of the plant growing",
                        "back into the gap. Clearing it properly means taking the whole thing.")
                .defineInRange("wisteriaRegrowChance", 0.55, 0.0, 1.0);
        WISTERIA_FIREPROOF = b.comment("Wisteria is green, woody and wet: fire does not clear it the way it clears kudzu.",
                        "You have to cut it out.")
                .define("wisteriaResistsFire", true);
        STRANGLE_OTHERS = b.comment("Chance the other weeds kill a tree they get hold of.")
                .defineInRange("otherStrangleChance", 0.12, 0.0, 1.0);
        RAMPANT_SPEED = b.comment("What a species' spread is multiplied by once it has got away from you.")
                .defineInRange("rampantSpeedMultiplier", 2.5, 1.0, 20.0);
        ESCAPE_ANGER = b.comment("Trees added to the tally of whoever planted a species, the moment it gets loose.",
                        "The forest knows who brought it in.")
                .defineInRange("escapeAnger", 25, 0, 10000);
        RAMPANT_ANGER = b.comment("Further trees added every two minutes for as long as it stays loose.")
                .defineInRange("rampantAngerPerTwoMinutes", 6, 0, 10000);
        DELIBERATE_ANGER = b.comment("What both of those are multiplied by when you put the species there on purpose,",
                        "with a rite or by hand. Something that blew in on the wind is bad luck. Something you",
                        "planted is a decision, and the forest treats it as one.")
                .defineInRange("deliberateAngerMultiplier", 3.0, 1.0, 50.0);
        AMENDS_ENABLED = b.comment("Wiping out an escape you caused wins back every point of anger it cost you.")
                .define("amendsAllowed", true);
        AMENDS_SIZE = b.comment("How big the mess has to get, and how much of it you have to pull out by hand,",
                        "before the forest counts clearing it as making amends. Both must be met: the patch has",
                        "to have grown this many blocks, and you have to have cut this many of them out.",
                        "Pulling up a weed you planted five minutes ago proves nothing.")
                .defineInRange("amendsSize", 400, 1, 1000000);
        b.pop();

        b.comment("The four ways of being in these woods.").push("classes");
        CLASSES_ENABLED = b.comment("Players choose a class the first time they join.")
                .define("enabled", true);
        RITUAL_BOOK = b.comment("A book is handed over the first time a player joins, explaining what the",
                        "forest counts and what it will trade.")
                .define("ritualBook", true);
        SKILL_PER_FELLED = b.comment("Trees felled per extra skill point, on top of the two ladders.")
                .defineInRange("pointPerFelledTrees", 20, 1, 100000);
        SKILL_PER_OFFERING = b.comment("Offerings given per extra skill point.")
                .defineInRange("pointPerOfferings", 50, 1, 100000);
        SKILLS_ENABLED = b.comment("The skill tree, opened with U. Points come from every rung of the forest's",
                        "anger and every rung of its goodwill, counted off the furthest you have ever got.")
                .define("skillTree", true);
        DRUID_FAVOUR = b.comment("What the Druid multiplies earned favour by.")
                .defineInRange("druidFavourRate", 2.5, 0.0, 100.0);
        DRUID_MARK_SECONDS = b.comment("How long a Druid's mark stays on a target before the woods lose interest.")
                .defineInRange("druidMarkSeconds", 45, 1, 3600);
        COLONIALIST_ANGER = b.comment("What the Colonialist multiplies earned anger by. He is resented out of",
                        "all proportion, and trades on it.")
                .defineInRange("colonialistAngerRate", 1.8, 0.0, 100.0);
        COLONIALIST_HEARTWOOD = b.comment("What the Colonialist multiplies heartwood from felling by.")
                .defineInRange("colonialistHeartwoodRate", 4.0, 0.0, 100.0);
        COLONIALIST_CLEARING = b.comment("Blocks of open ground around a Colonialist, with no tree in it, before",
                        "the clearing starts paying him.")
                .defineInRange("clearingRadius", 14, 2, 64);
        INVADER_RITE_COST = b.comment("What the Invader multiplies the price of an invasive species by.")
                .defineInRange("invaderRiteCost", 0.3, 0.0, 10.0);
        INVADER_WEED_DAMAGE = b.comment("What an Invader's weeds multiply their damage to everything else by.")
                .defineInRange("invaderWeedDamage", 2.5, 0.0, 100.0);
        GREEN_HAND_COOLDOWN = b.comment("Seconds between callings of one plant, before rank shortens it.")
                .defineInRange("greenHandCooldown", 12, 1, 600);
        GREEN_HAND_MINIMUM = b.comment("Blocks of a species that must be loose in the world before calling it",
                        "does anything at all. A power you have not planted for is no power.")
                .defineInRange("greenHandMinimum", 40, 0, 100000);
        GREEN_HAND_MAX_POWER = b.comment("Ceiling on how strong a calling gets, however much green there is.")
                .defineInRange("greenHandMaxPower", 10.0, 0.5, 50.0);
        GREEN_HAND_BACKFIRE = b.comment("How sharply the risk of it turning on you rises with the weight of",
                        "green in the world. At the default it only reaches the cap on a full pool, so the",
                        "risk climbs across a whole playthrough instead of arriving at once.")
                .defineInRange("greenHandBackfire", 0.20, 0.0, 10.0);
        GREEN_HAND_BACKFIRE_CAP = b.comment("The most it will ever turn on you. A power that fails half the",
                        "time is not a power, so this stays low.")
                .defineInRange("greenHandBackfireCap", 0.20, 0.0, 1.0);
        INVADER_CONSUMED_AT = b.comment("Blocks of loose invasive in the world before the Invader's own weeds stop",
                        "recognising him. Past this he is just more biomass.")
                .defineInRange("consumedAt", 2500, 1, 1000000);
        MUSHROOM_SPREAD_SECONDS = b.comment("Seconds between a Mushroom's fungus swelling around wherever he stands.")
                .defineInRange("mushroomSpreadSeconds", 8, 1, 3600);
        MUSHROOM_ORIGINAL_COST = b.comment("Tribute the Original asks for. It should be most of a playthrough.")
                .defineInRange("originalCost", 1800, 1, 1000000);
        MUSHROOM_HAZE_RANGE = b.comment("How far the Original's influence reaches.")
                .defineInRange("hazeRange", 48, 4, 256);
        MUSHROOM_SHIELD = b.comment("Nothing comes within arm's reach of a Mushroom. Whatever tries is put back",
                        "down further out than it meant to be.")
                .define("shimmerShield", true);
        MUSHROOM_SHIELD_RANGE = b.comment("How close anything gets before the shimmer moves it.")
                .defineInRange("shieldRange", 2.0, 0.0, 16.0);
        MUSHROOM_DODGE = b.comment("Chance an attack on a Mushroom simply does not connect.")
                .defineInRange("dodgeChance", 0.5, 0.0, 1.0);
        ORIGINAL_MUSIC = b.comment("The Original makes a noise. It is not pleasant and it does not stop.")
                .define("drone", true);
        ORIGINAL_HEIGHT = b.comment("How high the Original's stalk goes. It is meant to be visible from a long way off.")
                .defineInRange("originalHeight", 170, 8, 320);
        ORIGINAL_CAP = b.comment("Radius of the Original's cap. It should put a valley in shadow.")
                .defineInRange("originalCapRadius", 34, 2, 96);
        ORIGINAL_GIRTH = b.comment("How thick the stalk is at its widest.")
                .defineInRange("originalGirth", 6, 1, 32);
        MUSHROOM_OPPORTUNISM = b.comment("Where a wood has been cut to almost nothing, fungus reads the gap",
                        "and takes the ground. This happens whether or not anybody chose the Mushroom.")
                .define("fungusTakesClearedGround", true);
        MUSHROOM_IMBALANCE = b.comment("How little standing wood has to be left, out of ninety samples taken",
                        "around a player, before the fungus considers the place open.")
                .defineInRange("imbalanceThreshold", 3, 0, 90);
        ORIGINAL_LIMIT = b.comment("Most Originals one dimension may carry. The Call will not raise another",
                        "once this many stand, however long it is left.")
                .defineInRange("originalLimit", 8, 1, 200);
        ORIGINAL_BREED_MINUTES = b.comment("Minutes between an Original putting up another one of its own",
                        "accord, once somebody has taken the last rank of the Call.")
                .defineInRange("originalBreedMinutes", 10, 1, 1000);
        ORIGINAL_WORDS = b.comment("Scraps of language drift through the air near an Original. Some of it is",
                        "nearly readable. Turn this off if floating text upsets your framerate.")
                .define("driftingWords", true);
        b.pop();

        b.comment("Biomass: what the forest and the weeds have to spend, and where they put it.").push("biomass");
        BIOMASS_ENABLED = b.comment("The forest banks what its trees make and spends it deliberately.")
                .define("enabled", true);
        BIOMASS_PER_TREE = b.comment("Biomass one standing tree makes per day. The more wood there is, the more",
                        "there is to move around, so a wood that has already overgrown a valley grows faster still.")
                .defineInRange("perTreePerDay", 1.0, 0.0, 1000.0);
        BIOMASS_PER_WEED = b.comment("Biomass one block of an invasive makes per day, into the weeds' own pool.")
                .defineInRange("perWeedBlockPerDay", 0.04, 0.0, 1000.0);
        BIOMASS_CAP = b.comment("Most biomass either pool may hold. This is the size of the hammer the forest",
                        "can bring down in one place.")
                .defineInRange("poolCap", 4000.0, 1.0, 1000000.0);
        BIOMASS_PER_SIGNAL = b.comment("Biomass one extra pulse of tree growth costs.")
                .defineInRange("costPerGrowthPulse", 1.0, 0.01, 1000.0);
        BIOMASS_PER_WEED_BLOCK = b.comment("Biomass one extra block of weed costs.")
                .defineInRange("costPerWeedBlock", 0.5, 0.01, 1000.0);
        BIOMASS_CHANNEL_SHARE = b.comment("Share of the whole pool a single tree may take while the forest is",
                        "channelling. High, deliberately: the point is that everything goes to one place.")
                .defineInRange("channelShare", 0.25, 0.0, 1.0);
        BIOMASS_CHANNEL_MAX = b.comment("Most extra pulses one tree may take in a visit while being channelled into.",
                        "This is what makes trees near you erupt rather than merely grow.")
                .defineInRange("channelPulseLimit", 24, 0, 10000);
        BIOMASS_SPREAD_MAX = b.comment("Most extra pulses one tree may take while the pool is being spread evenly.")
                .defineInRange("spreadPulseLimit", 3, 0, 10000);
        BIOMASS_FOCUS_RANGE = b.comment("How close a tree must be to where the forest is aiming to get any of it.")
                .defineInRange("focusRange", 40, 4, 256);
        BIOMASS_FOCUS_SECONDS = b.comment("Seconds the forest holds its aim before picking a new spot. Long enough",
                        "that the growth stays where you are standing rather than chasing you about.")
                .defineInRange("focusSeconds", 45, 1, 3600);
        b.pop();

        b.comment("The plants that belong here. Picking costs a little; replanting earns a little less.")
                .push("natives");
        NATIVES_ENABLED = b.comment("Native plants are tracked at all.")
                .define("enabled", true);
        NATIVE_PICKS_PER_TREE = b.comment("Pickings that add up to one felled tree's worth of resentment.",
                        "Six means an ordinary plant costs a sixth of a tree.")
                .defineInRange("picksPerTree", 6, 1, 1000);
        NATIVE_TRILLIUM_COST = b.comment("What one trillium counts as, in pickings. A trillium takes years to come back",
                        "from being picked, and the forest prices it accordingly.")
                .defineInRange("trilliumPickCost", 4, 1, 100);
        NATIVE_PLANTS_PER_OFFERING = b.comment("Plants put in the ground to earn one offering of favour. Deliberately worse",
                        "value than picking is bad, so pulling plants up and pushing them back in loses ground.")
                .defineInRange("plantsPerOffering", 8, 1, 1000);
        NATIVE_FAVOUR_PER_DAY = b.comment("Most favour a day of planting can earn. 0 removes the cap.")
                .defineInRange("favourPerDay", 5, 0, 1000);
        NATIVE_SPREAD_CHANCE = b.comment("Chance a native plant creeps into the ground beside it on a random tick.",
                        "This is why picking them is forgivable at all: left alone, they come back.")
                .defineInRange("spreadChance", 0.15, 0.0, 1.0);
        HEARTWOOD_FROM_FELLING = b.comment("Heartwood a felled tree yields. Below 1 this is a chance per tree.",
                        "The forest still gives it to those it likes; this is the other road to it.")
                .defineInRange("heartwoodPerFelledTree", 0.18, 0.0, 64.0);
        NATIVE_DENSITY = b.comment("How many of the same plant may stand within two blocks before a stand stops",
                        "thickening up.")
                .defineInRange("standDensity", 6, 1, 200);
        b.pop();

        b.comment("Altars, rites and sacrifices.").push("rituals");
        TRIBUTE_PER_ITEM = b.comment("Tribute earned per item left on the altar. Rites are paid for in bulk: a chest",
                        "of goods, or a herd.")
                .defineInRange("tributePerItem", 2, 0, 1000);
        TRIBUTE_PER_LOG = b.comment("Tribute earned per log left on the altar. Far more than anything else is",
                        "worth, because it is the forest's own body being handed back to it. This is the",
                        "straightforward way to pay for a rite: fell a stand and give the timber up.")
                .defineInRange("tributePerLog", 6, 0, 1000);
        TRIBUTE_PER_PLANK = b.comment("Tribute earned per plank, or anything else made of wood.")
                .defineInRange("tributePerPlank", 3, 0, 1000);
        TRIBUTE_MONSTER = b.comment("Tribute earned for a hostile mob killed on an altar.")
                .defineInRange("tributePerMonster", 4, 0, 10000);
        TRIBUTE_ANIMAL = b.comment("Tribute earned for an animal killed on an altar.")
                .defineInRange("tributePerAnimal", 15, 0, 10000);
        TRIBUTE_PET = b.comment("Tribute earned for a tamed animal killed on an altar.")
                .defineInRange("tributePerTamedPet", 60, 0, 10000);
        TRIBUTE_BLACKBERRY = b.comment("Tribute the Rite of Seeding wants for Himalayan blackberry.")
                .defineInRange("seedingCostBlackberry", 30, 0, 1000000);
        TRIBUTE_KNOTWEED = b.comment("Tribute the Rite of Seeding wants for Japanese knotweed.")
                .defineInRange("seedingCostKnotweed", 55, 0, 1000000);
        TRIBUTE_CHEATGRASS = b.comment("Tribute the Rite of Seeding wants for cheatgrass.")
                .defineInRange("seedingCostCheatgrass", 40, 0, 1000000);
        TRIBUTE_HYACINTH = b.comment("Tribute the Rite of Seeding wants for water hyacinth.")
                .defineInRange("seedingCostHyacinth", 35, 0, 1000000);
        TRIBUTE_WISTERIA = b.comment("Tribute the Rite of Seeding wants for Chinese wisteria.")
                .defineInRange("seedingCostWisteria", 45, 0, 1000000);
        TRIBUTE_KUDZU = b.comment("Tribute the Rite of Blight wants for kudzu itself. It should be ruinous: there is",
                        "no other way to get kudzu into a world now, and there is no way to get it back out.")
                .defineInRange("blightCostKudzu", 300, 0, 1000000);
        RITE_GROVE_SIZE = b.comment("Saplings called up by the Rite of Groves.")
                .defineInRange("groveSaplings", 14, 1, 200);
        RITE_SEEDING_SIZE = b.comment("Radius of the stand the Rite of Seeding lays down.")
                .defineInRange("seedingRadius", 3, 1, 16);
        RITE_ROOTS = b.comment("Rhizomes called up by the Rite of Roots.")
                .defineInRange("riteRoots", 6, 1, 100);
        RITE_BARGAIN_LOGS = b.comment("Logs the forest hands over for the Rite of the Bargain.")
                .defineInRange("bargainLogs", 32, 1, 64);
        RITE_BARGAIN_COST = b.comment("Trees added to your tally for taking that timber. This is how you make the",
                        "forest hate you on purpose, if the wood is worth it to you.")
                .defineInRange("bargainCost", 12, 0, 1000);
        RITE_BLIGHT_COST = b.comment("Trees added to your tally for letting the weed in deliberately.")
                .defineInRange("blightCost", 20, 0, 1000);
        RITE_QUIET_COST = b.comment("Tribute the Rite of Quiet asks to buy back some of the forest's memory.",
                        "Expensive on purpose: a last resort, not a way of life.")
                .defineInRange("quietCost", 260, 0, 1000000);
        RITE_QUIET_TREES = b.comment("Trees the Rite of Quiet takes off your tally.")
                .defineInRange("quietForgives", 14, 1, 10000);
        RITE_FERTILIZER_WORTH = b.comment("Offerings credited for fertilizer left on an altar rather than fed to a tree.")
                .defineInRange("fertilizerOnAltar", 2, 1, 100);
        SACRIFICES = b.comment("The forest notices what dies within six blocks of an altar.")
                .define("sacrificesCount", true);
        SACRIFICE_MONSTER = b.comment("Offerings earned for killing a hostile mob on an altar.")
                .defineInRange("monsterWorth", 1, 0, 1000);
        SACRIFICE_ANIMAL = b.comment("Offerings earned for killing an animal on an altar.")
                .defineInRange("animalWorth", 3, 0, 1000);
        SACRIFICE_PET = b.comment("Offerings earned for killing a tamed animal on an altar. The forest counts a",
                        "creature that trusted you for far more than one that did not.")
                .defineInRange("tamedPetWorth", 15, 0, 1000);
        ARMOUR_SOFTENS = b.comment("A full set of heartwood armour makes the forest treat you as one stage calmer.")
                .define("heartwoodArmourSoftens", true);
        BRUSH_HOOK_RADIUS = b.comment("Blocks cleared either side of the spot when a brush hook is swung at kudzu.")
                .defineInRange("brushHookRadius", 2, 1, 6);
        b.pop();

        b.comment("Whether a server plays this one player at a time or all together.").push("sharing");
        SHARE_STANDING = b.comment("false = every player has their own standing: the forest hates and favours each of",
                        "them separately, which is the default and what singleplayer wants.",
                        "true = one standing for the whole server. Every tree anybody fells counts against all of",
                        "them, every offering anybody makes counts for all of them, and the stage everyone is at",
                        "is the same stage. On a server where one person logging on to clear land would otherwise",
                        "leave the rest untouched, this is the setting that makes the woods a shared problem.",
                        "Switching it on does not merge what players have already done; the shared tally starts",
                        "where it was left, and each player's own tally is kept in case it is switched back.")
                .define("shareStanding", false);
        SHARE_SKILLS = b.comment("false = every player earns and spends their own skill points.",
                        "true = one pool of points and one set of ranks for the whole server, so a power bought",
                        "by anybody is held by everybody who can use it. With shareStanding off as well, the pool",
                        "grows by the furthest any one player has pushed the forest plus everything all of them",
                        "have felled and given, so a group is not punished for splitting the work up.",
                        "Class-only skills still only do anything for a player of that class.",
                        "The shared tree starts empty: ranks players bought on their own are kept, set aside, and",
                        "come back if this is switched off again.")
                .define("shareSkills", false);
        b.pop();

        b.comment("Performance and feedback.").push("general");
        ACTIVE_RADIUS = b.comment("How close a player has to be for their own standing to govern a tree.",
                        "It no longer limits where the forest acts: trees work wherever their chunk is ticking.")
                .defineInRange("activeRadius", 64, 16, 160);
        SCAN_RADIUS = b.comment("How far out, in blocks, the mod looks for trees it has not found yet. Anything inside",
                        "this range that is still loaded gets picked up and driven, seen or not.")
                .defineInRange("scanRadius", 256, 32, 1024);
        MAX_TREES = b.comment("Most trees the mod will drive per dimension. 0 = no limit.",
                        "With no limit a mature forest can end up driving thousands of trees; raise treesPerTick with it.")
                .defineInRange("maxTrackedTrees", 0, 0, 1000000);
        TREES_PER_TICK = b.comment("How many trees are processed each game tick. Lower this if the server lags,",
                        "raise it if you have removed the tree limit and growth feels sluggish.")
                .defineInRange("treesPerTick", 12, 1, 256);
        ANNOUNCE = b.comment("Show a message and play a sound to everyone when a new stage is reached.")
                .define("announceStages", true);
        SHOW_COUNTER = b.comment("Show the running total above the hotbar every time a tree is counted.")
                .define("showCounter", false);
        b.pop();

        SPEC = b.build();
    }

    private Config() {
    }
}
