package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.RegistryObject;

import java.util.Locale;

/**
 * Real weeds, with the habits they actually have.
 * <p>
 * Kudzu is the worst of them and has a system of its own. These four are the ones you might reasonably decide
 * to keep: every one pays for itself, every one gets away from people constantly in the real world, and every
 * one is held back by the thing that actually holds it back.
 */
public enum Invasive {

    /**
     * Himalayan blackberry (Rubus armeniacus). Sold as a fruit crop, now a thicket you cannot walk through
     * across half the Pacific Northwest. Thorns tear at anything in it. Mowing and hard standing stop it.
     */
    BLACKBERRY,

    /**
     * Japanese knotweed (Fallopia japonica). Comes up through tarmac, floors and foundations; in Britain it
     * can sink a mortgage. The shoots are edible. Only a proper root barrier turns it.
     */
    KNOTWEED,

    /**
     * Cheatgrass (Bromus tectorum). Cures to tinder by midsummer and has rewritten the fire cycle of the
     * Great Basin. Dries, burns, and comes back first. Nothing crosses water.
     */
    CHEATGRASS,

    /**
     * Water hyacinth (Eichhornia crassipes). The most beautiful of them and the most strangling: it doubles
     * in a fortnight and seals rivers shut. It cannot leave the water, which is the only mercy.
     */
    WATER_HYACINTH,

    /**
     * Chinese wisteria (Wisteria sinensis). Planted everywhere for the flowers, and it repays you by climbing
     * mature trees, girdling them and pulling them down under its own weight. Nothing in this mod kills more
     * trees. It needs something rough to climb; it cannot get a grip on glass or metal.
     */
    WISTERIA;

    public RegistryObject<Block> block() {
        switch (this) {
            case BLACKBERRY:
                return VengefulWoods.BLACKBERRY;
            case KNOTWEED:
                return VengefulWoods.KNOTWEED;
            case CHEATGRASS:
                return VengefulWoods.CHEATGRASS;
            case WATER_HYACINTH:
                return VengefulWoods.WATER_HYACINTH;
            default:
                return VengefulWoods.WISTERIA;
        }
    }

    public RegistryObject<Item> harvest() {
        switch (this) {
            case BLACKBERRY:
                return VengefulWoods.BLACKBERRIES;
            case KNOTWEED:
                return VengefulWoods.KNOTWEED_SHOOTS;
            case CHEATGRASS:
                return VengefulWoods.DRY_THATCH;
            case WATER_HYACINTH:
                return VengefulWoods.HYACINTH_FIBRE;
            default:
                return VengefulWoods.WISTERIA_BLOOMS;
        }
    }

    /** Blocks per second this one may put down, per dimension. */
    public int spreadPerSecond() {
        switch (this) {
            case BLACKBERRY:
                return Config.BLACKBERRY_SPREAD.get();
            case KNOTWEED:
                return Config.KNOTWEED_SPREAD.get();
            case CHEATGRASS:
                return Config.CHEATGRASS_SPREAD.get();
            case WATER_HYACINTH:
                return Config.HYACINTH_SPREAD.get();
            default:
                return Config.WISTERIA_SPREAD.get();
        }
    }

    public int maxRunners() {
        return Config.INVASIVE_MAX_RUNNERS.get();
    }

    /** Tribute the altar wants before it will hand this one over. */
    public int tributeCost() {
        switch (this) {
            case BLACKBERRY:
                return Config.TRIBUTE_BLACKBERRY.get();
            case KNOTWEED:
                return Config.TRIBUTE_KNOTWEED.get();
            case CHEATGRASS:
                return Config.TRIBUTE_CHEATGRASS.get();
            case WATER_HYACINTH:
                return Config.TRIBUTE_HYACINTH.get();
            default:
                return Config.TRIBUTE_WISTERIA.get();
        }
    }

    public boolean isBody(BlockState state) {
        if (state.is(block().get())) {
            return true;
        }
        // Several of these are more than one block. Every part is the plant, so cutting one and leaving the
        // others clears nothing at all.
        switch (this) {
            case WISTERIA:
                return state.is(VengefulWoods.WISTERIA_BLOOM.get());
            case BLACKBERRY:
                return state.is(VengefulWoods.BLACKBERRY_ROOT.get())
                        || state.is(VengefulWoods.BLACKBERRY_CANE.get());
            case KNOTWEED:
                return state.is(VengefulWoods.KNOTWEED_ROOT.get())
                        || state.is(VengefulWoods.KNOTWEED_STEM.get());
            default:
                return false;
        }
    }

    /** The part that travels below ground, where this plant has one. */
    @javax.annotation.Nullable
    public RegistryObject<Block> root() {
        switch (this) {
            case BLACKBERRY:
                return VengefulWoods.BLACKBERRY_ROOT;
            case KNOTWEED:
                return VengefulWoods.KNOTWEED_ROOT;
            default:
                return null;
        }
    }

    /** The part that stands up out of the ground, where this plant has one. */
    @javax.annotation.Nullable
    public RegistryObject<Block> stem() {
        switch (this) {
            case BLACKBERRY:
                return VengefulWoods.BLACKBERRY_CANE;
            case KNOTWEED:
                return VengefulWoods.KNOTWEED_STEM;
            case WISTERIA:
                return VengefulWoods.WISTERIA_BLOOM;
            default:
                return null;
        }
    }

    /** The decorative half of a species, where it has one. Grown alongside the body, never instead of it. */
    @javax.annotation.Nullable
    public RegistryObject<Block> drape() {
        return this == WISTERIA ? VengefulWoods.WISTERIA_BLOOM : null;
    }

    /** The ground each one actually takes. This is also what decides which rite a place will answer. */
    public boolean canTravel(BlockState state) {
        switch (this) {
            case BLACKBERRY:
                // Disturbed ground, field edges, woodland margins.
                return state.is(BlockTags.DIRT) || state.is(Blocks.GRASS_BLOCK) || state.is(Blocks.PODZOL)
                        || state.is(Blocks.MOSS_BLOCK) || state.is(BlockTags.LEAVES) || state.is(Blocks.FARMLAND);
            case KNOTWEED:
                // Rubble, rock, made ground - and straight up through anything laid on top of it.
                return state.is(BlockTags.BASE_STONE_OVERWORLD) || state.is(BlockTags.STONE_ORE_REPLACEABLES)
                        || state.is(BlockTags.DEEPSLATE_ORE_REPLACEABLES) || state.is(Blocks.GRAVEL)
                        || state.is(BlockTags.DIRT) || state.is(BlockTags.STONE_BRICKS)
                        || state.is(Blocks.BRICKS) || state.is(Blocks.SMOOTH_STONE)
                        || state.is(Blocks.COBBLESTONE) || state.is(Blocks.CLAY);
            case CHEATGRASS:
                // Dry, open, overgrazed country.
                return state.is(BlockTags.SAND) || state.is(BlockTags.DIRT) || state.is(Blocks.GRASS_BLOCK)
                        || state.is(BlockTags.TERRACOTTA) || state.is(Blocks.TERRACOTTA) || state.is(Blocks.GRAVEL);
            case WATER_HYACINTH:
                // Still fresh water, and nothing else at all.
                return false;
            default:
                // Anything with a grain to it: bark, leaf, stone, soil. It climbs whatever it can hold on to.
                return state.is(BlockTags.LOGS) || state.is(BlockTags.LEAVES) || state.is(BlockTags.DIRT)
                        || state.is(Blocks.GRASS_BLOCK) || state.is(BlockTags.BASE_STONE_OVERWORLD)
                        || state.is(BlockTags.PLANKS) || state.is(BlockTags.WALLS)
                        || com.ferreusveritas.dynamictrees.api.TreeHelper.isTreePart(state);
        }
    }

    /** Water hyacinth floats: it spreads across the surface and will not come ashore. */
    public boolean needsWater() {
        return this == WATER_HYACINTH;
    }

    /** The thing that actually stops it. Get this wrong and your fence is decoration. */
    public boolean isBarrier(ServerLevel level, BlockPos pos, BlockState state) {
        switch (this) {
            case BLACKBERRY:
                // Hard standing. You beat brambles with paving, not with willpower.
                return state.is(BlockTags.STONE_BRICKS) || state.is(BlockTags.SLABS) || state.is(BlockTags.WALLS)
                        || state.is(Blocks.SMOOTH_STONE) || state.is(Blocks.BRICKS) || state.is(Blocks.POLISHED_ANDESITE);
            case KNOTWEED:
                // A real root barrier: sheet metal buried deep. Nothing softer is any use against it.
                return state.is(Blocks.IRON_BLOCK) || state.is(Blocks.COPPER_BLOCK) || state.is(Blocks.GOLD_BLOCK)
                        || state.is(Blocks.NETHERITE_BLOCK) || state.is(Blocks.OBSIDIAN)
                        || state.is(Blocks.CUT_COPPER) || state.is(Blocks.WAXED_CUT_COPPER);
            case CHEATGRASS:
                // Green firebreaks and water.
                if (!state.getFluidState().isEmpty() || state.is(Blocks.WATER)) {
                    return true;
                }
                for (Direction dir : Direction.values()) {
                    BlockPos side = pos.relative(dir);
                    if (level.isLoaded(side) && !level.getBlockState(side).getFluidState().isEmpty()) {
                        return true;
                    }
                }
                return false;
            case WATER_HYACINTH:
                // Hyacinth is stopped by dry land and by booms laid across the water.
                return state.is(BlockTags.LOGS) || state.is(BlockTags.PLANKS) || state.is(BlockTags.FENCES)
                        || state.is(Blocks.IRON_BARS);
            default:
                // Wisteria needs purchase. It slides off anything smooth.
                return state.is(Blocks.GLASS) || state.is(BlockTags.IMPERMEABLE) || state.is(Blocks.IRON_BLOCK)
                        || state.is(Blocks.COPPER_BLOCK) || state.is(Blocks.GOLD_BLOCK) || state.is(Blocks.ICE)
                        || state.is(Blocks.PACKED_ICE) || state.is(Blocks.IRON_BARS);
        }
    }

    /** How readily this one kills a tree it has got hold of. Wisteria is in a class of its own here. */
    public double strangleChance() {
        switch (this) {
            case WISTERIA:
                return Config.WISTERIA_STRANGLE.get();
            case KNOTWEED:
                return Config.STRANGLE_OTHERS.get() * 0.5;
            case WATER_HYACINTH:
                return 0.0;
            default:
                return Config.STRANGLE_OTHERS.get();
        }
    }

    /** Wisteria climbs; the rest keep low. */
    public boolean climbs() {
        return this == WISTERIA;
    }

    public String id() {
        return name().toLowerCase(Locale.ROOT);
    }

    public String translationKey() {
        return "message.vengefulwoods.escaped." + id();
    }
}
