package com.vengefulwoods;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * The tree.
 * <p>
 * Nothing a class does is free any more. The shimmer, the clearing, the marking - all of it starts locked,
 * and all of it goes up in ranks rather than simply switching on. Each branch needs the one above it, so
 * the order you take things in is a decision instead of a shopping list.
 */
public enum Skill {

    // ---------------------------------------------------------------- open to anyone
    THICK_SKIN("thick_skin", null, null, 3, 1, 0, 0, () -> VengefulWoods.WOVEN_CHESTPLATE.get()),
    SURE_FOOT("sure_foot", null, null, 2, 1, 0, 1, () -> VengefulWoods.HEARTWOOD_BOOTS.get()),
    FORAGER("forager", null, null, 2, 1, 0, 2, () -> VengefulWoods.BLACKBERRIES.get()),
    QUIET_STEP("quiet_step", null, null, 2, 1, 0, 3, () -> VengefulWoods.SWEETGRASS_BRAID.get()),

    // ---------------------------------------------------------------- Druid
    /** The whole marking business, which the Druid no longer simply has. */
    MARKING("marking", WoodsClass.DRUID, null, 3, 2, 1, 0, () -> VengefulWoods.GROVE_CHARM.get()),
    GREEN_TONGUE("green_tongue", WoodsClass.DRUID, MARKING, 3, 2, 2, 0, () -> VengefulWoods.FERTILIZER.get()),
    WARDEN_CALL("warden_call", WoodsClass.DRUID, MARKING, 2, 2, 2, 1, () -> VengefulWoods.ROOT_TOTEM.get()),
    GROVEBORN("groveborn", WoodsClass.DRUID, GREEN_TONGUE, 2, 3, 3, 0, () -> VengefulWoods.HEARTWOOD.get()),

    // ---------------------------------------------------------------- Colonialist
    /** Open ground stops being merely safe and starts being an advantage. */
    CLEARING("clearing", WoodsClass.COLONIALIST, null, 3, 2, 1, 0, () -> Items.CAMPFIRE),
    EMBER_AXE("ember_axe", WoodsClass.COLONIALIST, CLEARING, 3, 2, 2, 0, () -> VengefulWoods.HEARTWOOD_AXE.get()),
    TIMBERMAN("timberman", WoodsClass.COLONIALIST, CLEARING, 3, 2, 2, 1, () -> VengefulWoods.HEARTWOOD.get()),
    WILDFIRE("wildfire", WoodsClass.COLONIALIST, EMBER_AXE, 2, 3, 3, 0, () -> Items.FLINT_AND_STEEL),

    // ---------------------------------------------------------------- Invader
    /** Without this the weeds are only weeds. With it they answer to the thing holding them. */
    GREEN_HAND("green_hand", WoodsClass.INVADER, null, 1, 2, 1, 0, () -> VengefulWoods.KUDZU_FIBRE.get()),
    STRANGLE("strangle", WoodsClass.INVADER, GREEN_HAND, 3, 2, 2, 0, () -> VengefulWoods.WISTERIA_ITEM.get()),
    TIDE("tide", WoodsClass.INVADER, GREEN_HAND, 3, 2, 2, 1, () -> VengefulWoods.KUDZU_ITEM.get()),
    IMPALE("impale", WoodsClass.INVADER, GREEN_HAND, 3, 2, 2, 2, () -> VengefulWoods.KNOTWEED_ITEM.get()),
    SYMBIOTE("symbiote", WoodsClass.INVADER, GREEN_HAND, 2, 3, 3, 0, () -> VengefulWoods.BLACKBERRY_ITEM.get()),

    // ---------------------------------------------------------------- Mushroom
    /** The field. It does not exist until this is taken. */
    SHIMMER("shimmer", WoodsClass.MUSHROOM, null, 3, 2, 1, 0, () -> VengefulWoods.EYE_ITEM.get()),
    SPOREBORNE("sporeborne", WoodsClass.MUSHROOM, SHIMMER, 3, 2, 2, 0, () -> VengefulWoods.SPORE_IDOL.get()),
    MYCELIAL("mycelial", WoodsClass.MUSHROOM, SHIMMER, 3, 2, 2, 1, () -> Items.RED_MUSHROOM),
    /** A cloud of it, thrown out around you, that takes everyone's eyes but yours. */
    SPORE_CLOUD("spore_cloud", WoodsClass.MUSHROOM, SPOREBORNE, 3, 2, 3, 0, () -> Items.BROWN_MUSHROOM),
    /** Standing on your own ground mends you, and feeds the weed. */
    DEEP_ROOT("deep_root", WoodsClass.MUSHROOM, MYCELIAL, 3, 2, 3, 1, () -> Items.RED_MUSHROOM),
    MANY_EYES("many_eyes", WoodsClass.MUSHROOM, MYCELIAL, 5, 2, 3, 2, () -> Items.ENDER_EYE),
    /**
     * The last thing in the tree. The Original stops being a place you built and starts being something
     * that follows you, and then something that breeds.
     */
    THE_CALL("the_call", WoodsClass.MUSHROOM, MANY_EYES, 3, 4, 4, 1, () -> VengefulWoods.EYE_ITEM.get());

    private final String id;
    @Nullable
    public final WoodsClass only;
    /** What must be learned first. A branch is dead until its parent has at least one rank. */
    @Nullable
    public final Skill requires;
    public final int maxRank;
    public final int costPerRank;
    private final int row;
    private final int column;
    private final Supplier<Item> icon;

    Skill(String id, @Nullable WoodsClass only, @Nullable Skill requires, int maxRank, int costPerRank,
          int row, int column, Supplier<Item> icon) {
        this.id = id;
        this.only = only;
        this.requires = requires;
        this.maxRank = maxRank;
        this.costPerRank = costPerRank;
        this.row = row;
        this.column = column;
        this.icon = icon;
    }

    public String key() {
        return "skill.vengefulwoods." + id;
    }

    public Item icon() {
        return icon.get();
    }

    public int row() {
        return row;
    }

    public int column() {
        return column;
    }

    public boolean openTo(WoodsClass chosen) {
        return only == null || only == chosen;
    }

    public static List<Skill> forClass(WoodsClass chosen) {
        List<Skill> open = new ArrayList<>();
        for (Skill skill : values()) {
            if (skill.openTo(chosen)) {
                open.add(skill);
            }
        }
        return open;
    }
}
