package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The forest's ledger for its own plants.
 * <p>
 * Taking something that belongs here costs you a little. Putting something back earns you a little less than
 * taking it cost, so there is no way to farm the forest's good opinion by pulling a trillium up and pushing it
 * back in: do that all day and you end up worse off than when you started. It is only worth anything if the
 * plant stays in the ground.
 */
public class Natives {

    /** Picking debt not yet rounded up into a whole tree's worth of resentment. */
    private static final Map<UUID, Integer> PICKED = new HashMap<>();
    /** Planting credit not yet rounded up into a whole offering. */
    private static final Map<UUID, Integer> PLANTED = new HashMap<>();
    /** Offerings earned from planting today, and the day they were earned on. */
    private static final Map<UUID, int[]> TODAY = new HashMap<>();

    public static void clear() {
        PICKED.clear();
        PLANTED.clear();
        TODAY.clear();
    }

    @Nullable
    static Native kindOf(BlockState state) {
        return state.getBlock() instanceof NativePlantBlock block ? block.plant : null;
    }

    static boolean isNative(BlockState state) {
        return state.getBlock() instanceof NativePlantBlock;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Picking
    // ------------------------------------------------------------------------------------------------------------

    /**
     * The woods mind. Not much for a handful of fiddleheads, and a good deal for a trillium, which is the one
     * that takes years to come back.
     */
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.isCreative() || !(player instanceof ServerPlayer serverPlayer)
                || !(event.getLevel() instanceof ServerLevel level) || !Config.NATIVES_ENABLED.get()) {
            return;
        }
        Native plant = kindOf(event.getState());
        if (plant == null) {
            return;
        }
        if (Skills.has(serverPlayer, Skill.FORAGER)) {
            net.minecraft.world.level.block.Block.popResource(level, event.getPos(),
                    new net.minecraft.world.item.ItemStack(plant.harvest().get()));
        }
        int perTree = Config.NATIVE_PICKS_PER_TREE.get();
        if (perTree <= 0) {
            return;
        }
        UUID id = player.getUUID();
        int points = PICKED.merge(id, plant.pickCost(), Integer::sum);
        if (points < perTree) {
            return;
        }
        int trees = points / perTree;
        PICKED.put(id, points % perTree);
        anger(level, serverPlayer, trees, plant);
    }

    private static void anger(ServerLevel level, ServerPlayer player, int trees, Native plant) {
        MinecraftServer server = level.getServer();
        if (server == null) {
            return;
        }
        WrathData global = WrathData.global(server);
        UUID id = player.getUUID();
        WrathData.Account account = global.account(id);
        Stage before = account.stage();
        global.setFelled(id, account.felled + trees);
        Stage after = global.account(id).stage();
        SpeciesTuner.apply(WrathData.worstStage(server));

        player.displayClientMessage(Component.translatable("message.vengefulwoods.picked",
                        Component.translatable(plant.block().get().getDescriptionId()))
                .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
        if (after != before) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + after.ordinal())
                    .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Putting something back
    // ------------------------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onBlockPlace(BlockEvent.EntityPlaceEvent event) {
        if (!(event.getEntity() instanceof ServerPlayer player) || player.isCreative()
                || !(event.getLevel() instanceof ServerLevel level) || !Config.NATIVES_ENABLED.get()) {
            return;
        }
        Native plant = kindOf(event.getPlacedBlock());
        if (plant == null) {
            return;
        }
        int perOffering = Config.NATIVE_PLANTS_PER_OFFERING.get();
        if (perOffering <= 0) {
            return;
        }
        UUID id = player.getUUID();
        int points = PLANTED.merge(id, plant.plantWorth(), Integer::sum);
        if (points < perOffering) {
            return;
        }
        int earned = points / perOffering;
        PLANTED.put(id, points % perOffering);

        // There is a limit to how much goodwill a day of gardening is worth.
        int day = (int) (level.getDayTime() / 24000L);
        int[] record = TODAY.computeIfAbsent(id, key -> new int[]{day, 0});
        if (record[0] != day) {
            record[0] = day;
            record[1] = 0;
        }
        int cap = Config.NATIVE_FAVOUR_PER_DAY.get();
        if (cap > 0) {
            earned = Math.min(earned, Math.max(0, cap - record[1]));
        }
        if (earned <= 0) {
            return;
        }
        record[1] += earned;
        Rituals.reward(level, player, earned);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.replanted")
                .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), true);
    }
}
