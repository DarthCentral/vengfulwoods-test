package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A brush hook: a long blade on a handle, for cutting back what should not be there. Swung at kudzu it takes
 * a whole armful at once, which is the only way anyone has ever kept up with the stuff.
 */
public class BrushHookItem extends Item {

    public BrushHookItem() {
        super(new Item.Properties().durability(420));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos origin = context.getClickedPos();
        BlockState struck = level.getBlockState(origin);
        boolean weed = Invasives.isInvasive(struck);
        if (!Kudzu.isKudzu(struck) && !weed) {
            return InteractionResult.PASS;
        }

        int radius = Config.BRUSH_HOOK_RADIUS.get();
        // A brush hook is a blade for green growth. Swung at wisteria it barely bites: that is what the
        // heartwood lopper is for, and the difference between them is most of the reason to make one.
        if (Invasives.kindOf(struck) == Invasive.WISTERIA) {
            radius = Math.max(1, radius - 3);
        }
        int cut = 0;
        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -radius, -radius),
                origin.offset(radius, radius, radius))) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            // Cutting a whole stand out in one swing leaves nothing to grow back from.
            if (!Kudzu.isKudzu(state) && !Invasives.isInvasive(state)) {
                continue;
            }
            Invasive weedKind = Invasives.kindOf(state);
            // Nothing drops from a tool sweep. One swing can take hundreds of blocks, and hundreds of
            // item entities is how a server dies. Clear it by hand if you want the harvest.
            serverLevel.destroyBlock(pos.immutable(), false);
            if (weedKind != null) {
                Invasives.noteCleared(serverLevel, weedKind, 1);
            }
            cut++;
        }
        if (cut == 0) {
            return InteractionResult.PASS;
        }

        Sounds.play(level, origin, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 1.0F, 0.8F);
        ItemStack stack = context.getItemInHand();
        if (context.getPlayer() instanceof ServerPlayer player) {
            stack.hurtAndBreak(Math.max(1, cut / 4), player, holder -> {
            });
        }
        return InteractionResult.SUCCESS;
    }
}
