package com.vengefulwoods;

import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;

import javax.annotation.Nullable;

/** Something that burns well enough to be worth growing on purpose. */
public class FuelItem extends Item {

    private final int burnTicks;

    public FuelItem(int burnTicks) {
        super(new Item.Properties());
        this.burnTicks = burnTicks;
    }

    @Override
    public int getBurnTime(ItemStack stack, @Nullable RecipeType<?> recipeType) {
        return burnTicks;
    }
}
