package com.vengefulwoods;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLConstructModEvent;

/**
 * The only client-side code in the mod: one key, which asks the server to open the tree. Everything the key
 * leads to happens on the server, so this does nothing on its own and a server without it is unaffected.
 */
@Mod.EventBusSubscriber(modid = VengefulWoods.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public class WoodsClient {

    private static final KeyMapping SKILLS_KEY = new KeyMapping(
            "key.vengefulwoods.skills", InputConstants.KEY_U, "key.categories.vengefulwoods");

    @SubscribeEvent
    public static void construct(FMLConstructModEvent event) {
        MinecraftForge.EVENT_BUS.addListener(WoodsClient::clientTick);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(SKILLS_KEY);
    }

    /** Ties the altar's window to the screen that draws it. */
    @SubscribeEvent
    public static void clientSetup(net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent event) {
        event.enqueueWork(() -> {
            net.minecraft.client.gui.screens.MenuScreens.register(VengefulWoods.ALTAR_MENU.get(), AltarScreen::new);
            net.minecraft.client.gui.screens.MenuScreens.register(VengefulWoods.SKILL_MENU.get(), SkillScreen::new);
        });
    }

    private static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.START) {
            return;
        }
        while (SKILLS_KEY.consumeClick()) {
            if (Minecraft.getInstance().player != null) {
                WoodsNetwork.CHANNEL.sendToServer(new WoodsNetwork.OpenSkills());
            }
        }
    }
}
