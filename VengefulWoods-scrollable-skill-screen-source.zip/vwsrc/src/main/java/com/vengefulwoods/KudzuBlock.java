package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;

/**
 * The three parts kudzu is built from.
 * <ul>
 * <li>{@link Leaves} - the mats that hang off the vines, and the reason it is dark underneath.</li>
 * <li>{@link Vine} - woody branch-like stems, the structure of the thing.</li>
 * <li>{@link Runner} - the rhizome that travels underground and surfaces where it likes.</li>
 * </ul>
 * All of it burns, which is the only mercy in it.
 */
public final class KudzuBlock {

    private KudzuBlock() {
    }

    private static BlockBehaviour.Properties props(MapColor colour, float strength, SoundType sound) {
        return BlockBehaviour.Properties.of().mapColor(colour).strength(strength).sound(sound);
    }

    /**
     * Leaf mat. A full block, so a thick canopy is pitch dark underneath - but deliberately not a
     * suffocating one. Being buried should be a fight to dig out, and the damage for it is metered out
     * slowly by the mod instead of the instant crush vanilla would apply.
     */
    public static class Leaves extends Block {
        public Leaves() {
            super(props(MapColor.PLANT, 0.3F, SoundType.GRASS)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false));
        }

        @Override
        public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 60;
        }

        @Override
        public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 40;
        }
    }

    /** Woody stem. Tougher than the leaves - this is the part that holds a thicket together. */
    public static class Vine extends Block {
        public Vine() {
            super(props(MapColor.TERRACOTTA_GREEN, 0.8F, SoundType.WOOD).randomTicks());
        }

        /** A cutting that ends up anywhere at all will start running again by itself. */
        @Override
        public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
            Kudzu.awaken(level, pos, state);
        }

        @Override
        public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 30;
        }

        @Override
        public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 20;
        }
    }

    /** Underground runner. Found by digging, usually too late. */
    public static class Runner extends Block {
        public Runner() {
            super(props(MapColor.COLOR_BROWN, 0.6F, SoundType.WOOD).randomTicks());
        }

        @Override
        public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
            Kudzu.awaken(level, pos, state);
        }

        @Override
        public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 15;
        }

        @Override
        public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
            return 10;
        }
    }
}
