package com.vengefulwoods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * The altar, drawn as itself: a slab of dark wood with moss in the corners, a basin of nine slots along the
 * top, and the rites listed underneath with their prices. No chest anywhere in it.
 */
public class AltarScreen extends AbstractContainerScreen<AltarMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VengefulWoods.MODID, "textures/gui/altar.png");

    /** Where the list of rites begins, and how tall a line of it is. */
    private static final int LIST_X = 8;
    private static final int LIST_Y = 50;
    private static final int LINE_H = 20;
    private static final int LINE_W = 160;

    /** Which rite the cursor is over, so its description can be written under the list. */
    private int hovered = -1;

    public AltarScreen(AltarMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 256;
        this.inventoryLabelY = this.imageHeight - 93;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);

        List<Rite> rites = menu.rites();
        for (int i = 0; i < rites.size() && i < 5; i++) {
            int y = topPos + LIST_Y + i * LINE_H;
            int x = leftPos + LIST_X;
            boolean hovered = mouseX >= x && mouseX < x + LINE_W && mouseY >= y && mouseY < y + 18;
            int cost = rites.get(i).cost(Minecraft.getInstance().player);
            boolean affordable = cost <= 0 || menu.tribute() >= cost;
            // The button strip lives at x=176 on the sheet: normal, hovered, then out of reach.
            int v = !affordable ? 40 : hovered ? 20 : 0;
            graphics.blit(TEXTURE, x, y, 176, v, 80, 18);
            graphics.blit(TEXTURE, x + 80, y, 176, v, 80, 18);
            graphics.renderItem(new ItemStack(rites.get(i).icon()), x + 2, y + 1);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, 8, 7, 0xC8BFA6, false);

        // What you have to spend, where you can see it while you read the prices.
        String standing = menu.tribute() + " tribute";
        graphics.drawString(font, standing, imageWidth - 8 - font.width(standing), 7, 0x8FB46A, false);
        String mood = menu.stage().name().charAt(0) + menu.stage().name().substring(1).toLowerCase()
                + "  ·  " + menu.offerings() + " given";
        graphics.drawString(font, mood, 8, imageHeight - 174, 0x7A6E5A, false);

        List<Rite> rites = menu.rites();
        for (int i = 0; i < rites.size() && i < 5; i++) {
            Rite rite = rites.get(i);
            int y = LIST_Y + i * LINE_H;
            int cost = rite.cost(Minecraft.getInstance().player);
            boolean affordable = cost <= 0 || menu.tribute() >= cost;
            graphics.drawString(font, Component.translatable(rite.key()), LIST_X + 22, y + 2,
                    affordable ? 0xE4D8B8 : 0x6B635A, false);
            String price = cost < 0 ? "reads the ground" : cost == 0 ? "no tribute" : cost + " tribute";
            graphics.drawString(font, price, LIST_X + 22, y + 11,
                    affordable ? 0x8FB46A : 0x8A5A52, false);
        }

        // What the rite under the cursor actually does, written out rather than hidden in a tooltip.
        if (hovered >= 0 && hovered < rites.size()) {
            String text = Component.translatable(rites.get(hovered).key() + ".desc").getString();
            int y = LIST_Y + 5 * LINE_H + 2;
            for (String line : wrap(text, 160)) {
                graphics.drawString(font, line, LIST_X, y, 0x9A8F7A, false);
                y += 9;
                if (y > imageHeight - 180) {
                    break;
                }
            }
        }
    }

    /** Breaks a sentence over as many lines as the panel is wide. */
    private List<String> wrap(String text, int width) {
        List<String> lines = new java.util.ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (font.width(candidate) > width && line.length() > 0) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (line.length() > 0) {
            lines.add(line.toString());
        }
        return lines;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<Rite> rites = menu.rites();
        for (int i = 0; i < rites.size() && i < 5; i++) {
            int x = leftPos + LIST_X;
            int y = topPos + LIST_Y + i * LINE_H;
            if (mouseX >= x && mouseX < x + LINE_W && mouseY >= y && mouseY < y + 18) {
                if (minecraft != null && minecraft.gameMode != null) {
                    minecraft.gameMode.handleInventoryButtonClick(menu.containerId, i);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        this.hovered = -1;
        List<Rite> rites = menu.rites();
        for (int i = 0; i < rites.size() && i < 5; i++) {
            int x = leftPos + LIST_X;
            int y = topPos + LIST_Y + i * LINE_H;
            if (mouseX >= x && mouseX < x + LINE_W && mouseY >= y && mouseY < y + 18) {
                this.hovered = i;
                break;
            }
        }
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }
}
