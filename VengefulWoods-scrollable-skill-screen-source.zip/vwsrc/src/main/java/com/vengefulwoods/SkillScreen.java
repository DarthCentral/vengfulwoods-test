package com.vengefulwoods;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.List;

/**
 * The tree drawn as a tree: branches joining what leads to what, the icons lit if you own them, and
 * underneath, in plain words, exactly what the thing the cursor is over actually does.
 */
public class SkillScreen extends AbstractContainerScreen<SkillMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(VengefulWoods.MODID, "textures/gui/skills.png");

    /** Where the grid of icons sits inside the panel, and how far apart they are. */
    private static final int GRID_X = 22;
    private static final int GRID_Y = 24;
    private static final int STEP_X = 44;
    private static final int STEP_Y = 27;

    private int hovered = -1;
    /** Vertical offset of the skill tree; the description area stays fixed. */
    private int scrollOffset = 0;
    private static final int VIEW_TOP = GRID_Y;
    private static final int VIEW_BOTTOM = 116;

    public SkillScreen(SkillMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 200;
        this.imageHeight = 180;
        this.inventoryLabelY = -100;   // there is no inventory in this window
    }

    /** Where a skill's icon lands: a row per tier, spread across the panel. */
    private int[] spot(Skill skill) {
        return new int[]{leftPos + GRID_X + skill.column() * STEP_X,
                         topPos + GRID_Y + skill.row() * STEP_Y - scrollOffset};
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight);
        List<Skill> skills = menu.offered();

        // Only the skill tree scrolls; the title and description remain fixed.
        graphics.enableScissor(leftPos + 8, topPos + VIEW_TOP, leftPos + imageWidth - 8,
                topPos + VIEW_BOTTOM);
        graphics.pose().pushPose();

        // The branches first, so the icons sit on top of them.
        for (Skill skill : skills) {
            if (skill.requires == null || !skill.openTo(menu.chosen())) {
                continue;
            }
            int[] from = spot(skill.requires);
            int[] to = spot(skill);
            boolean live = menu.known(skill.requires);
            int colour = live ? 0xFF4F7A4A : 0xFF3A3648;
            int x0 = Math.min(from[0], to[0]) + 8;
            int x1 = Math.max(from[0], to[0]) + 8;
            graphics.fill(x0, from[1] + 16, x1 + 1, from[1] + 17, colour);
            graphics.fill(to[0] + 7, from[1] + 16, to[0] + 9, to[1], colour);
        }

        for (Skill skill : skills) {
            int[] at = spot(skill);
            int rank = menu.rank(skill);
            boolean maxed = rank >= skill.maxRank;
            boolean open = menu.unlocked(skill);
            boolean affordable = open && menu.points() >= skill.costPerRank && !maxed;
            int shade = maxed ? 0xFF2E5A2C : rank > 0 ? 0xFF2E4A2C
                    : affordable ? 0xFF3A3648 : 0xFF26242E;
            graphics.fill(at[0] - 2, at[1] - 2, at[0] + 18, at[1] + 18, shade);
            graphics.fill(at[0] - 2, at[1] - 2, at[0] + 18, at[1] - 1,
                    maxed ? 0xFFA8D27A : rank > 0 ? 0xFF6FA86A : open ? 0xFF4A4658 : 0xFF343040);
            graphics.renderItem(new ItemStack(skill.icon()), at[0], at[1]);
            // Pips along the bottom of the well, one per rank taken.
            for (int r = 0; r < skill.maxRank; r++) {
                int px = at[0] + r * 5;
                graphics.fill(px, at[1] + 17, px + 4, at[1] + 19,
                        r < rank ? 0xFFBFE08A : 0xFF3A3648);
            }
        }
        graphics.pose().popPose();
        graphics.disableScissor();

        // A small scrollbar indicates that more rows are available below.
        int contentBottom = skills.stream().mapToInt(skill -> GRID_Y + skill.row() * STEP_Y + 19)
                .max().orElse(VIEW_BOTTOM);
        int maxScroll = Math.max(0, contentBottom - VIEW_BOTTOM);
        if (maxScroll > 0) {
            int trackX = leftPos + imageWidth - 7;
            int trackTop = topPos + VIEW_TOP;
            int trackHeight = VIEW_BOTTOM - VIEW_TOP;
            graphics.fill(trackX, trackTop, trackX + 2, topPos + VIEW_BOTTOM, 0xFF282530);
            int thumbHeight = Math.max(12, trackHeight * trackHeight / (trackHeight + maxScroll));
            int thumbY = trackTop + (trackHeight - thumbHeight) * scrollOffset / maxScroll;
            graphics.fill(trackX, thumbY, trackX + 2, thumbY + thumbHeight, 0xFF9A93A8);
        }
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, title, 8, 7, 0xCFC9DC, false);
        String points = menu.points() + " to spend";
        graphics.drawString(font, points, imageWidth - 8 - font.width(points), 7, 0x8FD6E0, false);

        List<Skill> skills = menu.offered();
        if (hovered >= 0 && hovered < skills.size()) {
            Skill skill = skills.get(hovered);
            String name = Component.translatable(skill.key()).getString();
            String desc = Component.translatable(skill.key() + ".desc").getString();
            int rank = menu.rank(skill);
            String cost = rank >= skill.maxRank ? "mastered"
                    : !menu.unlocked(skill) ? "needs " + Component.translatable(skill.requires.key()).getString()
                    : "rank " + (rank + 1) + " \u00b7 " + skill.costPerRank
                      + " point" + (skill.costPerRank == 1 ? "" : "s");
            graphics.drawString(font, name, 10, imageHeight - 45, 0xE6E0F0, false);
            graphics.drawString(font, cost, imageWidth - 10 - font.width(cost), imageHeight - 45,
                    rank >= skill.maxRank ? 0x7FC27A : menu.unlocked(skill) ? 0x8FD6E0 : 0x8A5A52, false);
            int y = imageHeight - 34;
            for (String line : wrap(desc, imageWidth - 20)) {
                graphics.drawString(font, line, 10, y, 0x9A93A8, false);
                y += 9;
            }
        } else {
            graphics.drawString(font, "Hover a branch to read it. Click to learn it.", 10,
                    imageHeight - 34, 0x6E6880, false);
        }
    }

    private List<String> wrap(String text, int width) {
        List<String> lines = new ArrayList<>();
        StringBuilder line = new StringBuilder();
        for (String word : text.split(" ")) {
            String candidate = line.length() == 0 ? word : line + " " + word;
            if (font.width(candidate) > width && line.length() > 0) {
                lines.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(candidate);
            }
        }
        if (line.length() > 0) {
            lines.add(line.toString());
        }
        return lines.size() > 3 ? lines.subList(0, 3) : lines;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double deltaX, double deltaY) {
        if (mouseX >= leftPos + 8 && mouseX <= leftPos + imageWidth - 8
                && mouseY >= topPos + VIEW_TOP && mouseY <= topPos + VIEW_BOTTOM) {
            List<Skill> skills = menu.offered();
            int contentBottom = skills.stream().mapToInt(skill -> GRID_Y + skill.row() * STEP_Y + 19)
                    .max().orElse(VIEW_BOTTOM);
            int maxScroll = Math.max(0, contentBottom - VIEW_BOTTOM);
            if (maxScroll > 0 && deltaY != 0) {
                scrollOffset = Mth.clamp(scrollOffset - (int) Math.signum(deltaY) * 18, 0, maxScroll);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, deltaX, deltaY);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        List<Skill> skills = menu.offered();
        if (mouseY < topPos + VIEW_TOP || mouseY > topPos + VIEW_BOTTOM) {
            return super.mouseClicked(mouseX, mouseY, button);
        }
        for (int i = 0; i < skills.size(); i++) {
            int[] at = spot(skills.get(i));
            if (mouseY >= topPos + VIEW_TOP && mouseY <= topPos + VIEW_BOTTOM
                    && mouseX >= at[0] - 2 && mouseX < at[0] + 18 && mouseY >= at[1] - 2 && mouseY < at[1] + 18) {
                if (minecraft != null && minecraft.gameMode != null) {
                    minecraft.gameMode.handleInventoryButtonClick(menu.containerId, i);
                }
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        hovered = -1;
        List<Skill> skills = menu.offered();
        for (int i = 0; i < skills.size(); i++) {
            int[] at = spot(skills.get(i));
            if (mouseY >= topPos + VIEW_TOP && mouseY <= topPos + VIEW_BOTTOM
                    && mouseX >= at[0] - 2 && mouseX < at[0] + 18
                    && mouseY >= at[1] - 2 && mouseY < at[1] + 18) {
                hovered = i;
                break;
            }
        }
        super.render(graphics, mouseX, mouseY, partialTick);
    }
}
