package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseFireBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.util.RandomSource;

/** One block, three plants. What it does to you depends on which one it is. */
public class InvasiveBlock extends Block {

    public final Invasive kind;

    public InvasiveBlock(Invasive kind, MapColor colour, float strength, SoundType sound) {
        super(BlockBehaviour.Properties.of()
                .mapColor(colour)
                .strength(strength)
                .sound(sound)
                .noOcclusion()
                .randomTicks());
        this.kind = kind;
    }

    @Override
    public int getFlammability(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        if (kind == Invasive.WISTERIA && Config.WISTERIA_FIREPROOF.get()) {
            return 0; // Green, woody and full of sap. Burning it off does not work.
        }
        return kind == Invasive.CHEATGRASS ? 100 : 40;
    }

    @Override
    public int getFireSpreadSpeed(BlockState state, BlockGetter level, BlockPos pos, Direction face) {
        if (kind == Invasive.WISTERIA && Config.WISTERIA_FIREPROOF.get()) {
            return 0;
        }
        return kind == Invasive.CHEATGRASS ? 80 : 25;
    }

    /** Blackberry tears at whatever wades into it. The others are only in the way - which is bad enough. */
    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide() || kind != Invasive.BLACKBERRY || !(entity instanceof LivingEntity living)) {
            return;
        }
        if (entity instanceof Player player
                && (player.isCreative() || player.isSpectator() || WoodsGear.turnsThorns(player)
                    || WeedToolItem.wardsThorns(player) || WoodsClass.of(player).weedsSpare(player))) {
            return; // The Invader walks through his own brambles, while there is still less of them than him.
        }
        living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 20, 2, true, false, false));
        if (level.getGameTime() % 20L != 0L) {
            return;
        }
        float damage = (float) (double) Config.BLACKBERRY_DAMAGE.get();
        if (entity instanceof Player tough && Skills.has(tough, Skill.THICK_SKIN)) {
            damage *= 0.5F;
        }
        if (level instanceof ServerLevel world && !(entity instanceof Player)) {
            damage *= Invader.damageAgainstOthers(world); // Someone has made these theirs.
        }
        if (damage > 0.0F && level instanceof ServerLevel serverLevel) {
            net.minecraft.world.damagesource.DamageSource source = Rhizomes.tendrilDamage(serverLevel);
            if (source != null) {
                living.hurt(source, damage);
            }
        }
    }

    /** Cheatgrass cures to tinder and takes the country with it. */
    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        Invasives.awaken(level, pos, state);
        if (kind != Invasive.CHEATGRASS || !Config.CHEATGRASS_IGNITES.get()) {
            return;
        }
        if (random.nextFloat() > (float) (double) Config.CHEATGRASS_FIRE_CHANCE.get()) {
            return;
        }
        for (Direction dir : Direction.values()) {
            BlockPos side = pos.relative(dir);
            if (!level.isLoaded(side) || !level.getBlockState(side).isAir()) {
                continue;
            }
            BlockState fuel = level.getBlockState(side.relative(dir));
            if (fuel.isAir() || fuel.is(this)) {
                continue;
            }
            if (fuel.getFlammability(level, side.relative(dir), dir.getOpposite()) > 0) {
                level.setBlock(side, BaseFireBlock.getState(level, side), 11);
                return;
            }
        }
    }
}
