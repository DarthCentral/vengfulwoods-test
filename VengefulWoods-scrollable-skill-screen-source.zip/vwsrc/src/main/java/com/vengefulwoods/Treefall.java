package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.block.branch.BranchBlock;
import com.ferreusveritas.dynamictrees.entity.FallingTreeEntity;
import com.ferreusveritas.dynamictrees.init.DTConfigs;
import com.ferreusveritas.dynamictrees.util.BranchDestructionData;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * The forest hitting back with its own body.
 * <ul>
 * <li>Canopy drop: a branch above a target is cut loose so it lands on whatever is underneath.</li>
 * <li>Topple: a whole tree is felled sideways onto a target. The tree does not survive this.</li>
 * </ul>
 * A grudge is remembered wherever a mob (a creeper, usually) destroys a tree: trees in that area go after
 * mobs for a while, whatever the players have or have not done.
 */
public final class Treefall {

    /** Set while the forest fells one of its own trees, so the tree counter ignores it. */
    private static boolean deliberate;

    private record Grudge(BlockPos pos, long expiry) {
    }

    private static final Map<ResourceKey<Level>, List<Grudge>> GRUDGES = new HashMap<>();

    private Treefall() {
    }

    public static void clear() {
        GRUDGES.clear();
        deliberate = false;
    }

    /** True while a tree is being destroyed by the forest itself rather than by a player. */
    static boolean isDeliberate() {
        return deliberate;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Grudges
    // ------------------------------------------------------------------------------------------------------------

    static void addGrudge(ServerLevel level, BlockPos pos, long now) {
        List<Grudge> list = GRUDGES.computeIfAbsent(level.dimension(), key -> new ArrayList<>());
        if (list.size() >= 128) {
            list.remove(0);
        }
        list.add(new Grudge(pos.immutable(), now + Config.GRUDGE_MINUTES.get() * 1200L));
    }

    static boolean grudgeNear(ServerLevel level, BlockPos pos, long now, double radius) {
        List<Grudge> list = GRUDGES.get(level.dimension());
        if (list == null) {
            return false;
        }
        double maxDistSq = radius * radius;
        for (int i = list.size() - 1; i >= 0; i--) {
            Grudge grudge = list.get(i);
            if (now > grudge.expiry()) {
                list.remove(i);
                continue;
            }
            if (grudge.pos().distSqr(pos) <= maxDistSq) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Every tick
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players, long now) {
        if (now % 20L == 0L) {
            expireCages(level, now);
        }
        if (players.isEmpty()) {
            return;
        }
        if (now % 40L == 0L && Config.DEFEND_PLAYERS.get()) {
            defendStep(level, st, players, now);
        }
        if (now % 40L == 0L) {
            huntStep(level, st, players, now);
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Going after mobs
    // ------------------------------------------------------------------------------------------------------------

    private static void defendStep(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players, long now) {
        for (int i = 0; i < Math.min(players.size(), 4); i++) {
            ServerPlayer player = players.get(i);
            if (player.isSpectator()) {
                continue;
            }
            // Each player is defended (or not) according to their own standing with the forest.
            Stage stage = WrathData.stageOf(level.getServer(), player.getUUID());
            Boon boon = WrathData.boonOf(level.getServer(), player.getUUID());
            boolean friendly = boon.atLeast(Boon.ALLIED);
            // A grudge against mobs is the forest's own business: it is taken out near anybody.
            boolean spiteful = grudgeNear(level, player.blockPosition(), now, 64.0);
            // And a Druid can simply tell it what to kill, whatever it thinks of the thing otherwise.
            List<Monster> mobs = level.getEntitiesOfClass(Monster.class, player.getBoundingBox().inflate(24.0));
            Monster marked = null;
            for (Monster candidate : mobs) {
                if (Classes.isMarked(level, candidate)) {
                    marked = candidate;
                    break;
                }
            }
            if (!friendly && !spiteful && marked == null) {
                continue;
            }
            if (mobs.isEmpty()) {
                continue;
            }
            Monster mob = marked != null ? marked : mobs.get(level.random.nextInt(mobs.size()));
            if (!mob.isAlive()) {
                continue;
            }

            int roll = level.random.nextInt(10);
            boolean mayTopple = Config.TOPPLE_ON_MOBS.get() && (boon.atLeast(Boon.GUARDIAN) || spiteful);
            if (roll < 9 || !mayTopple) {
                canopyDropOn(level, mob.blockPosition());
            } else {
                BlockPos tree = findTreeFor(st, mob.blockPosition(), level);
                if (tree != null) {
                    topple(level, tree, mob.blockPosition());
                } else {
                    canopyDropOn(level, mob.blockPosition());
                }
            }
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // Going after players
    // ------------------------------------------------------------------------------------------------------------

    private static void huntStep(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players, long now) {
        // Every player the forest has a grievance with is worked on, not one picked at random: once the
        // count is up, every tree around that person is hostile at once.
        for (int i = 0; i < Math.min(players.size(), 8); i++) {
            hunt(level, st, players.get(i), now);
        }
    }

    private static void hunt(ServerLevel level, ForestDirector.LevelState st, ServerPlayer player, long now) {
        if (player.isCreative() || player.isSpectator() || !player.isAlive()) {
            return;
        }
        Stage stage = WoodsGear.softened(player, WrathData.stageOf(level.getServer(), player.getUUID()));
        if (!stage.dropsCanopyOnPlayers()) {
            return; // Not angry enough with this one to drop anything on them.
        }

        long toppleCooldown = (long) (Config.TOPPLE_COOLDOWN.get() * 20L * stage.toppleCooldownFactor());
        long canopyCooldown = Math.max(40L, toppleCooldown / 4L);

        // Branches come loose far more often than whole trees do.
        Long nextCanopy = st.nextCanopy.get(player.getUUID());
        if ((nextCanopy == null || now >= nextCanopy) && level.random.nextFloat() < stage.toppleUrge()) {
            if (canopyDropOn(level, player.blockPosition())) {
                st.nextCanopy.put(player.getUUID(), now + canopyCooldown);
            } else {
                st.nextCanopy.put(player.getUUID(), now + canopyCooldown / 2L);
            }
        }

        Long next = st.nextTopple.get(player.getUUID());
        if (next != null && now < next) {
            return;
        }
        if (next == null) {
            st.nextTopple.put(player.getUUID(), now + toppleCooldown / 2);
            return;
        }
        if (level.random.nextFloat() > stage.toppleUrge()) {
            return; // Not every chance is taken; at the lower stages it should feel like bad luck.
        }

        boolean acted = false;
        if (stage.topplesOnPlayers() && Config.TOPPLE_ON_PLAYERS.get()) {
            BlockPos tree = findTreeFor(st, player.blockPosition(), level);
            acted = tree != null && topple(level, tree, player.blockPosition());
        }
        if (acted) {
            st.nextTopple.put(player.getUUID(), now + toppleCooldown);
        }
    }

    /** A tracked tree tall enough, and close enough, to actually land on the target. */
    @Nullable
    private static BlockPos findTreeFor(ForestDirector.LevelState st, BlockPos target, ServerLevel level) {
        BlockPos best = null;
        double bestDistSq = Double.MAX_VALUE;
        for (BlockPos rootPos : st.order) {
            double distSq = rootPos.distSqr(target);
            if (distSq < 9.0 || distSq > 256.0 || distSq >= bestDistSq) {
                continue;
            }
            int height = ForestDirector.trunkHeight(level, rootPos);
            if (height < 6 || height * height < distSq) {
                continue; // Too short to reach.
            }
            bestDistSq = distSq;
            best = rootPos;
        }
        return best;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Dropping wood on things
    // ------------------------------------------------------------------------------------------------------------

    /** Fells a whole tree sideways onto a target. Returns true if the tree actually went over. */
    static boolean topple(ServerLevel level, BlockPos rootPos, BlockPos target) {
        BlockPos trunkPos = rootPos.above();
        BlockState trunkState = level.getBlockState(trunkPos);
        BranchBlock branch = TreeHelper.getBranch(trunkState);
        if (branch == null) {
            return false;
        }
        // Dynamic Trees drops a tree away from the face that was struck, so to land it on the target the
        // forest "strikes" the far side: the struck face points from the target back at the tree.
        Direction fallDir = horizontalToward(rootPos, target);
        Direction struckFace = fallDir.getOpposite();
        int height = ForestDirector.trunkHeight(level, rootPos);

        BranchDestructionData data;
        deliberate = true;
        try {
            data = branch.destroyBranchFromNode(level, trunkPos, struckFace, false, null);
            if (data == null || data.getNumBranches() == 0) {
                return false;
            }
            data.leavesDrops.clear(); // A tree thrown in anger is not a harvest.
            FallingTreeEntity.dropTree(level, data, Collections.<ItemStack>emptyList(), FallingTreeEntity.DestroyType.HARVEST);
        } finally {
            deliberate = false;
        }

        Sounds.play(level, trunkPos, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 1.4F, 0.5F);
        if (!dynamicTreesCrushesEntities()) {
            // Dynamic Trees is set not to hurt anyone with falling trees, so the forest does it itself.
            hurtUnder(level, trunkPos, fallDir, Math.max(height, 4), (float) (double) Config.CRUSH_DAMAGE.get());
        }
        return true;
    }

    /** Cuts a branch loose above a target so it comes down on its head. */
    static boolean canopyDropOn(ServerLevel level, BlockPos target) {
        for (int dy = 2; dy <= 16; dy++) {
            BlockPos pos = target.above(dy);
            if (!level.isLoaded(pos)) {
                return false;
            }
            BlockState state = level.getBlockState(pos);
            BranchBlock branch = TreeHelper.getBranch(state);
            if (branch == null) {
                continue;
            }
            deliberate = true;
            try {
                BranchDestructionData data = branch.destroyBranchFromNode(level, pos, Direction.DOWN, false, null);
                if (data == null || data.getNumBranches() == 0) {
                    return false;
                }
                data.leavesDrops.clear();
                FallingTreeEntity.dropTree(level, data, Collections.<ItemStack>emptyList(), FallingTreeEntity.DestroyType.HARVEST);
            } finally {
                deliberate = false;
            }
            Sounds.play(level, pos, Sounds.WOOD_BREAK, SoundSource.BLOCKS, 1.0F, 0.6F);
            // Dynamic Trees only hurts entities with whole toppling trees, never with a dropped piece,
            // so the weight of the canopy is applied here.
            hurtUnder(level, target, null, 2, (float) (double) Config.CRUSH_DAMAGE.get() * 0.5F);
            return true;
        }
        return false;
    }

    /** True when Dynamic Trees will hurt whatever a toppling tree lands on, so we leave that to it. */
    private static boolean dynamicTreesCrushesEntities() {
        try {
            return DTConfigs.ENABLE_FALLING_TREES.get() && DTConfigs.ENABLE_FALLING_TREE_DAMAGE.get();
        } catch (RuntimeException e) {
            return true;
        }
    }

    private static void hurtUnder(ServerLevel level, BlockPos from, @Nullable Direction toward, int reach, float damage) {
        if (damage <= 0.0F) {
            return;
        }
        AABB area = new AABB(from).inflate(1.5);
        if (toward != null) {
            area = area.expandTowards(toward.getStepX() * reach, 0.0, toward.getStepZ() * reach);
        }
        DamageSource source = Rhizomes.tendrilDamage(level);
        if (source == null) {
            return;
        }
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, area)) {
            if (entity instanceof ServerPlayer player && (player.isCreative() || player.isSpectator())) {
                continue;
            }
            entity.hurt(source, damage);
        }
    }

    private static Direction horizontalToward(BlockPos from, BlockPos to) {
        int dx = to.getX() - from.getX();
        int dz = to.getZ() - from.getZ();
        if (Math.abs(dx) >= Math.abs(dz)) {
            return dx >= 0 ? Direction.EAST : Direction.WEST;
        }
        return dz >= 0 ? Direction.SOUTH : Direction.NORTH;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Cages
    // ------------------------------------------------------------------------------------------------------------

    /** Throws up wooden columns around a mob so it cannot get to the player. */
    static void cage(ServerLevel level, LivingEntity mob, long now) {
        BlockPos center = mob.blockPosition();
        long expiry = now + Config.CAGE_SECONDS.get() * 20L;
        WrathData data = WrathData.get(level);
        BlockState rhizome = VengefulWoods.RHIZOME.get().defaultBlockState();
        boolean any = false;

        for (int x = -1; x <= 1; x++) {
            for (int z = -1; z <= 1; z++) {
                if (x == 0 && z == 0) {
                    continue;
                }
                for (int y = 0; y <= 1; y++) {
                    BlockPos pos = center.offset(x, y, z);
                    if (!level.isLoaded(pos)) {
                        continue;
                    }
                    BlockState state = level.getBlockState(pos);
                    // Only fill empty space: a cage never breaks anything.
                    if (!state.isAir() && !state.canBeReplaced()) {
                        continue;
                    }
                    if (occupiedByPlayer(level, pos)) {
                        continue; // Never wall a player in by accident.
                    }
                    level.setBlock(pos, rhizome, 3);
                    data.cages.add(new WrathData.Cage(pos.immutable(), expiry));
                    any = true;
                }
            }
        }
        if (any) {
            data.setDirty();
            Rhizomes.burst(level, center);
        }
    }

    private static boolean occupiedByPlayer(ServerLevel level, BlockPos pos) {
        AABB block = new AABB(pos);
        for (ServerPlayer player : level.players()) {
            if (player.getBoundingBox().intersects(block)) {
                return true;
            }
        }
        return false;
    }

    private static void expireCages(ServerLevel level, long now) {
        WrathData data = WrathData.get(level);
        if (data.cages.isEmpty()) {
            return;
        }
        Iterator<WrathData.Cage> iterator = data.cages.iterator();
        boolean changed = false;
        while (iterator.hasNext()) {
            WrathData.Cage cage = iterator.next();
            if (now < cage.expiryGameTime) {
                continue;
            }
            if (!level.isLoaded(cage.pos)) {
                continue; // Take it away when someone is there to see it.
            }
            iterator.remove();
            changed = true;
            if (Rhizomes.isRhizome(level.getBlockState(cage.pos))) {
                level.removeBlock(cage.pos, false);
            }
        }
        if (changed) {
            data.setDirty();
        }
    }
}
