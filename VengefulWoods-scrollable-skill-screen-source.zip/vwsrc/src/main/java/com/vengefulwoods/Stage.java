package com.vengefulwoods;

/**
 * How angry the forest is with one particular player. Each stage keeps everything from the stage before it.
 * <p>
 * growthSignalsPerDay: extra growth pulses a tree gets per Minecraft day. One pulse grows at most one new
 * branch block, so 7 is about "5 blocks taller and 2 wider a day" and 16 is about "12 taller and 4 wider".
 */
public enum Stage {
    //                    growth, saplings, rhizomes, rhizome blocks   (per tree, per day)
    DORMANT(0, 0, 0, 0),
    STIRRING(3, 0, 0, 0),          // faster growth, cleared ground closes up again
    THICKENING(8, 2, 0, 0),        // huge trees, saplings every day
    CREEPING(14, 6, 2, 32),        // rhizomes burrow out from the roots, fast
    SNARLING(40, 22, 7, 120),      // stumps sprout at once, rhizomes hunt torches
    RELENTLESS(80, 44, 13, 260),   // felled trees come back from the dead
    GRASPING(150, 75, 20, 440),    // growth turns toward players, roots grab, branches fall on them
    HUNTING(260, 120, 30, 720),    // tendrils attack, whole trees are thrown at players
    WRATHFUL(460, 200, 44, 1200);  // no let-up: the woods close over you while you watch

    public final int growthSignalsPerDay;
    public final int saplingsPerDay;
    public final int rhizomesPerDay;
    public final int rhizomeBlocksPerDay;

    Stage(int growthSignalsPerDay, int saplingsPerDay, int rhizomesPerDay, int rhizomeBlocksPerDay) {
        this.growthSignalsPerDay = growthSignalsPerDay;
        this.saplingsPerDay = saplingsPerDay;
        this.rhizomesPerDay = rhizomesPerDay;
        this.rhizomeBlocksPerDay = rhizomeBlocksPerDay;
    }

    public boolean atLeast(Stage other) {
        return this.ordinal() >= other.ordinal();
    }

    /** Destroyed trees needed to reach this stage. */
    public int threshold() {
        switch (this) {
            case STIRRING:
                return Config.STAGE_1.get();
            case THICKENING:
                return Config.STAGE_2.get();
            case CREEPING:
                return Config.STAGE_3.get();
            case SNARLING:
                return Config.STAGE_4.get();
            case RELENTLESS:
                return Config.STAGE_5.get();
            case GRASPING:
                return Config.STAGE_6.get();
            case HUNTING:
                return Config.STAGE_7.get();
            case WRATHFUL:
                return Config.STAGE_8.get();
            default:
                return 0;
        }
    }

    public static Stage forCount(int felled) {
        Stage result = DORMANT;
        for (Stage stage : values()) {
            if (stage != DORMANT && felled >= stage.threshold()) {
                result = stage;
            }
        }
        return result;
    }

    /** Multiplier applied to Dynamic Trees' own (natural) growth rate. */
    public float naturalGrowthMultiplier() {
        if (this == DORMANT) {
            return 1.0f;
        }
        float base = Config.NATURAL_GROWTH_MULTIPLIER.get().floatValue();
        switch (this) {
            case SNARLING:
                return base * 2.5f;
            case RELENTLESS:
                return base * 4.0f;
            case GRASPING:
                return base * 7.0f;
            case HUNTING:
                return base * 11.0f;
            case WRATHFUL:
                return base * 18.0f;
            default:
                return base;
        }
    }

    /** Saplings a single rhizome tip produces per day. */
    public float tipSaplingsPerDay() {
        switch (this) {
            case WRATHFUL:
                return 8.0f;
            case HUNTING:
                return 5.0f;
            case GRASPING:
                return 3.0f;
            case RELENTLESS:
                return 2.0f;
            default:
                return 1.0f;
        }
    }

    /** Chance a felled tree comes back the next day. It stops being a chance at the very end. */
    public double regrowChance() {
        double base = Config.REGROW_CHANCE.get();
        switch (this) {
            case WRATHFUL:
                return 1.0;
            case HUNTING:
                return Math.min(1.0, base * 1.8);
            case GRASPING:
                return Math.min(1.0, base * 1.4);
            default:
                return base;
        }
    }

    /** How readily the forest takes a chance to drop something on a player. */
    public float toppleUrge() {
        switch (this) {
            case WRATHFUL:
                return 0.95f;
            case HUNTING:
                return 0.7f;
            case GRASPING:
                return 0.4f;
            default:
                return 0.0f;
        }
    }

    /** Ticks before a sapling is forced to become a tree. An angry forest does not wait. */
    public int saplingDelayTicks() {
        float ticks = Config.SAPLING_GROW_SECONDS.get() * 20.0f;
        switch (this) {
            case WRATHFUL:
                ticks /= 20.0f;
                break;
            case HUNTING:
                ticks /= 10.0f;
                break;
            case GRASPING:
                ticks /= 6.0f;
                break;
            case RELENTLESS:
                ticks /= 3.0f;
                break;
            case SNARLING:
                ticks /= 2.0f;
                break;
            case CREEPING:
                ticks /= 1.5f;
                break;
            default:
                break;
        }
        return Math.max(20, (int) ticks);
    }

    /** Saplings one tree may put down in a single visit, so a furious forest does not trickle them out. */
    public int saplingsPerVisit() {
        switch (this) {
            case WRATHFUL:
                return 8;
            case HUNTING:
                return 6;
            case GRASPING:
                return 4;
            case RELENTLESS:
                return 3;
            case SNARLING:
                return 2;
            default:
                return 1;
        }
    }

    // ------------------------------------------------------------------------------------------------------------
    // What is unlocked where
    // ------------------------------------------------------------------------------------------------------------

    /** Rhizomes burrow out of the roots. */
    public boolean hasRhizomes() {
        return atLeast(CREEPING);
    }

    /** A sapling takes root on the stump the moment a tree is destroyed. */
    public boolean sproutsOnStumps() {
        return atLeast(SNARLING);
    }

    /** Rhizomes and saplings move toward torches, and smother them. */
    public boolean huntsLight() {
        return atLeast(SNARLING);
    }

    /** Destroyed trees have a chance to come back a day later. */
    public boolean regrowsTrees() {
        return atLeast(RELENTLESS);
    }

    /** Growth aims at players, and roots underfoot drag at them. */
    public boolean huntsPlayers() {
        return atLeast(GRASPING);
    }

    /** Branches are cut loose above players. */
    public boolean dropsCanopyOnPlayers() {
        return atLeast(GRASPING);
    }

    /** Rhizomes surface as tendrils and strike. */
    public boolean hasTendrils() {
        return atLeast(HUNTING);
    }

    /** Whole trees are thrown down on players. */
    public boolean topplesOnPlayers() {
        return atLeast(HUNTING);
    }

    /** Players get walled in by the same columns used on mobs. */
    public boolean cagesPlayers() {
        return atLeast(WRATHFUL);
    }

    public float tendrilDamageFactor() {
        switch (this) {
            case WRATHFUL:
                return 2.0f;
            case HUNTING:
                return 1.35f;
            default:
                return 1.0f;
        }
    }

    public float toppleCooldownFactor() {
        switch (this) {
            case WRATHFUL:
                return 0.25f;
            case HUNTING:
                return 0.6f;
            default:
                return 1.0f;
        }
    }
}
