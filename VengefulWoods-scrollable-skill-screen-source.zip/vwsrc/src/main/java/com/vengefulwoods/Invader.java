package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The Invader's bargain.
 * <p>
 * The weeds are his: they cost him almost nothing, they will not touch him, and they tear at everything else
 * twice as hard. What he is not told is that the arrangement is one-sided only while there is less of them
 * than there is of him. Every block of loose invasive in the world is counted, and past a certain weight of
 * green the plants stop recognising their gardener. After that he is simply more biomass, and the thing he
 * spent the game building is the thing killing him.
 */
public class Invader {

    /** Last warning sent to each player, so the countdown does not become spam. */
    private static final Map<UUID, Integer> WARNED = new HashMap<>();

    public static void clear() {
        WARNED.clear();
    }

    /** How much loose weed there is in this world, counted off what has escaped. */
    static int looseWeight(ServerLevel level) {
        if (level.getServer() == null) {
            return 0;
        }
        WrathData global = WrathData.global(level.getServer());
        int total = 0;
        for (WrathData.Escape escape : global.escapes.values()) {
            total += Math.max(0, escape.grown - escape.cleared);
        }
        return total;
    }

    /**
     * True once the weeds have stopped telling him apart from anything else they are growing over.
     * Cutting the mess back below the line brings him back into their good books.
     */
    static boolean consumed(Player player) {
        if (!(player instanceof ServerPlayer server) || server.getServer() == null) {
            return false;
        }
        if (WoodsClass.of(server) != WoodsClass.INVADER) {
            return false;
        }
        int limit = Config.INVADER_CONSUMED_AT.get();
        if (Skills.has(server, Skill.SYMBIOTE)) {
            limit *= 2;
        }
        return looseWeight(server.serverLevel()) >= limit;
    }

    /** What an Invader's weeds multiply their damage by, against anything that is not him. */
    static float damageAgainstOthers(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            if (WoodsClass.of(player) == WoodsClass.INVADER) {
                return Config.INVADER_WEED_DAMAGE.get().floatValue();
            }
        }
        return 1.0F;
    }

    /**
     * Once a second: the gardener gets told how the garden is doing, and once it is past him, it starts
     * showing. Nothing dramatic happens at the line - he simply stops being an exception.
     */
    static void tick(ServerLevel level, long now) {
        if (now % 100L != 0L || !Config.CLASSES_ENABLED.get()) {
            return;
        }
        int loose = looseWeight(level);
        int limit = Config.INVADER_CONSUMED_AT.get();
        for (ServerPlayer player : level.players()) {
            if (WoodsClass.of(player) != WoodsClass.INVADER) {
                continue;
            }
            int step = loose * 4 / Math.max(1, limit); // quarters of the way there
            Integer told = WARNED.get(player.getUUID());
            if (told == null || told != step) {
                WARNED.put(player.getUUID(), step);
                if (step >= 4) {
                    player.displayClientMessage(Component.translatable("message.vengefulwoods.invader_consumed")
                            .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
                } else if (step >= 2) {
                    player.displayClientMessage(Component.translatable("message.vengefulwoods.invader_warning")
                            .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), true);
                }
            }
            if (loose >= limit) {
                // It is in him now, not merely around him.
                player.addEffect(new MobEffectInstance(MobEffects.HUNGER, 120, 0, true, false, false));
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 0, true, false, false));
            }
        }
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent event) {
        WARNED.remove(event.getEntity().getUUID());
    }
}
