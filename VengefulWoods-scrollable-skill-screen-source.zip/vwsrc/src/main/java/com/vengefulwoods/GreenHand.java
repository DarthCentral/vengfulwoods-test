package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * The Invader's hands.
 * <p>
 * Hold a weed and use it, and that weed answers. Wisteria comes up out of the ground and takes hold of
 * whatever is in front of you. Kudzu arrives all at once, in a wave. Knotweed puts a cane straight up
 * through whatever is standing on it.
 * <p>
 * How hard any of it hits depends on how much of that plant is actually loose in the world - a power you
 * have not planted for is a power that does nothing. And the more green there is in total, the more likely
 * it is that it does not listen: up to one time in five, what you called comes for you instead.
 */
public class GreenHand {

    /** Last use, per player per plant, so each has its own cooldown. */
    private static final Map<UUID, Map<Invasive, Long>> LAST = new HashMap<>();

    public static void clear() {
        LAST.clear();
    }

    /** Which skill drives which plant. */
    private static Skill skillFor(Invasive kind) {
        switch (kind) {
            case WISTERIA:
                return Skill.STRANGLE;
            case KNOTWEED:
                return Skill.IMPALE;
            default:
                return Skill.TIDE;
        }
    }

    @SubscribeEvent
    public void onUse(PlayerInteractEvent.RightClickBlock event) {
        attempt(event.getEntity(), event.getHand(), event.getPos());
    }

    private void attempt(Player player, InteractionHand hand, BlockPos at) {
        if (!(player instanceof ServerPlayer caster) || !(player.level() instanceof ServerLevel level)) {
            return;
        }
        if (WoodsClass.of(caster) != WoodsClass.INVADER || !Skills.has(caster, Skill.GREEN_HAND)) {
            return;
        }
        ItemStack held = player.getItemInHand(hand);
        Invasive kind = heldPlant(held);
        if (kind == null) {
            return;
        }
        int rank = Skills.rank(caster, skillFor(kind));
        if (rank <= 0) {
            return;
        }
        long now = level.getGameTime();
        Map<Invasive, Long> mine = LAST.computeIfAbsent(caster.getUUID(), id -> new HashMap<>());
        long last = mine.getOrDefault(kind, -99999L);
        int cooldown = Math.max(20, Config.GREEN_HAND_COOLDOWN.get() * 20 - rank * 20);
        if (now - last < cooldown) {
            return;
        }
        mine.put(kind, now);
        unleash(level, caster, kind, rank, at, now);
    }

    /**
     * What is in your hand, read as a weapon. Kudzu has no entry in the lesser-weed enum, so it is
     * answered for by blackberry's slot - the tide is driven by its own skill either way.
     */
    @javax.annotation.Nullable
    private static Invasive heldPlant(ItemStack stack) {
        if (stack.is(VengefulWoods.KUDZU_ITEM.get()) || stack.is(VengefulWoods.KUDZU_LEAVES_ITEM.get())
                || stack.is(VengefulWoods.KUDZU_ROOT_ITEM.get())) {
            return Invasive.BLACKBERRY;   // stands in for kudzu: see skillFor and unleash
        }
        if (stack.is(VengefulWoods.WISTERIA_ITEM.get()) || stack.is(VengefulWoods.WISTERIA_BLOOM_ITEM.get())) {
            return Invasive.WISTERIA;
        }
        if (stack.is(VengefulWoods.KNOTWEED_ITEM.get()) || stack.is(VengefulWoods.KNOTWEED_STEM_ITEM.get())
                || stack.is(VengefulWoods.KNOTWEED_ROOT_ITEM.get())) {
            return Invasive.KNOTWEED;
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Strength, and the risk
    // ------------------------------------------------------------------------------------------------------------

    /**
     * How much of this plant is in the ground, which is the whole of its strength. A species you have never
     * planted does nothing at all when you call it.
     */
    static int standing(ServerLevel level, Invasive kind) {
        if (level.getServer() == null) {
            return 0;
        }
        WrathData.Escape escape = WrathData.global(level.getServer()).escapes.get(kind.name());
        return escape == null ? 0 : Math.max(0, escape.grown - escape.cleared);
    }

    /**
     * The chance it turns on you instead. It rises with the sheer weight of green in the world - the more
     * of it there is, the less of it is listening - and it never passes one time in five, because a power
     * that fails half the time is not a power.
     */
    /** Kudzu keeps no escape record of its own, so its weight is read off the weeds' pool. */
    static int kudzuStanding(ServerLevel level) {
        return (int) Biomass.weedPool(level);
    }

    static double backfireChance(ServerLevel level) {
        double pool = Biomass.weedPool(level);
        double cap = Math.max(1.0, Config.BIOMASS_CAP.get());
        double chance = (pool / cap) * Config.GREEN_HAND_BACKFIRE.get();
        return Math.min(Config.GREEN_HAND_BACKFIRE_CAP.get(), Math.max(0.0, chance));
    }

    // ------------------------------------------------------------------------------------------------------------
    // The three of them
    // ------------------------------------------------------------------------------------------------------------

    private static void unleash(ServerLevel level, ServerPlayer caster, Invasive kind, int rank,
                                BlockPos at, long now) {
        int standing = kind == Invasive.BLACKBERRY ? kudzuStanding(level) : standing(level, kind);
        if (standing < Config.GREEN_HAND_MINIMUM.get()) {
            caster.displayClientMessage(Component.translatable("message.vengefulwoods.hand_thin",
                    Component.translatable(kind.block().get().getDescriptionId()))
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        // Strength: how much is out there, tempered so a whole valley of it is strong, not absurd.
        // Flat enough that a valley of the stuff is still better than a field of it. It used to top out
        // at two hundred blocks, which made planting more of it pointless.
        double power = Math.min(Config.GREEN_HAND_MAX_POWER.get(),
                Math.sqrt(standing) / 12.0 * rank);
        boolean turned = level.random.nextDouble() < backfireChance(level);
        LivingEntity victim = null;

        if (turned) {
            victim = caster;
            caster.displayClientMessage(Component.translatable("message.vengefulwoods.hand_turned")
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD), false);
        }

        switch (kind) {
            case WISTERIA:
                strangle(level, caster, at, power, victim);
                break;
            case KNOTWEED:
                impale(level, caster, at, power, victim);
                break;
            default:
                tide(level, caster, at, power, victim);
                break;
        }
    }

    /** Wisteria: it comes up around a thing and closes, slowly, and does not let go. */
    private static void strangle(ServerLevel level, ServerPlayer caster, BlockPos at, double power,
                                 LivingEntity turned) {
        double reach = 4.0 + power * 2.0;
        BlockState wood = VengefulWoods.WISTERIA.get().defaultBlockState();
        BlockState bloom = VengefulWoods.WISTERIA_BLOOM.get().defaultBlockState();
        RandomSource random = level.random;

        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(at).inflate(reach))) {
            if (!valid(caster, target, turned)) {
                continue;
            }
            BlockPos feet = target.blockPosition();
            for (int i = 0; i < 4 + (int) (power * 3); i++) {
                BlockPos spot = feet.offset(random.nextInt(3) - 1, random.nextInt(3), random.nextInt(3) - 1);
                if (level.isLoaded(spot) && (level.getBlockState(spot).isAir()
                        || level.getBlockState(spot).canBeReplaced())) {
                    level.setBlock(spot.immutable(), random.nextInt(3) == 0 ? bloom : wood, 3);
                }
            }
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 4, true, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 1, true, false, false));
            DamageSource source = Rhizomes.tendrilDamage(level);
            if (source != null) {
                target.hurt(source, (float) (2.0 + power));
            }
            level.sendParticles(ParticleTypes.COMPOSTER, target.getX(), target.getY() + 1.0, target.getZ(),
                    24, 0.4, 0.8, 0.4, 0.04);
        }
        Sounds.play(level, at, Sounds.WOOD_BREAK, SoundSource.HOSTILE, 1.0F, 0.5F);
    }

    /** Knotweed: a cane comes up through the floor and through whatever was standing on it. */
    private static void impale(ServerLevel level, ServerPlayer caster, BlockPos at, double power,
                               LivingEntity turned) {
        double reach = 3.0 + power * 1.5;
        BlockState cane = VengefulWoods.KNOTWEED_STEM.get().defaultBlockState();
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(at).inflate(reach))) {
            if (!valid(caster, target, turned)) {
                continue;
            }
            BlockPos feet = target.blockPosition();
            int height = 2 + (int) power;
            for (int up = 0; up < height; up++) {
                BlockPos spot = feet.above(up);
                if (level.isLoaded(spot) && (level.getBlockState(spot).isAir()
                        || level.getBlockState(spot).canBeReplaced())) {
                    level.setBlock(spot.immutable(), cane, 3);
                }
            }
            DamageSource source = Rhizomes.tendrilDamage(level);
            if (source != null) {
                target.hurt(source, (float) (4.0 + power * 1.2));
            }
            target.setDeltaMovement(target.getDeltaMovement().add(0.0, 0.45 + power * 0.08, 0.0));
            target.hurtMarked = true;
            level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY() + 0.8, target.getZ(),
                    22, 0.3, 0.5, 0.3, 0.3);
        }
        Sounds.play(level, at, Sounds.ROOTS_BREAK, SoundSource.HOSTILE, 1.0F, 0.7F);
    }

    /** The tide: kudzu arrives in a wall of green and keeps arriving. */
    private static void tide(ServerLevel level, ServerPlayer caster, BlockPos at, double power,
                             LivingEntity turned) {
        int radius = 3 + (int) (power * 2.0);
        BlockPos centre = turned != null ? caster.blockPosition() : at;
        Kudzu.seed(level, centre, radius);
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                new AABB(centre).inflate(radius + 2.0))) {
            if (!valid(caster, target, turned)) {
                continue;
            }
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 140, 3, true, false, false));
        }
        level.sendParticles(ParticleTypes.COMPOSTER, centre.getX() + 0.5, centre.getY() + 1.0,
                centre.getZ() + 0.5, 90, radius * 0.6, 1.0, radius * 0.6, 0.06);
        Sounds.play(level, centre, Sounds.GRASS_PLACE, SoundSource.HOSTILE, 1.2F, 0.5F);
    }

    /** Who it lands on: everything but the caster, unless the caster is the one it turned on. */
    private static boolean valid(ServerPlayer caster, LivingEntity target, LivingEntity turned) {
        if (!target.isAlive()) {
            return false;
        }
        if (turned != null) {
            return target == turned;
        }
        return target != caster;
    }
}
