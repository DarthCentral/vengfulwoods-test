package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.entity.FallingTreeEntity;
import com.ferreusveritas.dynamictrees.tree.species.Species;
import com.ferreusveritas.dynamictrees.util.BranchDestructionData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.ForgeRegistries;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Counts destroyed trees and works out who to blame.
 * <p>
 * Whenever Dynamic Trees destroys part of a tree it spawns a "falling tree" entity that says how the tree died:
 * chopped (HARVEST), dug out by the roots (ROOT), burned (FIRE) or blown up (BLAST). We watch for those, then
 * look for the player responsible: who was breaking tree blocks there a moment ago, who lit the fire, who set
 * off the explosive, or failing all of that, who is standing closest.
 */
public class FellingTracker {

    private static final int FIRE_RADIUS = 48;
    private static final int BLAST_RADIUS = 16;
    private static final long BLAST_MEMORY_TICKS = 100L;
    private static final long BREAK_MEMORY_TICKS = 60L;
    private static final double BREAK_MATCH_RADIUS = 5.0;
    private static final double FALLBACK_RADIUS = 32.0;
    /** The same tree is never counted twice within this many ticks (5 minutes). */
    private static final long SAME_TREE_TICKS = 6000L;

    private record Mark(ResourceKey<Level> dim, BlockPos pos, long time, @Nullable UUID player) {
    }

    private record Spot(ResourceKey<Level> dim, BlockPos pos) {
    }

    private static final List<Mark> IGNITIONS = new ArrayList<>();
    private static final List<Mark> BLASTS = new ArrayList<>();
    private static final List<Mark> BREAKS = new ArrayList<>();
    private static final Map<Spot, Long> RECENT_TREES = new HashMap<>();

    public static void clear() {
        IGNITIONS.clear();
        BLASTS.clear();
        BREAKS.clear();
        RECENT_TREES.clear();
    }

    /** Remember who was chopping, and where. */
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        Player player = event.getPlayer();
        if (player == null || player.level().isClientSide() || !TreeHelper.isTreePart(event.getState())) {
            return;
        }
        addMark(BREAKS, new Mark(player.level().dimension(), event.getPos().immutable(),
                player.level().getGameTime(), player.getUUID()));
    }

    /** Remember where a player lights a fire: flint and steel, fire charge or lava bucket. */
    @SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        if (level.isClientSide()) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (stack.is(Items.FLINT_AND_STEEL) || stack.is(Items.FIRE_CHARGE) || stack.is(Items.LAVA_BUCKET)) {
            addMark(IGNITIONS, new Mark(level.dimension(), event.getPos().immutable(), level.getGameTime(),
                    event.getEntity().getUUID()));
        }
    }

    /** Remember where TNT goes off, and who was nearest to setting it off. */
    @SubscribeEvent
    public void onExplosion(ExplosionEvent.Detonate event) {
        Level level = event.getLevel();
        if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
            return;
        }
        Entity source = event.getExplosion().getExploder();
        if (Config.ALL_EXPLOSIONS.get() || source instanceof PrimedTnt || isTntMinecart(source)) {
            BlockPos pos = BlockPos.containing(event.getExplosion().getPosition());
            ServerPlayer nearest = ForestDirector.nearestPlayer(serverLevel.players(), pos, FALLBACK_RADIUS, false);
            addMark(BLASTS, new Mark(level.dimension(), pos, level.getGameTime(),
                    nearest == null ? null : nearest.getUUID()));
        }
    }

    private static boolean isTntMinecart(@Nullable Entity entity) {
        if (entity == null) {
            return false;
        }
        EntityType<?> tntMinecart = ForgeRegistries.ENTITY_TYPES.getValue(new ResourceLocation("minecraft", "tnt_minecart"));
        return tntMinecart != null && entity.getType() == tntMinecart;
    }

    @SubscribeEvent
    public void onEntityJoin(EntityJoinLevelEvent event) {
        if (event.loadedFromDisk() || !(event.getLevel() instanceof ServerLevel level)) {
            return;
        }
        if (!(event.getEntity() instanceof FallingTreeEntity fallingTree)) {
            return;
        }
        try {
            handleDestroyedTree(level, fallingTree);
        } catch (RuntimeException e) {
            VengefulWoods.LOGGER.error("Vengeful Woods failed to process a destroyed tree", e);
        }
    }

    private static void handleDestroyedTree(ServerLevel level, FallingTreeEntity fallingTree) {
        if (Treefall.isDeliberate()) {
            return; // The forest threw this tree itself; it is not a grievance against anyone.
        }
        BranchDestructionData data = fallingTree.getDestroyData();
        if (data == null || data.getNumBranches() < Config.MIN_BRANCHES.get()) {
            return;
        }
        long now = level.getGameTime();
        BlockPos cutPos = data.cutPos;
        ResourceKey<Level> dim = level.dimension();

        UUID culprit = null;
        boolean counts;
        switch (fallingTree.destroyType) {
            case HARVEST: // chopped
            case ROOT:    // the soil block under the trunk was dug out
                culprit = blame(BREAKS, dim, cutPos, BREAK_MATCH_RADIUS, now, BREAK_MEMORY_TICKS);
                counts = true;
                break;
            case FIRE:
                long fireMemory = Config.FIRE_MEMORY_MINUTES.get() * 1200L;
                culprit = blame(IGNITIONS, dim, cutPos, FIRE_RADIUS, now, fireMemory);
                counts = !Config.FIRE_NEEDS_PLAYER.get() || culprit != null;
                if (counts) {
                    // The fire is spreading: keep following it from tree to tree, still blaming whoever lit it.
                    addMark(IGNITIONS, new Mark(dim, cutPos.immutable(), now, culprit));
                }
                break;
            case BLAST:
                culprit = blame(BLASTS, dim, cutPos, BLAST_RADIUS, now, BLAST_MEMORY_TICKS);
                counts = wasMarked(BLASTS, dim, cutPos, BLAST_RADIUS, now, BLAST_MEMORY_TICKS);
                break;
            default:
                counts = false;
        }

        if (!counts) {
            // Nobody is to blame for this one, so something else destroyed it: a creeper, a stray fire.
            // The trees around here take it out on mobs for a while.
            if (fallingTree.destroyType == FallingTreeEntity.DestroyType.BLAST
                    || fallingTree.destroyType == FallingTreeEntity.DestroyType.FIRE) {
                Treefall.addGrudge(level, cutPos, now);
            }
            return;
        }

        if (culprit == null) {
            // Last resort: whoever is standing closest gets the blame.
            ServerPlayer nearest = ForestDirector.nearestPlayer(level.players(), cutPos, FALLBACK_RADIUS, false);
            if (nearest == null) {
                return; // Nobody around to hold responsible.
            }
            culprit = nearest.getUUID();
        }

        // Work out which tree this was, so chopping the same tree in two pieces only counts once.
        BlockPos rootPos = findRoot(level, data);
        Spot spot = new Spot(dim, rootPos);
        Long last = RECENT_TREES.get(spot);
        if (last != null && now - last < SAME_TREE_TICKS) {
            return;
        }
        if (RECENT_TREES.size() > 4096) {
            RECENT_TREES.clear();
        }
        RECENT_TREES.put(spot, now);

        MinecraftServer server = level.getServer();
        WrathData global = WrathData.global(server);
        Stage before = global.account(culprit).stage();
        global.addFelled(culprit);
        WrathData.Account account = global.account(culprit);
        Stage after = account.stage();

        ServerPlayer blamed = server.getPlayerList().getPlayer(culprit);
        if (blamed != null) {
            dropHeartwood(level, blamed, rootPos);
            Classes.paidForFelling(blamed);
        }
        if (Config.SHOW_COUNTER.get() && blamed != null) {
            blamed.displayClientMessage(Component.translatable("message.vengefulwoods.counter", account.effectiveFelled())
                    .withStyle(ChatFormatting.DARK_GREEN), true);
        }

        if (after != before) {
            SpeciesTuner.apply(WrathData.worstStage(server));
            announce(server, blamed, after);
        }

        // Cut down enough of it and something else moves into the gap you made.
        int trigger = Config.KUDZU_TRIGGER_TREES.get();
        if (trigger > 0 && account.felled == trigger && blamed != null && Config.KUDZU_SEEDS_ITSELF.get()) {
            Kudzu.triggerNear(level, blamed);
        }

        // Stage 5 and up: every destroyed tree has a chance to come back a day later.
        Species species = data.species;
        if (species != null && species.isValid()) {
            if (after.regrowsTrees() && level.random.nextDouble() < after.regrowChance()) {
                WrathData local = WrathData.get(level);
                local.regrows.add(new WrathData.Regrow(rootPos, species.getRegistryName().toString(),
                        now + 24000L, level.getDayTime() + 24000L));
                local.setDirty();
            } else if (after.sproutsOnStumps()) {
                // Stage 4: something is already growing on the stump before you have walked away.
                ForestDirector.sproutOnStump(level, rootPos, species, after, now);
            }
        }
    }

    /** Finds the rooty soil block of the tree a destroyed piece belonged to. */
    private static BlockPos findRoot(ServerLevel level, BranchDestructionData data) {
        BlockPos cutPos = data.cutPos;
        if (TreeHelper.isRooty(level.getBlockState(cutPos.below()))) {
            return cutPos.below();
        }
        Direction towardsRoot = data.cutDir == null ? Direction.DOWN : data.cutDir;
        BlockPos root = TreeHelper.findRootNode(level, cutPos.relative(towardsRoot));
        if (root != null && !root.equals(BlockPos.ZERO)) {
            return root.immutable();
        }
        return cutPos.below();
    }

    /**
     * Heartwood out of a felled tree.
     * <p>
     * It used to come only as a gift once the forest liked you, which left anyone playing against the woods
     * with no way to make its gear at all. Now the wood itself yields it - rarely - so both roads are open.
     * A Colonialist, who does nothing but fell, gets a good deal more of it.
     */
    private static void dropHeartwood(ServerLevel level, ServerPlayer player, BlockPos pos) {
        double chance = Config.HEARTWOOD_FROM_FELLING.get();
        if (chance <= 0.0) {
            return;
        }
        chance *= WoodsClass.heartwoodRate(player);
        int count = 0;
        while (chance >= 1.0) {
            count++;
            chance -= 1.0;
        }
        if (level.random.nextDouble() < chance) {
            count++;
        }
        if (count <= 0) {
            return;
        }
        net.minecraft.world.level.block.Block.popResource(level, pos.above(),
                new ItemStack(VengefulWoods.HEARTWOOD.get(), count));
    }

    private static void announce(MinecraftServer server, @Nullable ServerPlayer blamed, Stage stage) {
        VengefulWoods.LOGGER.info("Vengeful Woods reached stage {} for a player", stage);
        if (!Config.ANNOUNCE.get() || blamed == null) {
            return;
        }
        // The forest's quarrel is with one person, so only that person hears it.
        blamed.displayClientMessage(Component.translatable("message.vengefulwoods.stage." + stage.ordinal())
                .withStyle(ChatFormatting.DARK_GREEN, ChatFormatting.ITALIC), false);
        Sounds.play(blamed.level(), blamed.blockPosition(),
                stage.atLeast(Stage.HUNTING) ? Sounds.CURSE : Sounds.HEARTBEAT,
                SoundSource.AMBIENT, 1.0F, 0.6F);
    }

    private static void addMark(List<Mark> marks, Mark mark) {
        if (marks.size() >= 256) {
            marks.remove(0);
        }
        marks.add(mark);
    }

    /** The player recorded nearest to this spot, if there is one. */
    @Nullable
    private static UUID blame(List<Mark> marks, ResourceKey<Level> dim, BlockPos pos, double radius, long now, long memoryTicks) {
        UUID best = null;
        double bestDistSq = radius * radius;
        for (int i = marks.size() - 1; i >= 0; i--) {
            Mark mark = marks.get(i);
            if (now - mark.time() > memoryTicks) {
                marks.remove(i);
                continue;
            }
            double distSq = mark.pos().distSqr(pos);
            if (mark.dim() == dim && distSq <= bestDistSq && mark.player() != null) {
                bestDistSq = distSq;
                best = mark.player();
            }
        }
        return best;
    }

    /** Whether anything at all was recorded here, with or without a player attached. */
    private static boolean wasMarked(List<Mark> marks, ResourceKey<Level> dim, BlockPos pos, double radius, long now, long memoryTicks) {
        double maxDistSq = radius * radius;
        for (int i = marks.size() - 1; i >= 0; i--) {
            Mark mark = marks.get(i);
            if (now - mark.time() > memoryTicks) {
                marks.remove(i);
                continue;
            }
            if (mark.dim() == dim && mark.pos().distSqr(pos) <= maxDistSq) {
                return true;
            }
        }
        return false;
    }
}
