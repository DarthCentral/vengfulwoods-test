package com.vengefulwoods;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The specialists.
 * <p>
 * A brush hook will cut anything green, badly. These three each answer one of the weeds that a brush hook
 * cannot really deal with: the woody one, the buried one, and the one that fights back. Each is a weapon in
 * its own right as well, because the things living under a kudzu canopy have to be got through first.
 */
public class WeedToolItem extends SwordItem {

    /** What a given tool is for, and how far its swing reaches. */
    public enum Kind {
        /**
         * Heartwood lopper. Two heavy blades on a long handle, made for wood. The only tool that gets its
         * full reach through wisteria, which is otherwise the worst thing in the mod to clear.
         */
        LOPPER(4, 4, 0),
        /**
         * Grubbing mattock. Knotweed and kudzu both live mostly underground, where nothing else you own can
         * reach. This goes down after them.
         */
        MATTOCK(3, 0, 8),
        /**
         * Hedge slasher. A wide shallow sweep through brambles and dry grass. Holding it keeps the thorns
         * off you, which is the only way to stand in a blackberry thicket and work.
         */
        SLASHER(6, 2, 0);

        public final int reach;
        /** How far up and down an ordinary swing takes. */
        public final int height;
        /** How far below the struck block it digs, for the one that digs. */
        public final int depth;

        Kind(int reach, int height, int depth) {
            this.reach = reach;
            this.height = height;
            this.depth = depth;
        }

        /** Whether this tool is the right answer to what has just been struck. */
        boolean handles(BlockState state) {
            Invasive weed = Invasives.kindOf(state);
            boolean kudzu = Kudzu.isKudzu(state);
            switch (this) {
                case LOPPER:
                    // Woody growth: wisteria, and the kudzu vine itself, which is woody too.
                    return weed == Invasive.WISTERIA || weed == Invasive.BLACKBERRY
                            || (kudzu && !state.is(VengefulWoods.KUDZU_LEAVES.get()));
                case MATTOCK:
                    // Anything in the ground, plus the forest's own roots.
                    return weed == Invasive.KNOTWEED || weed == Invasive.WISTERIA || kudzu
                            || state.is(VengefulWoods.RHIZOME.get());
                default:
                    return weed == Invasive.BLACKBERRY || weed == Invasive.CHEATGRASS
                            || weed == Invasive.KNOTWEED || weed == Invasive.WATER_HYACINTH
                            || state.is(VengefulWoods.KUDZU_LEAVES.get());
            }
        }
    }

    public final Kind kind;

    public WeedToolItem(Kind kind, int attack, int durability) {
        super(Tiers.IRON, attack, kind == Kind.SLASHER ? -2.0F : -2.8F,
                new Item.Properties().durability(durability));
        this.kind = kind;
    }

    /** True while the player is holding a slasher, which is what keeps bramble thorns out of them. */
    public static boolean wardsThorns(Player player) {
        for (ItemStack stack : new ItemStack[]{player.getMainHandItem(), player.getOffhandItem()}) {
            if (stack.getItem() instanceof WeedToolItem tool && tool.kind == Kind.SLASHER) {
                return true;
            }
        }
        return false;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }
        BlockPos origin = context.getClickedPos();
        if (!kind.handles(level.getBlockState(origin))) {
            return InteractionResult.PASS; // Wrong tool for this. Use the one it is for.
        }

        int reach = kind.reach;
        BlockPos from = origin.offset(-reach, -kind.height - kind.depth, -reach);
        BlockPos to = origin.offset(reach, kind.height, reach);

        int weeds = 0;
        int kudzu = 0;
        for (BlockPos pos : BlockPos.betweenClosed(from, to)) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (!kind.handles(state)) {
                continue;
            }
            Invasive weed = Invasives.kindOf(state);
            boolean wasKudzu = Kudzu.isKudzu(state);
            // Nothing drops from a tool sweep. One swing can take hundreds of blocks, and hundreds of
            // item entities is how a server dies. Clear it by hand if you want the harvest.
            serverLevel.destroyBlock(pos.immutable(), false);
            if (weed != null) {
                Invasives.noteCleared(serverLevel, weed, 1);
                weeds++;
            } else if (wasKudzu) {
                kudzu++;
            }
        }
        int cut = weeds + kudzu;
        if (cut == 0) {
            return InteractionResult.PASS;
        }

        Sounds.play(level, origin, kind == Kind.MATTOCK ? Sounds.ROOTS_BREAK : Sounds.WOOD_BREAK,
                SoundSource.BLOCKS, 1.0F, kind == Kind.LOPPER ? 0.7F : 1.0F);
        ItemStack stack = context.getItemInHand();
        if (context.getPlayer() instanceof ServerPlayer player) {
            // Clearing with the right tool is worth as much favour as doing it the slow way.
            if (weeds > 0) {
                Invasives.creditWeeding(player, weeds);
            }
            if (kudzu > 0) {
                Kudzu.creditClearing(player, kudzu);
            }
            stack.hurtAndBreak(Math.max(1, cut / 6), player, holder -> {
            });
        }
        return InteractionResult.SUCCESS;
    }
}
