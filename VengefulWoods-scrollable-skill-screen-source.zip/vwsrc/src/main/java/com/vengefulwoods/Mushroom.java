package com.vengefulwoods;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.List;
import java.util.Map;

/**
 * The hidden one.
 * <p>
 * It is nearly nothing for a long time: fungus swells where you stand and that is all. What it is building
 * toward is the Original - a fruiting body the size of a tower, covered in eyes, that does not so much attack
 * as make the ground around it stop agreeing on where it goes. Inside its reach, doorways open onto places
 * they should not reach, the way back is not the way you came, and something is watching from every surface.
 * <p>
 * The Mushroom walks through all of it untouched, because to the Original it is not an intruder. Everything
 * else is.
 */
public class Mushroom {

    /** One dimension's Originals, and the doorways they have thrown. */
    private static final class Grove {
        final List<BlockPos> originals = new ArrayList<>();
        final Map<BlockPos, BlockPos> doors = new HashMap<>();
        long lastSwell;
    }

    private static final Map<ResourceKey<Level>, Grove> GROVES = new HashMap<>();

    public static void clear() {
        GROVES.clear();
        SHIMMER_OFF.clear();
        CLOUDED.clear();
    }

    private static Grove grove(ServerLevel level) {
        return GROVES.computeIfAbsent(level.dimension(), key -> new Grove());
    }

    // ------------------------------------------------------------------------------------------------------------
    // The slow part
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, List<ServerPlayer> players, long now) {
        if (!Config.CLASSES_ENABLED.get() || players.isEmpty()) {
            return;
        }
        Grove grove = grove(level);
        int every = Config.MUSHROOM_SPREAD_SECONDS.get() * 20;
        for (ServerPlayer player : players) {
            int rank = Skills.rank(player, Skill.MYCELIAL);
            if (rank > 0) {
                every = Math.max(20, every / (1 + rank)); // It answers to you faster.
                break;
            }
        }
        if (now - grove.lastSwell >= every) {
            grove.lastSwell = now;
            for (ServerPlayer player : players) {
                if (WoodsClass.of(player) == WoodsClass.MUSHROOM) {
                    swell(level, player);
                }
            }
        }
        if (now % 40L == 0L && !grove.originals.isEmpty()) {
            haze(level, grove, players, now);
        }
        if (now % 60L == 0L && !grove.originals.isEmpty()) {
            whisper(level, grove, players);
            fruit(level, grove);
        }
        if (now % 400L == 0L) {
            senseImbalance(level, players);
        }
        if (now % (Config.ORIGINAL_BREED_MINUTES.get() * 1200L) == 0L) {
            propagate(level, grove, players, now);
        }
        // The drone is forty seconds long and restarts as it ends, so inside the reach of an Original
        // there is never a moment of quiet.
        if (now % 800L == 0L && !grove.originals.isEmpty() && Config.ORIGINAL_MUSIC.get()) {
            for (BlockPos original : grove.originals) {
                level.playSound(null, original.getX() + 0.5, original.getY() + 20.0, original.getZ() + 0.5,
                        VengefulWoods.ORIGINAL_DRONE.get(), SoundSource.AMBIENT,
                        Math.max(1.0F, Config.MUSHROOM_HAZE_RANGE.get() / 16.0F), 1.0F);
            }
        }
        if (now % 10L == 0L) {
            shieldStep(level, players);
        }
        if (now % 40L == 0L) {
            deepRootStep(level, players);
        }
    }

    /**
     * The shimmer.
     * <p>
     * Nothing gets within two blocks of a Mushroom. Whatever tries is simply put back down further away,
     * mid-swing, with a smear of spores where it was standing. It is not a wall - there is no wall - things
     * just keep finding that they are not as close as they thought they were.
     */
    private static void shieldStep(ServerLevel level, List<ServerPlayer> players) {
        if (!Config.MUSHROOM_SHIELD.get()) {
            return;
        }
        for (ServerPlayer player : players) {
            int rank = Skills.rank(player, Skill.SHIMMER);
            if (rank <= 0 || !player.isAlive() || player.isSpectator() || isOff(player)) {
                continue;
            }
            // Four blocks at the first rank, further with each one after.
            double keep = Config.MUSHROOM_SHIELD_RANGE.get() + (rank - 1);
            // A ring of spores hanging in the air, so the thing is visible rather than mysterious.
            for (int i = 0; i < 6; i++) {
                double angle = (level.getGameTime() * 0.08) + i * (Math.PI / 3.0);
                level.sendParticles(ParticleTypes.PORTAL,
                        player.getX() + Math.cos(angle) * keep, player.getY() + 1.0 + Math.sin(angle * 2) * 0.4,
                        player.getZ() + Math.sin(angle) * keep, 1, 0.02, 0.02, 0.02, 0.0);
            }

            for (LivingEntity intruder : level.getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(keep))) {
                if (intruder == player || !intruder.isAlive()) {
                    continue;
                }
                if (intruder instanceof ServerPlayer other && WoodsClass.of(other) == WoodsClass.MUSHROOM) {
                    continue; // Its own are allowed close.
                }
                double dx = intruder.getX() - player.getX();
                double dz = intruder.getZ() - player.getZ();
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > keep) {
                    continue;
                }
                // Put down two blocks further out than it meant to be, facing the same way, confused.
                double scale = (keep + 2.0) / Math.max(0.25, dist);
                double x = player.getX() + dx * scale;
                double z = player.getZ() + dz * scale;
                BlockPos landing = topOpen(level, new BlockPos((int) x, (int) intruder.getY(), (int) z));
                if (landing == null) {
                    continue;
                }
                level.sendParticles(ParticleTypes.PORTAL, intruder.getX(), intruder.getY() + 1.0,
                        intruder.getZ(), 18, 0.3, 0.6, 0.3, 0.3);
                intruder.teleportTo(landing.getX() + 0.5, landing.getY(), landing.getZ() + 0.5);
                intruder.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0, true, false, false));
                level.playSound(null, landing, VengefulWoods.EYE_STARE.get(), SoundSource.HOSTILE, 0.6F, 1.2F);
            }
        }
    }

    /**
     * Fungus thickens around whoever is standing in it. Slowly, for a long time - this is the whole of the
     * class until the Original goes up, and it is meant to feel like very little.
     */
    private static void swell(ServerLevel level, ServerPlayer player) {
        RandomSource random = level.random;
        BlockPos centre = player.blockPosition();
        int grown = 0;
        for (int attempt = 0; attempt < 40 && grown < 3; attempt++) {
            BlockPos pos = centre.offset(random.nextInt(13) - 6, random.nextInt(5) - 2, random.nextInt(13) - 6);
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            BlockState below = level.getBlockState(pos.below());

            // A small mushroom standing on its own becomes a huge one.
            if (state.is(Blocks.RED_MUSHROOM) || state.is(Blocks.BROWN_MUSHROOM)) {
                boolean red = state.is(Blocks.RED_MUSHROOM);
                raiseCap(level, pos, red);
                grown++;
                continue;
            }
            // Bare ground under the fungus turns to mycelium, and new buttons come up out of it.
            if (state.isAir() && (below.is(Blocks.MYCELIUM) || below.is(Blocks.PODZOL))) {
                level.setBlock(pos, (random.nextBoolean() ? Blocks.RED_MUSHROOM : Blocks.BROWN_MUSHROOM)
                        .defaultBlockState(), 3);
                grown++;
            } else if (below.is(Blocks.GRASS_BLOCK) || below.is(Blocks.DIRT)) {
                level.setBlock(pos.below(), Blocks.MYCELIUM.defaultBlockState(), 3);
                grown++;
            }
        }
    }

    /**
     * Fungus is what arrives when something else has died.
     * <p>
     * If the wood around a player has been cut to almost nothing, the mushrooms read it as an opening and
     * take the ground themselves - with or without a Mushroom present. Somebody who clear-cuts a valley
     * does not get a bare valley. They get this.
     */
    private static void senseImbalance(ServerLevel level, List<ServerPlayer> players) {
        if (!Config.MUSHROOM_OPPORTUNISM.get()) {
            return;
        }
        RandomSource random = level.random;
        for (ServerPlayer player : players) {
            if (player.isSpectator()) {
                continue;
            }
            BlockPos centre = player.blockPosition();
            int trees = 0;
            int ground = 0;
            for (int attempt = 0; attempt < 90; attempt++) {
                BlockPos probe = centre.offset(random.nextInt(49) - 24, random.nextInt(17) - 8,
                        random.nextInt(49) - 24);
                if (!level.isLoaded(probe)) {
                    continue;
                }
                BlockState state = level.getBlockState(probe);
                if (com.ferreusveritas.dynamictrees.api.TreeHelper.isBranch(state)) {
                    trees++;
                }
                BlockState below = level.getBlockState(probe.below());
                if (state.isAir() && (below.is(Blocks.GRASS_BLOCK) || below.is(Blocks.DIRT)
                        || below.is(Blocks.PODZOL) || below.is(Blocks.MYCELIUM))) {
                    ground++;
                }
            }
            // Plenty of open ground and almost no wood left standing on it: an opening.
            if (ground < 8 || trees > Config.MUSHROOM_IMBALANCE.get()) {
                continue;
            }
            int taken = 0;
            for (int attempt = 0; attempt < 40 && taken < 6; attempt++) {
                BlockPos spot = centre.offset(random.nextInt(41) - 20, random.nextInt(11) - 5,
                        random.nextInt(41) - 20);
                if (!level.isLoaded(spot)) {
                    continue;
                }
                BlockState state = level.getBlockState(spot);
                BlockState below = level.getBlockState(spot.below());
                if (state.is(Blocks.RED_MUSHROOM) || state.is(Blocks.BROWN_MUSHROOM)) {
                    raiseCap(level, spot, state.is(Blocks.RED_MUSHROOM));
                    taken++;
                } else if (below.is(Blocks.GRASS_BLOCK) || below.is(Blocks.DIRT)) {
                    level.setBlock(spot.below(), Blocks.MYCELIUM.defaultBlockState(), 3);
                    if (state.isAir() && random.nextInt(3) == 0) {
                        level.setBlock(spot, (random.nextBoolean() ? Blocks.RED_MUSHROOM
                                : Blocks.BROWN_MUSHROOM).defaultBlockState(), 3);
                    }
                    taken++;
                }
            }
        }
    }

    /** A button becomes a tree-sized cap. Crude on purpose: it should look grown, not built. */
    private static void raiseCap(ServerLevel level, BlockPos foot, boolean red) {
        RandomSource random = level.random;
        int height = 3 + random.nextInt(4);
        BlockState stem = Blocks.MUSHROOM_STEM.defaultBlockState();
        BlockState cap = (red ? Blocks.RED_MUSHROOM_BLOCK : Blocks.BROWN_MUSHROOM_BLOCK).defaultBlockState();
        for (int up = 0; up < height; up++) {
            BlockPos pos = foot.above(up);
            if (!level.isLoaded(pos) || !canOvergrow(level.getBlockState(pos))) {
                return;
            }
            level.setBlock(pos, stem, 3);
        }
        BlockPos crown = foot.above(height);
        int radius = 2 + random.nextInt(2);
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                if (dx * dx + dz * dz > radius * radius + 1) {
                    continue;
                }
                for (int dy = 0; dy <= 1; dy++) {
                    BlockPos pos = crown.offset(dx, dy, dz);
                    if (level.isLoaded(pos) && canOvergrow(level.getBlockState(pos))) {
                        level.setBlock(pos, cap, 3);
                    }
                }
            }
        }
    }

    private static boolean canOvergrow(BlockState state) {
        return state.isAir() || state.canBeReplaced() || state.is(Blocks.RED_MUSHROOM)
                || state.is(Blocks.BROWN_MUSHROOM);
    }

    // ------------------------------------------------------------------------------------------------------------
    // The Original
    // ------------------------------------------------------------------------------------------------------------

    /**
     * Raises the thing itself: a stem that goes up until it runs out of sky, a cap the size of a hill, and
     * eyes. Called from the altar once the tribute is paid, and once is generally enough.
     */
    static boolean raiseOriginal(ServerLevel level, BlockPos altar, ServerPlayer player) {
        BlockPos base = altar.above();
        int sky = level.getMaxBuildHeight() - 30;
        int height = Math.min(Config.ORIGINAL_HEIGHT.get(), Math.max(24, sky - base.getY()));
        RandomSource random = level.random;

        BlockState stem = Blocks.MUSHROOM_STEM.defaultBlockState();
        BlockState cap = Blocks.RED_MUSHROOM_BLOCK.defaultBlockState();
        BlockState gill = Blocks.BROWN_MUSHROOM_BLOCK.defaultBlockState();
        BlockState eye = VengefulWoods.EYE.get().defaultBlockState();

        // The stalk. Thick at the foot, waisted, swelling again under the cap.
        int fat = Config.ORIGINAL_GIRTH.get();
        for (int up = 0; up < height; up++) {
            double t = (double) up / height;
            int radius = (int) Math.round(fat * (1.0 - 0.45 * Math.sin(t * Math.PI)) );
            radius = Math.max(2, radius);
            for (int dx = -radius; dx <= radius; dx++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    if (dx * dx + dz * dz > radius * radius) {
                        continue;
                    }
                    BlockPos pos = base.offset(dx, up, dz);
                    if (!level.isLoaded(pos)) {
                        continue;
                    }
                    boolean skin = dx * dx + dz * dz >= (radius - 1) * (radius - 1);
                    level.setBlock(pos, stem, 3);
                    if (skin && random.nextInt(26) == 0) {
                        cluster(level, pos, eye, random);   // eyes come in groups, never alone
                    }
                }
            }
        }

        // The cap: a wide dome, and underneath it the gills go light and dark in patches that do not
        // agree with the light anywhere else.
        BlockPos crown = base.above(height);
        int radius = Config.ORIGINAL_CAP.get();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radius) {
                    continue;
                }
                int lift = (int) Math.round(3.0 * Math.cos(dist / radius * Math.PI * 0.5));
                int thickness = (int) Math.max(1, 5 - dist * 4.0 / radius);
                for (int dy = 0; dy < thickness; dy++) {
                    BlockPos pos = crown.offset(dx, lift + dy, dz);
                    if (!level.isLoaded(pos)) {
                        continue;
                    }
                    level.setBlock(pos, cap, 3);
                }
                // Underside. Blotches of pale and dark, with eyes looking down out of them.
                BlockPos under = crown.offset(dx, lift - 1, dz);
                if (level.isLoaded(under)) {
                    double blotch = Math.sin(dx * 0.55) * Math.cos(dz * 0.47) + Math.sin((dx + dz) * 0.21);
                    BlockState below = blotch > 0.45 ? gill
                            : blotch < -0.55 ? Blocks.MUSHROOM_STEM.defaultBlockState() : cap;
                    level.setBlock(under, below, 3);
                    if (random.nextInt(34) == 0) {
                        level.setBlock(under, eye, 3);
                    }
                }
            }
        }

        grove(level).originals.add(base.immutable());
        level.sendParticles(ParticleTypes.PORTAL, base.getX() + 0.5, base.getY() + 4.0, base.getZ() + 0.5,
                260, 4.0, 8.0, 4.0, 0.4);
        Sounds.play(level, base, Sounds.ROOTS_BREAK, SoundSource.HOSTILE, 1.0F, 0.3F);
        level.playSound(null, base.getX() + 0.5, base.getY() + 20.0, base.getZ() + 0.5,
                VengefulWoods.ORIGINAL_DRONE.get(), SoundSource.AMBIENT, 4.0F, 1.0F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.original")
                .withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.BOLD), false);
        if (!canSummon(player)) {
            unlockSummon(player);
            player.displayClientMessage(Component.translatable("message.vengefulwoods.summon_learned")
                    .withStyle(ChatFormatting.LIGHT_PURPLE), false);
        }
        return true;
    }

    /**
     * Eyes are never one block. Where one opens, three or four more open around it, which is the
     * difference between a decoration and being looked at.
     */
    private static void cluster(ServerLevel level, BlockPos centre, BlockState eye, RandomSource random) {
        level.setBlock(centre, eye, 3);
        int extra = 2 + random.nextInt(4);
        for (int i = 0; i < extra; i++) {
            BlockPos pos = centre.offset(random.nextInt(3) - 1, random.nextInt(5) - 2, random.nextInt(3) - 1);
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (state.is(Blocks.MUSHROOM_STEM) || state.is(Blocks.RED_MUSHROOM_BLOCK)
                    || state.is(Blocks.BROWN_MUSHROOM_BLOCK)) {
                level.setBlock(pos.immutable(), eye, 3);
            }
        }
    }

    /**
     * The words.
     * <p>
     * Scraps of language drift through the air around an Original - some of it nearly readable, most of it
     * not. They are text displays rather than particles, so they hang in the world and turn to face you,
     * and they rot away on their own after a few seconds. Summoned by command because that is the one way
     * of building a display entity that cannot be got subtly wrong.
     */
    private static void whisper(ServerLevel level, Grove grove, List<ServerPlayer> players) {
        if (!Config.ORIGINAL_WORDS.get() || level.getServer() == null) {
            return;
        }
        RandomSource random = level.random;
        double range = hazeRange(level);
        // Clear the last breath of it before the next one. Display entities do not expire on their own,
        // and a drift of words is wanted, not a snowdrift of them.
        run(level, "kill @e[type=minecraft:text_display,tag=vengefulwoods_word]");
        for (ServerPlayer player : players) {
            if (player.isSpectator()) {
                continue;
            }
            boolean near = false;
            for (BlockPos original : grove.originals) {
                if (player.blockPosition().distSqr(original) <= range * range) {
                    near = true;
                    break;
                }
            }
            if (!near) {
                continue;
            }
            int many = 1 + random.nextInt(3);
            for (int i = 0; i < many; i++) {
                double angle = random.nextDouble() * Math.PI * 2.0;
                double away = 4.0 + random.nextDouble() * 12.0;
                double x = player.getX() + Math.cos(angle) * away;
                double y = player.getY() + 1.0 + random.nextDouble() * 6.0;
                double z = player.getZ() + Math.sin(angle) * away;
                speak(level, x, y, z, garble(random), random);
            }
        }
    }

    /** Words, as they arrive: some whole, most eaten. */
    private static final String[] WHOLE = {
            "it was here first", "you are late", "count them", "we remember the axe",
            "nothing was taken", "the gills know", "look up", "it is still counting",
            "you came back", "there is no outside", "breathe it", "we grew you",
    };

    private static String garble(RandomSource random) {
        String base = WHOLE[random.nextInt(WHOLE.length)];
        StringBuilder out = new StringBuilder();
        for (char c : base.toCharArray()) {
            if (c != ' ' && random.nextInt(5) == 0) {
                out.append((char) ('a' + random.nextInt(26)));   // the word slips
            } else if (c != ' ' && random.nextInt(11) == 0) {
                out.append(c).append(c);                          // or stuttters
            } else {
                out.append(c);
            }
        }
        if (random.nextInt(4) == 0) {
            return new StringBuilder(out.toString()).reverse().toString();
        }
        return out.toString();
    }

    /** Hangs one line of it in the air, facing whoever looks, and lets it rot. */
    private static void speak(ServerLevel level, double x, double y, double z, String text,
                              RandomSource random) {
        String safe = text.replace("\"", "").replace("\\", "");
        float scale = 0.6F + random.nextFloat() * 0.9F;
        int alpha = 90 + random.nextInt(110);
        String colour = String.format("#%02X%02X%02X%02X", alpha, 190 + random.nextInt(60),
                170 + random.nextInt(60), 210 + random.nextInt(45));
        String command = String.format(java.util.Locale.ROOT,
                "summon minecraft:text_display %.2f %.2f %.2f {text:'{\"text\":\"%s\",\"color\":\"%s\"}',"
                        + "billboard:\"center\",see_through:1b,background:0,alignment:\"center\","
                        + "transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],"
                        + "translation:[0f,0f,0f],scale:[%.2ff,%.2ff,%.2ff]},"
                        + "Tags:[\"vengefulwoods_word\"]}",
                x, y, z, safe, colour, scale, scale, scale);
        run(level, command);
    }

    /** Runs one command as the server itself, silently. */
    private static void run(ServerLevel level, String command) {
        if (level.getServer() == null) {
            return;
        }
        try {
            level.getServer().getCommands().performPrefixedCommand(
                    level.getServer().createCommandSourceStack().withSuppressedOutput().withPermission(4),
                    command);
        } catch (RuntimeException ignored) {
            // A refused command is not worth bringing a world down over.
        }
    }

    /** The Original fruits: lesser mushrooms keep coming up in its shadow. */
    private static void fruit(ServerLevel level, Grove grove) {
        RandomSource random = level.random;
        int radius = Config.ORIGINAL_CAP.get() + 12;
        for (BlockPos original : grove.originals) {
            for (int attempt = 0; attempt < 6; attempt++) {
                BlockPos spot = original.offset(random.nextInt(radius * 2) - radius,
                        random.nextInt(14) - 7, random.nextInt(radius * 2) - radius);
                if (!level.isLoaded(spot)) {
                    continue;
                }
                BlockState state = level.getBlockState(spot);
                BlockState below = level.getBlockState(spot.below());
                if (state.is(Blocks.RED_MUSHROOM) || state.is(Blocks.BROWN_MUSHROOM)) {
                    raiseCap(level, spot, state.is(Blocks.RED_MUSHROOM));
                } else if (state.isAir() && (below.is(Blocks.MYCELIUM) || below.is(Blocks.PODZOL))) {
                    level.setBlock(spot, (random.nextBoolean() ? Blocks.RED_MUSHROOM : Blocks.BROWN_MUSHROOM)
                            .defaultBlockState(), 3);
                } else if (below.is(Blocks.GRASS_BLOCK) || below.is(Blocks.DIRT) || below.is(Blocks.STONE)) {
                    level.setBlock(spot.below(), Blocks.MYCELIUM.defaultBlockState(), 3);
                }
            }
        }
    }

    /** How far the haze reaches, which somebody may have learned to widen. */
    private static double hazeRange(ServerLevel level) {
        double range = Config.MUSHROOM_HAZE_RANGE.get();
        for (ServerPlayer player : level.players()) {
            int rank = Skills.rank(player, Skill.MANY_EYES);
            if (rank > 0) {
                return range * (1.0 + 0.4 * rank);
            }
        }
        return range;
    }

    /**
     * Whether this player has already paid for one the long way, which is what unlocks calling them up
     * afterwards. Kept on the account, so it survives the world closing.
     */
    /**
     * Deep root: standing on your own ground mends you, and what mends you feeds the weed. The fungus is
     * not doing you a favour; you are simply part of the same thing now.
     */
    private static void deepRootStep(ServerLevel level, List<ServerPlayer> players) {
        for (ServerPlayer player : players) {
            int rank = Skills.rank(player, Skill.DEEP_ROOT);
            if (rank <= 0 || !player.isAlive()) {
                continue;
            }
            BlockState under = level.getBlockState(player.blockPosition().below());
            if (!under.is(Blocks.MYCELIUM) && !under.is(Blocks.RED_MUSHROOM_BLOCK)
                    && !under.is(Blocks.BROWN_MUSHROOM_BLOCK) && !under.is(Blocks.MUSHROOM_STEM)) {
                continue;
            }
            player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 60, rank - 1, true, false, true));
            if (rank >= 2) {
                player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 60, rank - 2, true, false, true));
            }
            if (rank >= 3) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 60, 0, true, false, true));
            }
            Biomass.growWeeds(level, rank, 40.0F / 24000.0F);
        }
    }

    /**
     * The spore cloud: everything that is not a Mushroom loses its eyes for a while. Thrown by using an
     * empty hand in the air, which is the only free gesture the class has left.
     */
    static boolean sporeCloud(ServerLevel level, ServerPlayer caster) {
        int rank = Skills.rank(caster, Skill.SPORE_CLOUD);
        if (rank <= 0) {
            return false;
        }
        long now = level.getGameTime();
        Long last = CLOUDED.get(caster.getUUID());
        int cooldown = Math.max(60, 400 - rank * 80);
        if (last != null && now - last < cooldown) {
            return false;
        }
        CLOUDED.put(caster.getUUID(), now);
        double reach = 5.0 + rank * 3.0;
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class,
                caster.getBoundingBox().inflate(reach))) {
            if (target == caster || !target.isAlive()) {
                continue;
            }
            if (target instanceof ServerPlayer other && WoodsClass.of(other) == WoodsClass.MUSHROOM) {
                continue;
            }
            target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60 + rank * 40, 0, true, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 120 + rank * 60, 0, true, false, false));
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 80 + rank * 30, rank - 1,
                    true, false, false));
        }
        level.sendParticles(ParticleTypes.COMPOSTER, caster.getX(), caster.getY() + 1.0, caster.getZ(),
                120 + rank * 60, reach * 0.4, 1.2, reach * 0.4, 0.05);
        Sounds.play(level, caster.blockPosition(), Sounds.GRASS_PLACE, SoundSource.PLAYERS, 1.2F, 0.4F);
        caster.displayClientMessage(Component.translatable("message.vengefulwoods.spore_cloud")
                .withStyle(ChatFormatting.LIGHT_PURPLE), true);
        return true;
    }

    private static final Map<UUID, Long> CLOUDED = new HashMap<>();

    /** Players who have switched the field off. It is theirs to carry or not. */
    private static final java.util.Set<UUID> SHIMMER_OFF = new java.util.HashSet<>();

    static boolean isOff(ServerPlayer player) {
        return SHIMMER_OFF.contains(player.getUUID());
    }

    /** Switches the field on or off and says which it now is. */
    static void toggleShimmer(ServerPlayer player) {
        if (!Skills.has(player, Skill.SHIMMER)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.shimmer_unknown")
                    .withStyle(ChatFormatting.GRAY), true);
            return;
        }
        boolean nowOff = SHIMMER_OFF.add(player.getUUID());
        if (!nowOff) {
            SHIMMER_OFF.remove(player.getUUID());
        }
        player.displayClientMessage(Component.translatable(nowOff
                        ? "message.vengefulwoods.shimmer_off" : "message.vengefulwoods.shimmer_on")
                .withStyle(ChatFormatting.LIGHT_PURPLE), true);
    }

    static boolean canSummon(ServerPlayer player) {
        return player.getServer() != null
                && WrathData.global(player.getServer()).own(player.getUUID()).classProgress > 0;
    }

    static void unlockSummon(ServerPlayer player) {
        if (player.getServer() == null) {
            return;
        }
        WrathData global = WrathData.global(player.getServer());
        global.setClassProgress(player.getUUID(),
                global.own(player.getUUID()).classProgress + 1);
    }

    /**
     * Calls one up where the player is standing, with no altar involved.
     * <p>
     * Needs the Call, which is the last thing in the tree. Still costs tribute at the first rank - it is a
     * shortcut, not a gift - and gets cheaper as the rank climbs, until at the top it costs nothing at all
     * because by then the thing is doing it by itself anyway.
     */
    static boolean summonHere(ServerLevel level, ServerPlayer player) {
        int rank = Skills.rank(player, Skill.THE_CALL);
        if (WoodsClass.of(player) != WoodsClass.MUSHROOM || rank <= 0) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_refused")
                    .withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        WrathData global = WrathData.global(level.getServer());
        int cost = Math.max(0, Config.MUSHROOM_ORIGINAL_COST.get() / (2 * rank));
        if (cost > 0 && !global.spendTribute(player.getUUID(), cost)) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_tribute",
                    cost, global.account(player.getUUID()).tribute).withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        return raiseOriginal(level, player.blockPosition().below(), player);
    }

    /**
     * Brings the nearest Original to you.
     * <p>
     * It does not walk. The old one is simply no longer where it was - the blocks go, and it stands up
     * again around you, which from the outside looks like the thing deciding to be somewhere else.
     */
    static boolean moveHere(ServerLevel level, ServerPlayer player) {
        if (Skills.rank(player, Skill.THE_CALL) < 2) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.rite_refused")
                    .withStyle(ChatFormatting.DARK_RED), true);
            return false;
        }
        Grove grove = grove(level);
        BlockPos nearest = null;
        double best = Double.MAX_VALUE;
        for (BlockPos original : grove.originals) {
            double distance = original.distSqr(player.blockPosition());
            if (distance < best) {
                best = distance;
                nearest = original;
            }
        }
        if (nearest == null) {
            player.displayClientMessage(Component.translatable("message.vengefulwoods.no_original")
                    .withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        unmake(level, nearest);
        grove.originals.remove(nearest);
        return raiseOriginal(level, player.blockPosition().below(), player);
    }

    /** Takes one down again, block by block, so moving it does not leave a tower behind. */
    private static void unmake(ServerLevel level, BlockPos base) {
        int height = Config.ORIGINAL_HEIGHT.get() + 8;
        int radius = Config.ORIGINAL_CAP.get() + 2;
        for (BlockPos pos : BlockPos.betweenClosed(base.offset(-radius, -2, -radius),
                base.offset(radius, height, radius))) {
            if (!level.isLoaded(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (state.is(Blocks.MUSHROOM_STEM) || state.is(Blocks.RED_MUSHROOM_BLOCK)
                    || state.is(Blocks.BROWN_MUSHROOM_BLOCK) || state.is(VengefulWoods.EYE.get())) {
                level.setBlock(pos.immutable(), Blocks.AIR.defaultBlockState(), 2);
            }
        }
        level.sendParticles(ParticleTypes.PORTAL, base.getX() + 0.5, base.getY() + 20.0, base.getZ() + 0.5,
                300, 6.0, 20.0, 6.0, 0.5);
    }

    /**
     * At the top rank it stops needing you. Every so often an Original puts up another one out at the edge
     * of its own reach, and then that one does the same.
     */
    private static void propagate(ServerLevel level, Grove grove, List<ServerPlayer> players, long now) {
        ServerPlayer caller = null;
        for (ServerPlayer player : players) {
            if (Skills.rank(player, Skill.THE_CALL) >= 3) {
                caller = player;
                break;
            }
        }
        if (caller == null || grove.originals.isEmpty()
                || grove.originals.size() >= Config.ORIGINAL_LIMIT.get()) {
            return;
        }
        RandomSource random = level.random;
        BlockPos parent = grove.originals.get(random.nextInt(grove.originals.size()));
        double angle = random.nextDouble() * Math.PI * 2.0;
        double away = Config.MUSHROOM_HAZE_RANGE.get() * (1.2 + random.nextDouble() * 0.8);
        BlockPos spot = new BlockPos((int) (parent.getX() + Math.cos(angle) * away), parent.getY(),
                (int) (parent.getZ() + Math.sin(angle) * away));
        BlockPos ground = topOpen(level, spot);
        if (ground == null) {
            return;
        }
        raiseOriginal(level, ground.below(), caller);
    }

    /** True where an Original is close enough to be doing something to you. */

    /** True where an Original is close enough to be doing something to you. */
    static boolean underOriginal(ServerLevel level, BlockPos pos) {
        Grove grove = GROVES.get(level.dimension());
        if (grove == null) {
            return false;
        }
        double range = hazeRange(level);
        for (BlockPos original : grove.originals) {
            if (original.distSqr(pos) <= range * range) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------------------------------------------------
    // The bad trip
    // ------------------------------------------------------------------------------------------------------------

    /**
     * What it is like to be near the thing when it does not know you.
     * <p>
     * No damage. The ground stops being reliable instead: you are turned around, the way you came is not
     * where you left it, and every few seconds something that is definitely a surface is definitely looking
     * at you. Monsters simply stop working.
     */
    private static void haze(ServerLevel level, Grove grove, List<ServerPlayer> players, long now) {
        double range = hazeRange(level);
        RandomSource random = level.random;

        for (BlockPos original : grove.originals) {
            // Eyes open and shut all over it, whoever is watching.
            level.sendParticles(ParticleTypes.PORTAL, original.getX() + 0.5, original.getY() + 12.0,
                    original.getZ() + 0.5, 40, 4.0, 10.0, 4.0, 0.25);

            for (ServerPlayer player : players) {
                if (player.blockPosition().distSqr(original) > range * range) {
                    continue;
                }
                if (WoodsClass.of(player) == WoodsClass.MUSHROOM || player.isCreative() || player.isSpectator()) {
                    continue; // It knows its own.
                }
                player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 220, 0, true, false, false));
                if (random.nextInt(3) == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 70, 0, true, false, false));
                }
                if (random.nextInt(4) == 0) {
                    player.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 100, 0, true, false, false));
                }
                // Turned around: a few blocks sideways, facing somewhere else. The maze is not in the walls.
                if (random.nextInt(5) == 0) {
                    loop(level, player, original, random);
                }
            }

            // Anything hostile inside the haze stops being able to do anything at all.
            for (Monster monster : level.getEntitiesOfClass(Monster.class,
                    new net.minecraft.world.phys.AABB(original).inflate(range))) {
                monster.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 120, 4, true, false, false));
                monster.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 120, 2, true, false, false));
                monster.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 160, 0, true, false, false));
                if (random.nextInt(6) == 0) {
                    monster.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 120, 0, true, false, false));
                }
            }
        }
    }

    /**
     * Puts somebody back where they were a moment ago, facing the wrong way. Done often enough, a person
     * walking in a straight line arrives where they started, which is the whole trick of the place.
     */
    private static void loop(ServerLevel level, ServerPlayer player, BlockPos original, RandomSource random) {
        double angle = random.nextDouble() * Math.PI * 2.0;
        double distance = 4.0 + random.nextDouble() * 8.0;
        double x = original.getX() + 0.5 + Math.cos(angle) * distance;
        double z = original.getZ() + 0.5 + Math.sin(angle) * distance;
        BlockPos ground = topOpen(level, new BlockPos((int) x, player.blockPosition().getY(), (int) z));
        if (ground == null) {
            return;
        }
        level.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1.0, player.getZ(),
                40, 0.4, 1.0, 0.4, 0.6);
        player.teleportTo(level, ground.getX() + 0.5, ground.getY(), ground.getZ() + 0.5,
                random.nextFloat() * 360.0F, 0.0F);
        level.sendParticles(ParticleTypes.PORTAL, ground.getX() + 0.5, ground.getY() + 1.0, ground.getZ() + 0.5,
                40, 0.4, 1.0, 0.4, 0.6);
        Sounds.play(level, ground, Sounds.ROOTS_BREAK, SoundSource.HOSTILE, 0.7F, 0.4F);
    }

    /** The first standable spot near a column, searching up and then down. */
    private static BlockPos topOpen(ServerLevel level, BlockPos around) {
        for (int dy = 0; dy <= 12; dy++) {
            for (int sign = 1; sign >= -1; sign -= 2) {
                BlockPos pos = around.above(dy * sign);
                if (!level.isLoaded(pos)) {
                    continue;
                }
                if (level.getBlockState(pos).isAir() && level.getBlockState(pos.above()).isAir()
                        && !level.getBlockState(pos.below()).isAir()) {
                    return pos.immutable();
                }
            }
        }
        return null;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Harvesting it
    // ------------------------------------------------------------------------------------------------------------

    /** An eye that is pulled out of the Original does not take it well. */
    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        if (!(event.getLevel() instanceof ServerLevel level) || !event.getState().is(VengefulWoods.EYE.get())) {
            return;
        }
        Player player = event.getPlayer();
        if (player == null || player.isCreative() || WoodsClass.of(player) == WoodsClass.MUSHROOM) {
            return;
        }
        player.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 400, 0, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 120, 0, true, false, false));
        level.sendParticles(ParticleTypes.PORTAL, event.getPos().getX() + 0.5, event.getPos().getY() + 0.5,
                event.getPos().getZ() + 0.5, 30, 0.3, 0.3, 0.3, 0.4);
    }
}
