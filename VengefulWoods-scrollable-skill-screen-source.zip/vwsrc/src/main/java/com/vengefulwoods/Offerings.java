package com.vengefulwoods;

import com.ferreusveritas.dynamictrees.api.TreeHelper;
import com.ferreusveritas.dynamictrees.block.DynamicSaplingBlock;
import com.ferreusveritas.dynamictrees.block.rooty.RootyBlock;
import com.ferreusveritas.dynamictrees.tree.species.Species;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Fertilizer, favour, and everything the forest does once it likes you:
 * leaving gifts, pulling leaves out of your way, and keeping its saplings off your doorstep.
 */
public class Offerings {

    private static final Map<UUID, Long> NEXT_GIFT = new HashMap<>();

    public static void clear() {
        NEXT_GIFT.clear();
    }

    // ------------------------------------------------------------------------------------------------------------
    // Giving fertilizer to a tree
    // ------------------------------------------------------------------------------------------------------------

    @SubscribeEvent
    public void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Level level = event.getLevel();
        if (level.isClientSide() || !(level instanceof ServerLevel serverLevel)) {
            return;
        }
        ItemStack stack = event.getItemStack();
        if (!stack.is(VengefulWoods.FERTILIZER.get())) {
            return;
        }
        BlockPos pos = event.getPos();
        if (!isTree(serverLevel, pos)) {
            return;
        }
        Player player = event.getEntity();
        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.SUCCESS);

        try {
            offer(serverLevel, pos, player, event.getHand(), stack);
        } catch (RuntimeException e) {
            VengefulWoods.LOGGER.error("Vengeful Woods failed to accept an offering", e);
        }
    }

    private static boolean isTree(ServerLevel level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        return TreeHelper.isTreePart(state) || state.getBlock() instanceof DynamicSaplingBlock;
    }

    private static void offer(ServerLevel level, BlockPos pos, Player player, InteractionHand hand, ItemStack stack) {
        MinecraftServer server = level.getServer();
        WrathData global = WrathData.global(server);
        UUID id = player.getUUID();
        Stage before = global.account(id).stage();
        Boon boonBefore = global.account(id).boon();

        global.addOffering(id);

        Stage after = global.account(id).stage();
        Boon boonAfter = global.account(id).boon();

        if (!player.isCreative()) {
            stack.shrink(1);
        }

        // The tree takes it in: full soil, and a little life back.
        BlockPos rootPos = TreeHelper.findRootNode(level, pos);
        if (rootPos != null && !rootPos.equals(BlockPos.ZERO)) {
            BlockState rootState = level.getBlockState(rootPos);
            RootyBlock rooty = TreeHelper.getRooty(rootState);
            if (rooty != null) {
                rooty.setFertility(level, rootPos, 15);
            }
        }

        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5,
                12, 0.4, 0.4, 0.4, 0.02);
        Sounds.play(level, pos, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 0.8F, 1.2F);

        if (after != before) {
            SpeciesTuner.apply(WrathData.worstStage(server));
        }

        Component message;
        if (boonAfter != boonBefore && boonAfter != Boon.NONE) {
            // The forest's feelings are about this one person, so only they are told.
            player.displayClientMessage(Component.translatable("message.vengefulwoods.boon." + boonAfter.ordinal())
                    .withStyle(ChatFormatting.GREEN, ChatFormatting.ITALIC), false);
            return;
        }
        if (after != before) {
            message = Component.translatable("message.vengefulwoods.calmed", after.ordinal())
                    .withStyle(ChatFormatting.GREEN);
        } else {
            message = Component.translatable("message.vengefulwoods.accepted")
                    .withStyle(ChatFormatting.DARK_GREEN);
        }
        player.displayClientMessage(message, true);
    }

    // ------------------------------------------------------------------------------------------------------------
    // What the forest does for friends
    // ------------------------------------------------------------------------------------------------------------

    static void tick(ServerLevel level, ForestDirector.LevelState st, List<ServerPlayer> players, long now) {
        if (now % 10L != 0L) {
            return;
        }
        for (ServerPlayer player : players) {
            // Every player stands on their own with the forest.
            Boon boon = WrathData.boonOf(level.getServer(), player.getUUID());
            if (boon == Boon.NONE) {
                continue;
            }
            if (boon.atLeast(Boon.ALLIED) && Config.CLEAR_PATHS.get()) {
                clearPath(level, player);
            }
            if (boon.weedsForYou() && now % 40L == 0L) {
                // A warden forest pulls the weeds up around its own people.
                Invasives.wardenSweep(level, player);
            }
            if (boon.blesses() && now % 80L == 0L) {
                blessing(level, player);
            }
            if (now % 100L == 0L) {
                maybeGift(level, st, player, boon, now);
            }
        }
    }

    /**
     * Heartbound: standing under the canopy of a forest that loves you does you good. It only holds while
     * there are leaves over your head - step into the open and you are on your own again.
     */
    private static void blessing(ServerLevel level, ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        BlockPos pos = player.blockPosition();
        boolean covered = false;
        for (int dy = 1; dy <= 12 && !covered; dy++) {
            BlockPos above = pos.above(dy);
            if (!level.isLoaded(above)) {
                break;
            }
            BlockState state = level.getBlockState(above);
            covered = TreeHelper.isLeaves(state) || state.is(BlockTags.LEAVES) || TreeHelper.isBranch(state);
        }
        if (!covered) {
            return;
        }
        player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, 0, true, false, false));
        player.addEffect(new MobEffectInstance(MobEffects.DIG_SPEED, 100, 0, true, false, false));
    }

    /** Leaves get out of an ally's way instead of slowing them down. */
    private static void clearPath(ServerLevel level, ServerPlayer player) {
        if (player.isSpectator()) {
            return;
        }
        BlockPos feet = player.blockPosition();
        Direction facing = player.getDirection();
        for (int step = 0; step <= 2; step++) {
            BlockPos ahead = feet.relative(facing, step);
            for (int dy = 0; dy <= 1; dy++) {
                BlockPos pos = ahead.above(dy);
                if (!level.isLoaded(pos)) {
                    return;
                }
                BlockState state = level.getBlockState(pos);
                if (TreeHelper.isLeaves(state)) {
                    level.removeBlock(pos, false);
                    level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                            3, 0.3, 0.3, 0.3, 0.0);
                }
            }
        }
    }

    /** Every few minutes a nearby tree leaves something for a player it likes. */
    private static void maybeGift(ServerLevel level, ForestDirector.LevelState st, ServerPlayer player, Boon boon, long now) {
        if (player.isSpectator() || player.isCreative()) {
            return;
        }
        long interval = giftInterval(boon);
        Long next = NEXT_GIFT.get(player.getUUID());
        if (next == null) {
            // Spread the first gifts out so everyone is not given something at the same moment.
            NEXT_GIFT.put(player.getUUID(), now + level.random.nextInt((int) Math.max(20L, interval)) + 600L);
            return;
        }
        if (now < next) {
            return;
        }

        BlockPos treePos = nearestTree(st, player.blockPosition(), 16.0);
        if (treePos == null) {
            return; // No tree close enough to give anything.
        }
        NEXT_GIFT.put(player.getUUID(), now + interval);

        ItemStack gift = pickGift(level, treePos, boon, level.random);
        if (gift == null || gift.isEmpty()) {
            return;
        }
        BlockPos dropPos = giftSpot(level, treePos);
        Block.popResource(level, dropPos, gift);
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, dropPos.getX() + 0.5, dropPos.getY() + 0.5, dropPos.getZ() + 0.5,
                10, 0.4, 0.4, 0.4, 0.02);
        Sounds.play(level, dropPos, Sounds.GRASS_PLACE, SoundSource.BLOCKS, 0.7F, 1.4F);
        player.displayClientMessage(Component.translatable("message.vengefulwoods.gift")
                .withStyle(ChatFormatting.DARK_GREEN), true);
    }

    /** Open ground beside the trunk, so the gift is not spat out of a solid block. */
    private static BlockPos giftSpot(ServerLevel level, BlockPos rootPos) {
        for (Direction side : Direction.Plane.HORIZONTAL) {
            BlockPos pos = rootPos.above().relative(side);
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.canBeReplaced()) {
                return pos;
            }
        }
        return rootPos.above(2);
    }

    /** The better they think of you, the less time passes between gifts. */
    private static long giftInterval(Boon boon) {
        long base = Config.GIFT_MINUTES.get() * 1200L;
        switch (boon) {
            case GUARDIAN:
                return Math.max(200L, base / 4L);
            case ALLIED:
                return Math.max(200L, base / 2L);
            default:
                return base;
        }
    }

    @Nullable
    private static ItemStack pickGift(ServerLevel level, BlockPos rootPos, Boon boon, RandomSource random) {
        // A seed of whatever species gave the gift, when we can work it out.
        BlockState rootState = level.getBlockState(rootPos);
        RootyBlock rooty = TreeHelper.getRooty(rootState);
        Species species = rooty == null ? null : rooty.getSpecies(rootState, level, rootPos);

        int roll = random.nextInt(boon.atLeast(Boon.GUARDIAN) ? 14 : (boon.atLeast(Boon.ALLIED) ? 12 : 10));
        switch (roll) {
            case 0:
            case 1:
            case 2:
                return new ItemStack(Items.STICK, 2 + random.nextInt(4));
            case 3:
            case 4:
                return new ItemStack(Items.APPLE, 1 + random.nextInt(2));
            case 5:
                return new ItemStack(Items.BONE_MEAL, 2 + random.nextInt(3));
            case 10:
                return new ItemStack(VengefulWoods.FERTILIZER.get(), 1 + random.nextInt(2));
            case 11:
                // Heartwood: the only way to get it, and what the forest's own gear is made of.
                return new ItemStack(VengefulWoods.HEARTWOOD.get(), 1);
            case 12:
                return new ItemStack(VengefulWoods.HEARTWOOD.get(), 1 + random.nextInt(3));
            case 13:
                return new ItemStack(Items.GOLDEN_APPLE, 1);
            default:
                if (species != null && species.isValid() && species.hasSeed()) {
                    return species.getSeedStack(1 + random.nextInt(2));
                }
                return new ItemStack(Items.STICK, 2);
        }
    }

    @Nullable
    private static BlockPos nearestTree(ForestDirector.LevelState st, BlockPos from, double range) {
        BlockPos best = null;
        double bestDistSq = range * range;
        for (BlockPos rootPos : st.order) {
            double distSq = rootPos.distSqr(from);
            if (distSq < bestDistSq) {
                bestDistSq = distSq;
                best = rootPos;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------------------------------------------------
    // Keeping off your doorstep
    // ------------------------------------------------------------------------------------------------------------

    /**
     * True if there is something built within a few blocks: an allied forest will not plant here.
     * Checks every second block to keep it cheap.
     */
    static boolean nearBase(ServerLevel level, BlockPos pos) {
        final int radius = 4;
        for (int x = -radius; x <= radius; x += 2) {
            for (int z = -radius; z <= radius; z += 2) {
                for (int y = -2; y <= 3; y += 1) {
                    BlockPos check = pos.offset(x, y, z);
                    if (!level.isLoaded(check)) {
                        return true; // Do not plant blind.
                    }
                    if (isBuilt(level.getBlockState(check))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean isBuilt(BlockState state) {
        if (state.isAir() || state.canBeReplaced() || TreeHelper.isTreePart(state)
                || state.is(VengefulWoods.RHIZOME.get()) || state.getBlock() instanceof DynamicSaplingBlock) {
            return false;
        }
        // Torches, doors, chests, furnaces, beds, workstations: all things a player puts down.
        return state.is(VengefulWoods.LIGHT_TARGETS) || state.hasBlockEntity() || Rhizomes.isBuiltBlock(state);
    }
}
