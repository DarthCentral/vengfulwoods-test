package com.vengefulwoods;

import com.mojang.logging.LogUtils;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

/**
 * Vengeful Woods - a horror add-on for Dynamic Trees.
 * The more trees the players destroy, the harder the forest fights back.
 */
@Mod(VengefulWoods.MODID)
public class VengefulWoods {

    public static final String MODID = "vengefulwoods";
    public static final Logger LOGGER = LogUtils.getLogger();

    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MODID);

    /** The wooden block that rhizomes and tendrils are made of. */
    public static final RegistryObject<Block> RHIZOME = BLOCKS.register("rhizome", RhizomeBlock::new);
    public static final RegistryObject<Item> RHIZOME_ITEM =
            ITEMS.register("rhizome", () -> new BlockItem(RHIZOME.get(), new Item.Properties()));

    /**
     * The invasive weed, in three parts: the woody vine that branches like a tree limb, the leaf mats that
     * hang off it, and the runner that travels underground and surfaces where it likes.
     */
    public static final RegistryObject<Block> KUDZU = BLOCKS.register("kudzu", KudzuBlock.Vine::new);
    public static final RegistryObject<Item> KUDZU_ITEM =
            ITEMS.register("kudzu", () -> new BlockItem(KUDZU.get(), new Item.Properties()));
    public static final RegistryObject<Block> KUDZU_LEAVES = BLOCKS.register("kudzu_leaves", KudzuBlock.Leaves::new);
    public static final RegistryObject<Item> KUDZU_LEAVES_ITEM =
            ITEMS.register("kudzu_leaves", () -> new BlockItem(KUDZU_LEAVES.get(), new Item.Properties()));
    public static final RegistryObject<Block> KUDZU_ROOT = BLOCKS.register("kudzu_root", KudzuBlock.Runner::new);
    public static final RegistryObject<Item> KUDZU_ROOT_ITEM =
            ITEMS.register("kudzu_root", () -> new BlockItem(KUDZU_ROOT.get(), new Item.Properties()));

    /** Real weeds, with the habits they actually have. Every one of them is worth keeping, which is the trap. */
    public static final RegistryObject<Block> BLACKBERRY = BLOCKS.register("blackberry",
            () -> new InvasiveBlock(Invasive.BLACKBERRY, MapColor.COLOR_GREEN, 0.4F, SoundType.SWEET_BERRY_BUSH));
    public static final RegistryObject<Item> BLACKBERRY_ITEM =
            ITEMS.register("blackberry", () -> new BlockItem(BLACKBERRY.get(), new Item.Properties()));
    public static final RegistryObject<Block> KNOTWEED = BLOCKS.register("knotweed",
            () -> new InvasiveBlock(Invasive.KNOTWEED, MapColor.TERRACOTTA_GREEN, 0.6F, SoundType.VINE));
    public static final RegistryObject<Item> KNOTWEED_ITEM =
            ITEMS.register("knotweed", () -> new BlockItem(KNOTWEED.get(), new Item.Properties()));
    public static final RegistryObject<Block> CHEATGRASS = BLOCKS.register("cheatgrass",
            () -> new InvasiveBlock(Invasive.CHEATGRASS, MapColor.SAND, 0.3F, SoundType.GRASS));
    public static final RegistryObject<Item> CHEATGRASS_ITEM =
            ITEMS.register("cheatgrass", () -> new BlockItem(CHEATGRASS.get(), new Item.Properties()));
    public static final RegistryObject<Block> WATER_HYACINTH = BLOCKS.register("water_hyacinth",
            () -> new InvasiveBlock(Invasive.WATER_HYACINTH, MapColor.COLOR_PURPLE, 0.2F, SoundType.WET_GRASS));
    public static final RegistryObject<Item> WATER_HYACINTH_ITEM =
            ITEMS.register("water_hyacinth", () -> new BlockItem(WATER_HYACINTH.get(), new Item.Properties()));

    public static final RegistryObject<Block> WISTERIA = BLOCKS.register("wisteria",
            () -> new InvasiveBlock(Invasive.WISTERIA, MapColor.COLOR_PURPLE, 2.6F, SoundType.VINE));
    public static final RegistryObject<Item> WISTERIA_ITEM =
            ITEMS.register("wisteria", () -> new BlockItem(WISTERIA.get(), new Item.Properties()));
    /** The flowering curtain that hangs off the woody vine. Softer, and just as much a part of the plant. */
    public static final RegistryObject<Block> WISTERIA_BLOOM = BLOCKS.register("wisteria_bloom",
            () -> new InvasiveBlock(Invasive.WISTERIA, MapColor.COLOR_PURPLE, 0.4F, SoundType.VINE));
    public static final RegistryObject<Item> WISTERIA_BLOOM_ITEM =
            ITEMS.register("wisteria_bloom", () -> new BlockItem(WISTERIA_BLOOM.get(), new Item.Properties()));

    /** What they pay out, which is the whole reason anyone plants them. */
    public static final RegistryObject<Item> BLACKBERRIES = ITEMS.register("blackberries",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(3).saturationMod(0.3F).build())));
    public static final RegistryObject<Item> KNOTWEED_SHOOTS = ITEMS.register("knotweed_shoots",
            () -> new Item(new Item.Properties().food(new FoodProperties.Builder()
                    .nutrition(4).saturationMod(0.4F).build())));
    public static final RegistryObject<Item> DRY_THATCH =
            ITEMS.register("dry_thatch", () -> new FuelItem(2400));
    public static final RegistryObject<Item> HYACINTH_FIBRE =
            ITEMS.register("hyacinth_fibre", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> WISTERIA_BLOOMS =
            ITEMS.register("wisteria_blooms", () -> new Item(new Item.Properties()));

    /**
     * The plants that belong here. Picking them costs you a little of the forest's patience; putting them
     * back earns a little of it, and every one of them is worth having for its own sake.
     */
    public static final RegistryObject<Block> TRILLIUM = BLOCKS.register("trillium",
            () -> new NativePlantBlock(Native.TRILLIUM, MapColor.PLANT, 10));
    public static final RegistryObject<Item> TRILLIUM_BLOOM =
            ITEMS.register("trillium", () -> new BlockItem(TRILLIUM.get(), new Item.Properties()));

    public static final RegistryObject<Block> WILD_GINGER = BLOCKS.register("wild_ginger",
            () -> new NativePlantBlock(Native.WILD_GINGER, MapColor.PLANT, 6));
    public static final RegistryObject<Item> GINGER_ROOT =
            ITEMS.register("wild_ginger", () -> new BlockItem(WILD_GINGER.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(2).saturationMod(0.3F).build())));

    public static final RegistryObject<Block> FIDDLEHEAD = BLOCKS.register("fiddlehead_fern",
            () -> new NativePlantBlock(Native.FIDDLEHEAD, MapColor.PLANT, 13));
    /** Raw fiddleheads really will make you ill. Cook them. */
    public static final RegistryObject<Item> FIDDLEHEADS =
            ITEMS.register("fiddlehead_fern", () -> new BlockItem(FIDDLEHEAD.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(2).saturationMod(0.1F)
                            .effect(() -> new MobEffectInstance(MobEffects.CONFUSION, 160, 0), 0.8F).build())));
    public static final RegistryObject<Item> COOKED_FIDDLEHEADS =
            ITEMS.register("cooked_fiddleheads", () -> new Item(new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(6).saturationMod(0.6F).build())));

    public static final RegistryObject<Block> SWEETGRASS = BLOCKS.register("sweetgrass",
            () -> new NativePlantBlock(Native.SWEETGRASS, MapColor.PLANT, 14));
    public static final RegistryObject<Item> SWEETGRASS_BRAID =
            ITEMS.register("sweetgrass", () -> new FuelBlockItem(SWEETGRASS.get(), 600));

    public static final RegistryObject<Block> WINTERGREEN = BLOCKS.register("wintergreen",
            () -> new NativePlantBlock(Native.WINTERGREEN, MapColor.PLANT, 6));
    public static final RegistryObject<Item> WINTERGREEN_LEAVES =
            ITEMS.register("wintergreen", () -> new BlockItem(WINTERGREEN.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 120, 0), 1.0F).build())));

    /** Bramble below ground, and the arching cane above it. Both are the plant. */
    public static final RegistryObject<Block> BLACKBERRY_ROOT = BLOCKS.register("blackberry_root",
            () -> new InvasiveBlock(Invasive.BLACKBERRY, MapColor.COLOR_BROWN, 0.5F, SoundType.SWEET_BERRY_BUSH));
    public static final RegistryObject<Item> BLACKBERRY_ROOT_ITEM =
            ITEMS.register("blackberry_root", () -> new BlockItem(BLACKBERRY_ROOT.get(), new Item.Properties()));
    public static final RegistryObject<Block> BLACKBERRY_CANE = BLOCKS.register("blackberry_cane",
            () -> new InvasiveBlock(Invasive.BLACKBERRY, MapColor.PLANT, 0.3F, SoundType.SWEET_BERRY_BUSH));
    public static final RegistryObject<Item> BLACKBERRY_CANE_ITEM =
            ITEMS.register("blackberry_cane", () -> new BlockItem(BLACKBERRY_CANE.get(), new Item.Properties()));

    /** Knotweed's rhizome, which is the part that actually matters, and the cane it throws up. */
    public static final RegistryObject<Block> KNOTWEED_ROOT = BLOCKS.register("knotweed_root",
            () -> new InvasiveBlock(Invasive.KNOTWEED, MapColor.COLOR_BROWN, 0.6F, SoundType.WOOD));
    public static final RegistryObject<Item> KNOTWEED_ROOT_ITEM =
            ITEMS.register("knotweed_root", () -> new BlockItem(KNOTWEED_ROOT.get(), new Item.Properties()));
    public static final RegistryObject<Block> KNOTWEED_STEM = BLOCKS.register("knotweed_stem",
            () -> new InvasiveBlock(Invasive.KNOTWEED, MapColor.PLANT, 0.3F, SoundType.WOOD));
    public static final RegistryObject<Item> KNOTWEED_STEM_ITEM =
            ITEMS.register("knotweed_stem", () -> new BlockItem(KNOTWEED_STEM.get(), new Item.Properties()));

    /** An eye of the Original. It is a block. It is looking at you. */
    public static final RegistryObject<Block> EYE = BLOCKS.register("watching_eye",
            () -> new EyeBlock());
    public static final RegistryObject<Item> EYE_ITEM =
            ITEMS.register("watching_eye", () -> new BlockItem(EYE.get(), new Item.Properties()));
    /** Paid to the altar to raise the Original. Found only by whoever already knows what it is for. */
    public static final RegistryObject<Item> SPORE_IDOL =
            ITEMS.register("spore_idol", () -> new Item(new Item.Properties().stacksTo(1)));


    /** Cattail. The root is food; the head, dried, is the best tinder growing anywhere. */
    public static final RegistryObject<Block> CATTAIL = BLOCKS.register("cattail",
            () -> new NativePlantBlock(Native.CATTAIL, MapColor.PLANT, 16));
    public static final RegistryObject<Item> CATTAIL_ITEM =
            ITEMS.register("cattail", () -> new FuelBlockItem(CATTAIL.get(), 500));

    /** Sea buckthorn. Sour, orange, and worth more than anything else growing on a shore. */
    public static final RegistryObject<Block> SEA_BUCKTHORN = BLOCKS.register("sea_buckthorn",
            () -> new NativePlantBlock(Native.SEA_BUCKTHORN, MapColor.COLOR_ORANGE, 13));
    public static final RegistryObject<Item> SEA_BUCKTHORN_ITEM =
            ITEMS.register("sea_buckthorn", () -> new BlockItem(SEA_BUCKTHORN.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(4).saturationMod(0.5F)
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 80, 0), 0.6F).build())));

    /** Prickly pear. Both halves of it are worth having and both punish haste. */
    public static final RegistryObject<Block> PRICKLY_PEAR = BLOCKS.register("prickly_pear",
            () -> new NativePlantBlock(Native.PRICKLY_PEAR, MapColor.PLANT, 14));
    public static final RegistryObject<Item> PRICKLY_PEAR_ITEM =
            ITEMS.register("prickly_pear", () -> new BlockItem(PRICKLY_PEAR.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(3).saturationMod(0.4F).build())));

    /** Wild bergamot. Bee balm: a dye out of the heads, and a tea that settles you. */
    public static final RegistryObject<Block> BERGAMOT = BLOCKS.register("wild_bergamot",
            () -> new NativePlantBlock(Native.BERGAMOT, MapColor.COLOR_PINK, 12));
    public static final RegistryObject<Item> BERGAMOT_ITEM =
            ITEMS.register("wild_bergamot", () -> new BlockItem(BERGAMOT.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(1).saturationMod(0.1F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 300, 0), 1.0F)
                            .build())));

    /** Ramps. Three weeks in spring, and dug out of whole valleys wherever anybody finds them. */
    public static final RegistryObject<Block> RAMPS = BLOCKS.register("ramps",
            () -> new NativePlantBlock(Native.RAMPS, MapColor.PLANT, 11));
    public static final RegistryObject<Item> RAMPS_ITEM =
            ITEMS.register("ramps", () -> new BlockItem(RAMPS.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(3).saturationMod(0.6F).build())));

    /** Alpine bistort. It carries its own young on the stem, because nothing up there gets a second go. */
    public static final RegistryObject<Block> BISTORT = BLOCKS.register("alpine_bistort",
            () -> new NativePlantBlock(Native.BISTORT, MapColor.PLANT, 12));
    public static final RegistryObject<Item> BISTORT_ITEM =
            ITEMS.register("alpine_bistort", () -> new BlockItem(BISTORT.get(), new Item.Properties()
                    .food(new FoodProperties.Builder().nutrition(4).saturationMod(0.7F).build())));

    /** The stone of the rites. */
    public static final RegistryObject<Block> ALTAR = BLOCKS.register("verdant_altar", AltarBlock::new);
    public static final DeferredRegister<net.minecraft.world.level.block.entity.BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MODID);
    public static final RegistryObject<net.minecraft.world.level.block.entity.BlockEntityType<AltarBlockEntity>>
            ALTAR_BLOCK_ENTITY = BLOCK_ENTITIES.register("verdant_altar",
            () -> net.minecraft.world.level.block.entity.BlockEntityType.Builder
                    .of(AltarBlockEntity::new, ALTAR.get()).build(null));
    public static final RegistryObject<Item> ALTAR_ITEM =
            ITEMS.register("verdant_altar", () -> new BlockItem(ALTAR.get(), new Item.Properties()));

    /** Materials. Heartwood is given, never taken; fibre is what is left when you beat the weed. */
    public static final RegistryObject<Item> HEARTWOOD =
            ITEMS.register("heartwood", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> KUDZU_FIBRE =
            ITEMS.register("kudzu_fibre", () -> new Item(new Item.Properties()));

    /** Charms, each spent on its own rite. */
    public static final RegistryObject<Item> GROVE_CHARM =
            ITEMS.register("grove_charm", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> ROOT_TOTEM =
            ITEMS.register("root_totem", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BARGAIN_IDOL =
            ITEMS.register("bargain_idol", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BLIGHT_SEED =
            ITEMS.register("blight_seed", () -> new Item(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SEEDBED_CHARM =
            ITEMS.register("seedbed_charm", () -> new Item(new Item.Properties().stacksTo(16)));

    /** Gear grown rather than forged. */
    public static final RegistryObject<Item> HEARTWOOD_SWORD =
            ITEMS.register("heartwood_sword", () -> new SwordItem(WoodsGear.HEARTWOOD_TIER, 5, -2.2F,
                    new Item.Properties()));
    public static final RegistryObject<Item> HEARTWOOD_AXE =
            ITEMS.register("heartwood_axe", () -> new AxeItem(WoodsGear.HEARTWOOD_TIER, 7.0F, -3.0F,
                    new Item.Properties()));
    public static final RegistryObject<Item> BRUSH_HOOK =
            ITEMS.register("brush_hook", BrushHookItem::new);

    /** One tool for each weed a brush hook cannot really deal with. */
    public static final RegistryObject<Item> HEARTWOOD_LOPPER = ITEMS.register("heartwood_lopper",
            () -> new WeedToolItem(WeedToolItem.Kind.LOPPER, 5, 820));
    public static final RegistryObject<Item> GRUBBING_MATTOCK = ITEMS.register("grubbing_mattock",
            () -> new WeedToolItem(WeedToolItem.Kind.MATTOCK, 4, 640));
    public static final RegistryObject<Item> HEDGE_SLASHER = ITEMS.register("hedge_slasher",
            () -> new WeedToolItem(WeedToolItem.Kind.SLASHER, 3, 560));
    public static final RegistryObject<Item> HEARTWOOD_HELMET = ITEMS.register("heartwood_helmet",
            () -> new ArmorItem(WoodsGear.HEARTWOOD, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> HEARTWOOD_CHESTPLATE = ITEMS.register("heartwood_chestplate",
            () -> new ArmorItem(WoodsGear.HEARTWOOD, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> HEARTWOOD_LEGGINGS = ITEMS.register("heartwood_leggings",
            () -> new ArmorItem(WoodsGear.HEARTWOOD, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> HEARTWOOD_BOOTS = ITEMS.register("heartwood_boots",
            () -> new ArmorItem(WoodsGear.HEARTWOOD, ArmorItem.Type.BOOTS, new Item.Properties()));

    /** Woven gear: weed cord, wisteria withy, and just enough iron to hold it together. */
    public static final RegistryObject<Item> WOVEN_HELMET = ITEMS.register("woven_helmet",
            () -> new ArmorItem(WoodsGear.WOVEN, ArmorItem.Type.HELMET, new Item.Properties()));
    public static final RegistryObject<Item> WOVEN_CHESTPLATE = ITEMS.register("woven_chestplate",
            () -> new ArmorItem(WoodsGear.WOVEN, ArmorItem.Type.CHESTPLATE, new Item.Properties()));
    public static final RegistryObject<Item> WOVEN_LEGGINGS = ITEMS.register("woven_leggings",
            () -> new ArmorItem(WoodsGear.WOVEN, ArmorItem.Type.LEGGINGS, new Item.Properties()));
    public static final RegistryObject<Item> WOVEN_BOOTS = ITEMS.register("woven_boots",
            () -> new ArmorItem(WoodsGear.WOVEN, ArmorItem.Type.BOOTS, new Item.Properties()));

    /** Given to a tree to take the edge off the forest's anger. */
    public static final RegistryObject<Item> FERTILIZER =
            ITEMS.register("fertilizer", () -> new Item(new Item.Properties()));

    /** Everything the mod adds, in the order it makes sense to meet it in. */
    private static final java.util.List<RegistryObject<Item>> TAB_ORDER = java.util.List.of(
            // What the forest grows, and what grows on it
            TRILLIUM_BLOOM, GINGER_ROOT, FIDDLEHEADS, SWEETGRASS_BRAID, WINTERGREEN_LEAVES,
            CATTAIL_ITEM, SEA_BUCKTHORN_ITEM, PRICKLY_PEAR_ITEM, BERGAMOT_ITEM, RAMPS_ITEM, BISTORT_ITEM,
            COOKED_FIDDLEHEADS,
            // The weeds
            KUDZU_ITEM, KUDZU_LEAVES_ITEM, KUDZU_ROOT_ITEM, BLACKBERRY_ITEM, KNOTWEED_ITEM, CHEATGRASS_ITEM,
            WATER_HYACINTH_ITEM, WISTERIA_ITEM, WISTERIA_BLOOM_ITEM,
            BLACKBERRY_ROOT_ITEM, BLACKBERRY_CANE_ITEM, KNOTWEED_ROOT_ITEM, KNOTWEED_STEM_ITEM,
            // What they pay out
            BLACKBERRIES, KNOTWEED_SHOOTS, DRY_THATCH, HYACINTH_FIBRE, WISTERIA_BLOOMS, KUDZU_FIBRE,
            // The forest's own
            RHIZOME_ITEM, HEARTWOOD, FERTILIZER,
            // Altar and rites
            ALTAR_ITEM, GROVE_CHARM, ROOT_TOTEM, BARGAIN_IDOL, SEEDBED_CHARM, BLIGHT_SEED, SPORE_IDOL,
            EYE_ITEM,
            // Gear
            BRUSH_HOOK, HEARTWOOD_LOPPER, GRUBBING_MATTOCK, HEDGE_SLASHER,
            HEARTWOOD_SWORD, HEARTWOOD_AXE,
            HEARTWOOD_HELMET, HEARTWOOD_CHESTPLATE, HEARTWOOD_LEGGINGS, HEARTWOOD_BOOTS,
            WOVEN_HELMET, WOVEN_CHESTPLATE, WOVEN_LEGGINGS, WOVEN_BOOTS);

    /** One tab with all of it in, rather than scattering the mod through the vanilla ones. */
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MODID);
    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("vengeful_woods",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.vengefulwoods"))
                    .icon(() -> new ItemStack(HEARTWOOD.get()))
                    .withLabelColor(0x2E5B2E)
                    .displayItems((params, output) -> {
                        for (RegistryObject<Item> item : TAB_ORDER) {
                            output.accept(new ItemStack(item.get()));
                        }
                    })
                    .build());

    /** The altar's own window. */
    public static final DeferredRegister<net.minecraft.world.inventory.MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, MODID);
    public static final RegistryObject<net.minecraft.world.inventory.MenuType<AltarMenu>> ALTAR_MENU =
            MENUS.register("altar", () -> net.minecraftforge.common.extensions.IForgeMenuType.create(AltarMenu::new));

    public static final RegistryObject<net.minecraft.world.inventory.MenuType<SkillMenu>> SKILL_MENU =
            MENUS.register("skills", () -> net.minecraftforge.common.extensions.IForgeMenuType.create(SkillMenu::new));

    /** The Original's own noise. */
    public static final DeferredRegister<net.minecraft.sounds.SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, MODID);
    public static final RegistryObject<net.minecraft.sounds.SoundEvent> ORIGINAL_DRONE =
            SOUNDS.register("original.drone", () -> net.minecraft.sounds.SoundEvent
                    .createVariableRangeEvent(new ResourceLocation(MODID, "original.drone")));
    public static final RegistryObject<net.minecraft.sounds.SoundEvent> EYE_STARE =
            SOUNDS.register("eye.stare", () -> net.minecraft.sounds.SoundEvent
                    .createVariableRangeEvent(new ResourceLocation(MODID, "eye.stare")));

    /** Blocks the forest treats as "torches" to hunt down (editable with a datapack). */
    public static final TagKey<Block> LIGHT_TARGETS = BlockTags.create(new ResourceLocation(MODID, "light_targets"));
    /** Blocks rhizomes and tendrils can never break (editable with a datapack). */
    public static final TagKey<Block> RHIZOME_IMMUNE = BlockTags.create(new ResourceLocation(MODID, "rhizome_immune"));

    public VengefulWoods() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        BLOCK_ENTITIES.register(modBus);
        SOUNDS.register(modBus);
        MENUS.register(modBus);
        TABS.register(modBus);

        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, Config.SPEC);
        WoodsNetwork.register();

        MinecraftForge.EVENT_BUS.register(new FellingTracker());
        MinecraftForge.EVENT_BUS.register(new ForestDirector());
        MinecraftForge.EVENT_BUS.register(new Offerings());
        MinecraftForge.EVENT_BUS.register(new Kudzu());
        MinecraftForge.EVENT_BUS.register(new Rituals());
        MinecraftForge.EVENT_BUS.register(new Invasives());
        MinecraftForge.EVENT_BUS.register(new Natives());
        MinecraftForge.EVENT_BUS.register(new ClassChoice());
        MinecraftForge.EVENT_BUS.register(new Invader());
        MinecraftForge.EVENT_BUS.register(new Classes());
        MinecraftForge.EVENT_BUS.register(new Mushroom());
        MinecraftForge.EVENT_BUS.register(new RitualBook());
        MinecraftForge.EVENT_BUS.register(new GreenHand());
        MinecraftForge.EVENT_BUS.addListener(this::onRegisterCommands);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStarted);
        MinecraftForge.EVENT_BUS.addListener(this::onServerStopped);
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        WoodsCommand.register(event.getDispatcher());
    }

    private void onServerStarted(ServerStartedEvent event) {
        FellingTracker.clear();
        ForestDirector.clear();
        Offerings.clear();
        Treefall.clear();
        Kudzu.clear();
        Invasives.clear();
        Natives.clear();
        Biomass.clear();
        ClassChoice.clear();
        Classes.clear();
        Invader.clear();
        Mushroom.clear();
        GreenHand.clear();
        SpeciesTuner.reset();
        SpeciesTuner.apply(WrathData.worstStage(event.getServer()));
    }

    private void onServerStopped(ServerStoppedEvent event) {
        // Put every tree species back the way Dynamic Trees had it, so the next world starts clean.
        SpeciesTuner.reset();
        FellingTracker.clear();
        ForestDirector.clear();
        Offerings.clear();
        Treefall.clear();
        Kudzu.clear();
        Invasives.clear();
        Natives.clear();
        Biomass.clear();
        ClassChoice.clear();
        Classes.clear();
        Invader.clear();
        Mushroom.clear();
        GreenHand.clear();
    }
}
