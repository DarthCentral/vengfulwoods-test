package com.vengefulwoods;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Map;
import java.util.UUID;

/**
 * /vengefulwoods status        - your own standing with the forest, plus everyone else it keeps an account for
 * /vengefulwoods set <count>   - set your own destroyed-tree count (for testing a stage)
 * /vengefulwoods favor <count> - set your own number of offerings (for testing the friendly side)
 * /vengefulwoods reset         - wipe every player's account, and all rhizomes, cages and pending regrowth
 * Operators only (permission level 2).
 */
public final class WoodsCommand {

    private WoodsCommand() {
    }

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // Open to everybody: a player has to be able to pick their own class and see their own tree
        // without an operator standing over them.
        dispatcher.register(Commands.literal("woods")
                .then(Commands.literal("class").executes(context -> chooseClass(context.getSource())))
                .then(Commands.literal("skills").executes(context -> openSkills(context.getSource())))
                .then(Commands.literal("original")
                        .executes(context -> summonOriginal(context.getSource()))
                        .then(Commands.literal("here").executes(context -> moveOriginal(context.getSource()))))
                .then(Commands.literal("shimmer").executes(context -> toggleShimmer(context.getSource()))));

        dispatcher.register(Commands.literal("vengefulwoods")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("class").executes(context -> chooseClass(context.getSource())))
                .then(Commands.literal("skills").executes(context -> openSkills(context.getSource())))
                .then(Commands.literal("status").executes(context -> status(context.getSource())))
                .then(Commands.literal("set")
                        .then(Commands.argument("count", IntegerArgumentType.integer(0))
                                .executes(context -> set(context.getSource(), IntegerArgumentType.getInteger(context, "count")))))
                .then(Commands.literal("favor")
                        .then(Commands.argument("count", IntegerArgumentType.integer(0))
                                .executes(context -> favor(context.getSource(), IntegerArgumentType.getInteger(context, "count")))))
                .then(Commands.literal("reset").executes(context -> reset(context.getSource())))
                .then(Commands.literal("kudzu")
                        .then(Commands.literal("start").executes(context -> kudzuStart(context.getSource())))
                        .then(Commands.literal("stop").executes(context -> kudzuStop(context.getSource())))));
    }

    /** Puts the class choice in front of the caller, whether or not they have already chosen. */
    private static int chooseClass(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        ClassChoice.open(player);
        return 1;
    }

    /** The skill tree, for anyone whose keyboard is not cooperating. */
    private static int openSkills(CommandSourceStack source) throws CommandSyntaxException {
        Skills.open(source.getPlayerOrException());
        return 1;
    }

    /** The Mushroom calling one up where it stands, once it has paid for one the long way. */
    private static int summonOriginal(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (player.level() instanceof net.minecraft.server.level.ServerLevel level) {
            Mushroom.summonHere(level, player);
        }
        return 1;
    }

    /** Turns the Mushroom's field on or off. */
    /** Brings the nearest Original to the caller, for whoever has the rank for it. */
    private static int moveOriginal(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (player.level() instanceof net.minecraft.server.level.ServerLevel level) {
            Mushroom.moveHere(level, player);
        }
        return 1;
    }

    private static int toggleShimmer(CommandSourceStack source) throws CommandSyntaxException {
        Mushroom.toggleShimmer(source.getPlayerOrException());
        return 1;
    }

    private static int status(CommandSourceStack source) throws CommandSyntaxException {
        MinecraftServer server = source.getServer();
        WrathData global = WrathData.global(server);

        StringBuilder text = new StringBuilder();
        ServerPlayer self = source.getPlayerOrException();
        WrathData.Account mine = global.account(self.getUUID());
        text.append("You: ").append(mine.felled).append(" trees destroyed, ").append(mine.offerings)
                .append(" offerings, counts as ").append(mine.effectiveFelled())
                .append(" -> stage ").append(mine.stage().ordinal()).append(" (").append(mine.stage()).append(")")
                .append(", favour: ").append(mine.boon());

        if (Config.SHARE_STANDING.get()) {
            text.append("\n(standing is shared: this is the whole server's tally)");
        }
        if (Config.SHARE_SKILLS.get()) {
            text.append("\n(skill points are shared: one pool for the whole server)");
        }

        for (Map.Entry<UUID, WrathData.Account> entry : global.accounts().entrySet()) {
            if (entry.getKey().equals(self.getUUID()) || WrathData.isShared(entry.getKey())) {
                continue;
            }
            if (Config.SHARE_STANDING.get()) {
                continue; // Everyone is on the same tally; listing it once per player says nothing.
            }
            ServerPlayer other = server.getPlayerList().getPlayer(entry.getKey());
            String name = other != null ? other.getName().getString() : entry.getKey().toString().substring(0, 8);
            WrathData.Account account = entry.getValue();
            text.append("\n").append(name).append(": ").append(account.felled).append(" destroyed, ")
                    .append(account.offerings).append(" offerings -> stage ").append(account.stage().ordinal())
                    .append(", favour: ").append(account.boon());
        }

        int tips = 0;
        int regrows = 0;
        for (ServerLevel level : server.getAllLevels()) {
            WrathData local = WrathData.get(level);
            tips += local.tips.size();
            regrows += local.regrows.size();
        }
        int kudzu = 0;
        for (ServerLevel level : server.getAllLevels()) {
            kudzu += Kudzu.frontCount(level);
        }
        text.append("\nRhizomes growing: ").append(tips).append(" | Trees waiting to grow back: ").append(regrows)
                .append(" | Kudzu spreading from: ").append(kudzu).append(" places");

        final String message = text.toString();
        source.sendSuccess(() -> Component.literal(message), false);
        return mine.felled;
    }

    private static int set(CommandSourceStack source, int count) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        WrathData global = WrathData.global(source.getServer());
        global.setFelled(player.getUUID(), count);
        Stage stage = global.account(player.getUUID()).stage();
        SpeciesTuner.apply(WrathData.worstStage(source.getServer()));
        source.sendSuccess(() -> Component.literal("Your destroyed-tree count is now " + count
                + ". Stage " + stage.ordinal() + " (" + stage + ")."), true);
        return count;
    }

    private static int favor(CommandSourceStack source, int count) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        WrathData global = WrathData.global(source.getServer());
        global.setOfferings(player.getUUID(), count);
        WrathData.Account account = global.account(player.getUUID());
        SpeciesTuner.apply(WrathData.worstStage(source.getServer()));
        source.sendSuccess(() -> Component.literal("Your offerings are now " + count + ". Stage "
                + account.stage().ordinal() + " (" + account.stage() + "), favour: " + account.boon() + "."), true);
        return count;
    }

    private static int kudzuStart(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Kudzu.seed(player.serverLevel(), player.blockPosition());
        source.sendSuccess(() -> Component.literal("Kudzu has taken hold here. Good luck."), true);
        return 1;
    }

    private static int kudzuStop(CommandSourceStack source) {
        for (ServerLevel level : source.getServer().getAllLevels()) {
            Kudzu.wipe(level);
        }
        source.sendSuccess(() -> Component.literal(
                "Kudzu will stop spreading. Blocks already in the world stay until something clears them."), true);
        return 1;
    }

    private static int reset(CommandSourceStack source) {
        WrathData global = WrathData.global(source.getServer());
        global.clearAccounts();
        for (ServerLevel level : source.getServer().getAllLevels()) {
            WrathData local = WrathData.get(level);
            local.tips.clear();
            local.regrows.clear();
            local.cages.clear();
            local.setDirty();
        }
        ForestDirector.clear();
        Offerings.clear();
        Treefall.clear();
        Kudzu.clear();
        SpeciesTuner.apply(Stage.DORMANT);
        source.sendSuccess(() -> Component.literal(
                "The forest has forgotten everyone. Rhizome blocks already in the world stay where they are."), true);
        return 1;
    }
}
