# Vengeful Woods

A horror add-on for **Dynamic Trees** (Minecraft **1.20.1**, **Forge**).
Every tree you chop, burn or blow up is counted. The more you destroy, the harder the forest fights back.

Needs: Minecraft 1.20.1, Forge 47+, Dynamic Trees 1.4.x. It must be installed on the server **and** on every player's game.

## What you are

The first time you join, four things are offered. Three of them are visible.

|  |  |  |
|---|---|---|
| | **Druid** | |
| **Colonialist** | *( )* | **Invader** |

- **Druid** — the forest gives you **two and a half times** the favour it gives anyone else, and holds about a
  quarter less against you when you do cut something. Use a **grove charm on a living thing** and the woods
  turn on it: whatever the trees nearby are capable of, they do to that, wherever it is standing.
- **Colonialist** — you are here to take the wood out, and the forest resents you at **nearly twice the rate**.
  In exchange, felling pays: **four times the heartwood**, plus strength, haste and fire resistance for long
  enough to start on the next tree. **Open ground is yours** — with no tree within 14 blocks you mend and move
  quickly. Under canopy you are nobody. The forest's whole purpose is that there is less open ground every day.
- **Invader** — the weeds cost you **a third of the tribute**, they will **not touch you**, and they hit
  everything else **two and a half times harder**. Until there is more of them than there is of you: past
  **2,500 blocks of loose weed** they stop telling you apart from the rest of it, and the thing you spent the
  game building starts working on you.

The fourth is the empty space in the middle. Nothing says it is there.

If you close the menu without choosing, any altar will put it back in front of you.

## What happens

**The forest keeps a separate account for every player.** It remembers who chopped what and who fed it, so in a
multiplayer world it can hunt one person while leaving gifts for another. Trees behave according to whoever is
standing nearest them.

| Trees destroyed (per player) | What the forest does to that player |
|---|---|
| **6** — Stirring | Trees grow faster and never run out of soil, so cleared areas close up again. |
| **14** — Thickening | Trees reach 60 blocks and thicken; 8 growth pulses and 2 saplings a day, each standing up within a minute. |
| **22** — Creeping | **Rhizomes** at 32 blocks a day, 2 per tree. They stay buried about three blocks down, curving down as readily as up, and mostly *replace* what they grow through — only something you built is broken properly, so your walls come back as items. 14 pulses, **6 saplings**, up in 40 seconds. |
| **30** — Snarling | 40 pulses, **22 saplings** (up in 30s), 7 rhizomes at 120 a day. Stumps sprout instantly and the roots hunt **torches**. |
| **40** — Relentless | Felled trees come back. 80 pulses, **44 saplings** (20s), 13 rhizomes at 260 a day. The forest stops spreading its biomass and starts aiming it. |
| **52** — Grasping | 150 pulses, **75 saplings** (10s), 20 rhizomes at 440 a day. Growth turns toward you, roots drag at your legs, branches fall on your head. |
| **66** — Hunting | 260 pulses, **120 saplings** (6s), 30 rhizomes at 720 a day. Tendrils strike and trees are thrown down on you. |
| **84** — Wrathful | 460 pulses, **200 saplings** (3s), 44 rhizomes at 1,200 a day, background growth **×18**, regrowth guaranteed, double-damage tendrils, and it topples four times as often — with the whole forest's biomass channelled into whatever is standing over you. |

The first three stages are where they always were. **Everything past Creeping comes much sooner than it used
to** — the whole ladder now tops out at **84 trees**, so the half of the mod that actually
hunts you is no longer something you have to grind for. A Colonialist gets there on about 47 actual trees, because each one counts for nearly two.

## The Mushroom

It is almost nothing for a long time. Fungus thickens where you stand — mycelium creeping over the ground,
buttons coming up out of it, and any small mushroom you pass swelling into a cap the size of a tree. That is
the entire class for most of a playthrough, and it is meant to feel like you chose wrong.

What it is building toward is **the Original**. Raise it at an altar with a **spore idol** and **1,800
tribute** — about five stacks of logs — and a stalk goes up **ninety blocks** with a cap fourteen across,
covered in eyes that open and shut on their own.

Inside **48 blocks** of it, for anything that is not you:

- **Nausea, and the dark closing in.** Blindness in patches, darkness in others.
- **The ground stops agreeing on where it goes.** Every few seconds a person in the haze is put back down
  somewhere else facing another way, so walking in a straight line brings you round to where you started. The
  maze is not in the walls.
- **Monsters stop working** — slowness IV, weakness III, nausea, and they lose their sight at random.

The Mushroom walks through all of it untouched, because to the Original it is not an intruder. Prise an eye
out and it will have something to say about that.

**You can raise as many as you can pay for.** Each costs its own 1,800 tribute, and their reaches overlap.

**And it makes a noise.** Inside an Original's range there is a forty-second drone — detuned, beating against
itself, never quite resolving — that restarts as it ends, so there is no moment of quiet. It is in the ambient
channel, so you can turn it down like any other sound if you need to.

### What the Mushroom gets besides

- **The shimmer.** Nothing comes within **two blocks** of you. Whatever tries is simply put back down further
  out than it meant to be, mid-swing, with a smear of spores where it was standing. There is no wall — things
  just keep finding they are not as close as they thought. A ring of drifting spores makes it visible.
- **Half of everything misses.** Not blocked, not reduced: the blow goes through where you were a moment ago.

## The skill tree

Press **U**. It is the same tree for everyone, with a branch that only appears for whatever you chose.

Points are not handed out for busywork: **one for every rung you climb of the forest's anger, and one for
every rung of its goodwill** — so whichever way you are playing, the thing you are already doing is what
pays. They count off the **furthest you have ever got**, not where you stand now, so calming a forest back
down does not take your learning away again. Thirteen points exist, and a class's branch costs exactly
thirteen, which means a complete tree needs you to have been both hated and trusted at some point.

Open to anyone: **Thick Skin** (half damage from thorns), **Sure Foot** (root underfoot stops dragging),
**Forager** (hand-picked plants pay double), **Quiet Step** (kudzu smells you from half as far).

Then three apiece for the Druid (favour, longer marks, canopy healing), the Colonialist (fire, double
heartwood, a clearing twice the size), the Invader (cheaper rites, weeds that never turn on you, twice as
much loose growth tolerated) and the Mushroom (faster fungus, wider reach, harder still to hit).

## Biomass

Every standing tree feeds a pool. **The more wood there is, the more the forest has to spend**, so a wood that
has already overgrown a valley grows faster than one that is still a few saplings — which is why the late game
runs away from you.

What it does with the pool is the thing:

- **Up to Snarling it spreads it**, thinly, across every tree it owns. That is the slow even thickening you see
  early on: a few extra blocks everywhere.
- **From Relentless on it stops doing that and aims.** The whole pool goes into one place — whatever is nearest
  the player it is angriest with — and it holds that aim for **45 seconds** at a time. Trees outside **40 blocks**
  of the spot get nothing at all. The handful standing over you get everything a thousand trees made, up to
  **24 extra growth pulses each, per visit**. That is a tree erupting rather than growing.

So at the top end the wood is not uniformly faster. It is normal everywhere except exactly where you are
standing, which is the difference between a forest that grows and one that has noticed you.

The weeds bank their own pool off the blocks they have in the ground, and spend it the same way — in surges
rather than evenly.

## Making peace

Craft **Forest Fertilizer**: 1 hay block + 2 bones + 1 wheat seeds (shapeless) makes 3. Right-click any tree block
with it. Each one cancels out **1 destroyed tree** — for the player who gives it, nobody else.

Gifts also build favour, but only while the forest is calm enough to notice you (before the rhizomes come out;
past that it is too angry to care). Favour is personal, and it is **twice as hard to earn as it used to be** —
a **Druid** earns it two and a half times faster, a **Colonialist** at less than half rate.

| Offerings | What the forest does for you |
|---|---|
| **45** — Tolerated | Presents at the roots — sticks, apples, bone meal, seeds, and **heartwood** once you climb higher. |
| **120** — Allied | Gifts twice as often. Leaves pull out of your way, saplings keep off your walls, and mobs near you get crushed. |
| **240** — Guardian | Gifts four times as often, with golden apples and heartwood. It throws whole trees at whatever is hunting you. |
| **450** — Warden | It **pulls invasives up around you unasked** — kudzu, blackberry, knotweed, cheatgrass, hyacinth, all of it. |
| **800** — Heartbound | Stand under any canopy and the woods hold you up: **regeneration and haste** for as long as there are leaves over your head. |

**Heartwood is no longer only a gift.** A felled tree yields a little — about one piece every five or six
trees, and four times that for a Colonialist — so playing against the woods no longer locks you out of their
gear entirely.

## The plants that belong here

**Eleven real natives**, each growing where it actually grows and nowhere else. All of them are useful, all of
them come back on their own if you leave some, and the forest keeps a tally of how you treat them.

| Plant | Where it grows | What it is for | Picking costs |
|---|---|---|---|
| **White trillium** *(Trillium grandiflorum)* | Deciduous forest | **2 white dye** each, and the flower a grove charm wants | **4 pickings** — a picked trillium may not flower again for years, and the forest prices it that way |
| **Wild ginger** *(Asarum canadense)* | Deciduous forest | Food, and greens for fertilizer | 1 |
| **Ramps** *(Allium tricoccum)* | Deciduous forest | Solid food (3, good saturation) | **3** — whole valleys of it have been dug out in living memory, and the woods have noticed |
| **Ostrich fern** *(Matteuccia struthiopteris)* | Wetland | Fiddleheads: **raw they make you ill**, cooked they are solid food (6) | 1 |
| **Sweetgrass** *(Hierochloe odorata)* | Wetland | **Fuel** (600 ticks), and 3 braids make string | 1 |
| **Cattail** *(Typha latifolia)* | Wetland, on mud, clay or wet sand | **Fuel** (500 ticks) — the dried head is the best tinder growing anywhere | 1 |
| **Wintergreen** *(Gaultheria procumbens)* | Taiga and boreal | Eat a few leaves for **regeneration**, hungry or not | 2 |
| **Sea buckthorn** *(Hippophae rhamnoides)* | Beaches and stony shores | Food (4) with a **60% chance of regeneration** on top | 1 |
| **Prickly pear** *(Opuntia humifusa)* | Desert and badlands, on sand or terracotta | Food (3) | 1 |
| **Wild bergamot** *(Monarda fistulosa)* | Savanna | Eat any time for **15 seconds of resistance** — the tea that settles you | 1 |
| **Alpine bistort** *(Bistorta vivipara)* | Peaks, slopes and windswept hills, on bare stone, scree or old snow | Food (4, the best saturation of any of them) — it carries its own young on the stem | **2** — nothing up there grows back quickly |

**Each one wants its own ground.** Prickly pear will not take in leaf litter and trillium will not take in sand,
so you cannot carry a pocketful of one plant around the world and farm it anywhere: a shore plant needs a shore.

**Picking angers the forest slightly.** Six pickings add up to one felled tree, so forty-eight ordinary plants —
or twelve trilliums — is the first stage. Nothing like cutting timber, but it adds up if you strip the ground.
Ramps and bistort cost more than the common ones, for the same reason trillium does: they do not come back fast.

**Planting earns a little back.** Eight plants put in the ground is worth one offering of favour, capped at
**five a day** so that gardening stays a slow way to be forgiven rather than a shortcut. And it is deliberately
worse value than picking is bad: pull a trillium up and push it straight back in and you are **0.29 trees worse
off** than before you touched it. There is no way to farm the forest's good opinion out of the same flower.

Left alone they creep back into the ground beside them, which is the only reason picking them is forgivable at
all.

## Trees fighting back

* If a **mob** destroys a tree — a creeper blast, a fire nobody lit — the trees in that area hold a grudge for
  10 minutes and go after mobs there, whether or not they like you.
* Against a mob they will **cage it** in wooden columns, **cut a branch loose above it** so the canopy lands on
  its head, or **topple a whole tree** onto it. A toppled tree is gone for good — the forest spends itself.
* From **Grasping** on they do the same to **you**, and they all do it at once: every player the forest has a
  grievance with is worked on every two seconds, not one picked at random. Branches come loose on a short cooldown,
  whole trees from **Hunting**, cages at **Wrathful**. Falling-tree damage is Dynamic Trees' own, so its
  `enableFallingTreeDamage` setting still applies.

What counts as destroying a tree:

* chopping it down (or digging out the soil block under its trunk),
* burning it, if a player used **flint and steel**, a **fire charge** or a **lava bucket** nearby (within 48 blocks, in the last 20 minutes; the fire is followed as it spreads),
* blowing it up with **TNT**.

A piece only counts if it has at least 3 branch blocks, and the same tree is never counted twice within 5 minutes.

Good to know:

* Creative and spectator players are never hunted, hit or given gifts. Test in survival.
* Trees keep growing, spreading and planting **whether or not anyone is watching** — a tree stays active as long
  as its chunk is still ticking, and when nobody is nearby it falls back on the forest's general temper. Chunks
  that Minecraft has unloaded entirely are frozen, as always; nothing can change that without a chunk-loading mod.
* The mod searches **256 blocks** around each player for trees it has not found yet, so an angry forest drives
  trees you have never walked past. The 64-block radius only decides whose standing a tree answers to.
* Time skipped by sleeping counts toward what a tree is owed.
* **There is no limit on how dense the forest gets.** Trees may now stand shoulder to shoulder, any number of them
  can be driven at once, and rhizomes run forever. If a server starts struggling, the brakes are
  `minTreeSpacing`, `maxTrackedTrees`, `maxActiveTips` and `maxLength` in the config - all set to "unlimited" by default.
* Chests, furnaces and other storage blocks are never broken unless you turn that on in the config. Beds, obsidian and bedrock are always safe.
* Kudzu comes in three blocks: **vine** (woody, axe), **leaves** (mats, hoe or shears) and **root** (underground, axe). All three burn.
* **Vine and root are alive wherever they end up.** Place one from your inventory, or leave a scrap behind when
  you clear a patch, and it starts running again on its own. Only the leaves are inert — cut those all you like.
* Rhizome blocks can be chopped with an axe (they drop sticks) and they burn. Breaking them does not count as cutting a tree.
* Cages take themselves apart after about 12 seconds, and never wall a player in.
* A tree the forest throws itself does not count against you, and drops nothing.

## Kudzu

Something worse than you is in these woods, and it grows the way a tree does — only sideways, and far faster.

**Runners** are small, fast and numerous. Each one crawls only a couple of dozen blocks before it gives out, but
it forks every three blocks on the way, so one outbreak becomes a tangle of threads rather than a few long ropes.
Roughly half of them dive **underground**, laying **kudzu root** for twenty-odd blocks at a time — under your
walls, under your floor — before pushing a shoot back up into the light. Cutting the green you can see does
nothing about the network beneath it.

They cannot climb into open air: to gain height they have to grab something, so they go up trunks, walls and
cliffs, then spread out across the top and put everything below into permanent darkness. **They follow the lie
of the land** — up a rise, draping down a bank — and will only reach across a gap of **3 blocks or less**, and
only toward something solid to land on. That is how kudzu really crosses from tree to tree, and it means a
runner that meets open water heads for the ground instead of marching out over it.

**It never stops.** Runners are short-lived on purpose, but if the last of them dies while you are not looking,
a new one starts from any block still in the ground within a few seconds. Short of taking every last piece of
it out, it is always coming back.

**They hunt.** A runner that senses a player within 48 blocks steers toward them and **lays three blocks a step
instead of one** while it has your scent — a runner that has found you does not amble. The buried ones come up
underneath.

**And being in it is the dangerous part.** This no longer waits for a growing tip to path exactly onto your
boots, which almost never happened and is why being swallowed used to work so badly. **Three blocks of kudzu
around you is enough**: it closes over you where you stand, and after a couple of seconds it starts **pulling
you down into itself**, breaking the ground under you and sealing the hole overhead. Spores come with it —
nausea and weakness at first, poison and hunger once it has had you a while — and the damage **climbs the
longer it holds you**, so digging out early is the whole game.

**It eats.** Anything living caught in kudzu is torn at, and anything that dies in it is absorbed: the weed
banks the kill as biomass and thickens over the spot. A kudzu wood feeds itself on the things breeding under
its own canopy.

It also swallows crops, crushes whatever it piles three layers deep onto, and holds you fast if you walk into it.
Under the leaf mats it is dark enough for anything to breed.

The trees fight it — they tear vine off wherever it touches wood, and rhizomes shove straight through it — but
they clear maybe 10 blocks a second against its 60. They are losing, and they will keep losing.

**Cut it back and the trees notice.** Every 20 kudzu blocks a player breaks counts as one fertilizer offering for
that player — the fastest way into the forest's good books.

It burns well. Fire is your best weapon and the most dangerous thing you can bring into a forest.

**Where it comes from.** Nowhere, unless you bring it. Kudzu no longer arrives on its own at any tree count:
the only door into a world is the Rite of Blight at an altar, and that costs 1200 in tribute. Spreading is down
to **45 blocks a second** as well — still four times anything else in the mod, but no longer a green tide.
(`appearsOnItsOwn = true` in the config puts the old behaviour back.)

To start one yourself: `/vengefulwoods kudzu start` (right where you stand). To call it off:
`/vengefulwoods kudzu stop`. The `[kudzu]` config section controls the trigger (`arrivesAfterTrees`), the ring
(`minDistance` / `maxDistance`), spread rate, branching, leaf density, runner count, burrowing, hunting and
burial damage — `enabled = false` turns the whole thing off.

## The lesser invasives

Four real weeds, with the habits they actually have. Every one pays for itself — that is exactly why people
planted them in the first place — and every one is stopped by the thing that really stops it.

| Plant | Pays in | Loose, it… | Stopped by |
|---|---|---|---|
| **Himalayan blackberry** *(2/s)* *(Rubus armeniacus)* | **Blackberries** (food) | Closes paths with thicket, 1 damage a second to anything standing in it | **Hard standing** — paving, bricks, slabs |
| **Japanese knotweed** *(Fallopia japonica)* | **Shoots** (good food) + the rubble it breaks through | Comes **up through floors, walls and foundations** | **A buried root barrier** — iron, copper, gold or netherite blocks, obsidian |
| **Cheatgrass** *(Bromus tectorum)* | **Dry thatch** (burns twice as long as coal) | Cures to tinder and **sets the country alight** | **Water and green firebreaks** |
| **Water hyacinth** *(Eichhornia crassipes)* | **Fibre** (3 → 2 string; also the woven armour) | **Seals waterways shut** | **Dry land and booms** — logs, planks, fences, iron bars |
| **Chinese wisteria** *(Wisteria sinensis)* | **Blooms** (1 → 2 purple dye), and the withy for woven armour | **Creeps toward players** at a block every three seconds, **goes for built blocks 4 times out of 5** and brings down ~4 blocks of structure for each one it takes, climbs trees and kills them, grows into thick woody mats, and closes around anyone who stands in it too long. **Will not burn, grows back when cut** | **Smooth surfaces** — glass, metal blocks, ice |

Cut one and it drops its produce, plus a cutting about a third of the time. A block you place spreads exactly
like one that escaped, because there is no difference — only the fence you built. When a species has added
enough blocks, everybody is told it has got away.

Clearing them earns favour at 40 blocks to the offering; kudzu work is worth twice that.

**Everything they put down grows.** Any piece of any invasive — a length of woody vine, a spray of flower, a
shoot off a cane, a handful of kudzu leaf — starts the whole plant again the moment somebody puts it in the
ground. There is no inert part.

**They grow shoots.** Knotweed is a cane two or three metres tall in life and bramble throws arching canes over
whatever it covers, so neither reads as a carpet on the floor any more: knotweed sends something up out of
**more than half** the blocks it lays, bramble out of about a third.

**Three of them are built from parts now.** Wisteria is the woody vine plus the curtain of flower hanging off
it; **blackberry** is root below ground, thicket at the surface and arching **cane** above; **knotweed** is the
famous **rhizome** underground and a bamboo-like **cane** standing out of it. Which part grows where depends on
whether it is buried or in the open, so a stand looks like a plant instead of a sheet of one block. Every part
is the plant — cut one and leave the others and you have cleared nothing — and **every part drops something you
can plant again**, at even odds.

**Himalayan blackberry has been pulled right back**, from 6 blocks a second to 2. It was outgrowing everything,
including the things that are supposed to be worse than it.

## Getting hold of them

**Nothing invasive appears on its own, kudzu included.** The only way any of it enters your world is a rite,
paid for in **tribute**.

Tribute is weight, not virtue. Leave anything on the altar and the whole stack goes, worth 2 each. Kill
something on it and it counts for far more: a hostile mob is 4, an animal 15, **a tamed pet 60**.

| Rite | Charm | Tribute | Gives |
|---|---|---|---|
| **Rite of Seeding** | Seedbed Charm | **60–110** | A stand of whatever suits where you stand, plus four cuttings |
| **Rite of Blight** | Blight Seed | **600** | Kudzu. No other way in, and no way back out. |

The Rite of Seeding reads the ground around the altar: **standing timber** gives wisteria, **still water** gives
hyacinth, **bare rock** gives knotweed, **dry open ground** gives cheatgrass, and anywhere else green gives
blackberry.

## Wisteria

Wisteria is the slowest thing in the mod and the one that gets there anyway. Every stem takes **three seconds
over a single block** — you can stand and watch it take one — and it is always coming. A stem senses anybody
within **64 blocks** and works toward them, crooked, in no hurry, around whatever is in the way.

**What it actually wants is your walls.** Any stem touching something built takes the built block **4 times out
of 5** rather than the open ground beside it, so a vine that reaches a base stops travelling and starts eating.
And the hole it makes does not stay one block: the course above it comes down, with **a bite out of the wall to
the side at every level** — about **four blocks gone for each one it takes**, travelling up to six blocks up.
Walls open, floors drop, roofs come in. A single stem against stonework takes roughly **a block a second** once
it is through, and they arrive in numbers.

It is heavy as well as patient. Three courses of wisteria over anything built and the thing underneath gives
way, collapsing the same way, so a roof under a mature vine does not stay a roof.

### Getting rid of it

Not easily:

- **Hardness 2.6** — tougher than most of what you build out of. Hoe or axe, and it is not quick.
- **It will not burn.** Green, woody and full of sap: fire clears kudzu and does nothing at all to this.
- **It grows back into the gap.** Pull one block out by hand and there is a **55% chance** a neighbouring stem
  starts running again, pointed at the hole. Clearing a stand a block at a time takes **more than twice as many
  swings as there are blocks**.
- **The brush hook is the answer.** A swing takes the whole stand around the spot at once, and what is cut in
  one go has nothing left to grow back from. Wisteria is woody enough that the hook bites **one block less far**
  than it does through kudzu, but it still beats cutting by hand by a mile.

### Standing still in it

It keeps growing whether or not you move, and someone who stays put is a thing it can grow around. Stand in a thick patch — six blocks of it within arm's reach — for **12 seconds** and you are told it has
stopped going around you. After that it closes in a block at a time from the ground up, and leans on you for
**1.5 damage a second, climbing the longer you stay**. Walking out unwinds the count twice as fast as standing
there built it up.

## When one gets away from you

The mod keeps track of who called each species up. If a patch spreads past the escape threshold, the trees
**blame that person**: **+25 trees** on their tally the moment it happens, and **+6 more every two minutes**
for as long as it stays loose.

**If you planted it on purpose, all of that is tripled.** A rite at an altar and a block placed by your own
hand both count as deliberate; something that spread in from someone else's mess does not. Planted on purpose
and left loose for an hour, an escape costs you about **615 trees** — three times what WRATHFUL asks for. The
forest can tell the difference between bad luck and a decision, and it does not forgive the second one on the
same terms.

An escaped species also goes **rampant** — spread multiplied by **2.5**, and double the chance of killing any
tree it gets hold of. Blackberry, knotweed, cheatgrass and wisteria all strangle trees; wisteria does it half
the time it touches one.

### Making it right

Wipe out an escape you caused and the forest gives back **every point of anger it cost you** — the whole
penalty, the drip included, however far it has pushed you up the stages. It is not cheap, and it will not be
fooled:

- **The mess has to have been real.** The patch must have added **400 blocks** since it got loose, on top of
  the 120 it took to escape in the first place.
- **You have to have taken out that much of it yourself.** 400 blocks pulled up, by hand or with the brush
  hook — the hook counts, because clearing a disaster with the right tool shouldn't count for less.
- **Every running tip has to be gone.** Any surviving block can start a new runner on a random tick, so this is
  the part that actually takes the work.

Plant a weed, let it tick past the warning line, and dig it straight back up, and you get nothing: it was never
a mess. Let one eat half a valley and then spend an evening taking it out and you walk away square. The account
is kept with the world, so a restart does not wipe either the debt or the chance to pay it.

Short of that, cutting every last running tip out still contains the species: the rampancy stops and so does
the drip of anger. You simply keep what it has already cost you.

## Altars and rites

Build a **verdant altar** and **use it empty-handed to open it** — it holds 27 slots. Put in what you are
giving up, then use a charm on the altar and everything in the bowl is counted and taken at that moment. No
more feeding the stone one item at a time.

**Crouch and use it empty-handed** for a plain readout: your anger, your favour, your banked tribute, what the
rites cost and how much biomass the wood around you is sitting on. If anything about this mod is unclear, that
is the place to look.

Not everything is worth the same:

| Offered | Tribute each |
|---|---|
| **A log** | **6** |
| Planks, stairs, slabs, fences, doors, saplings — anything made of wood | **3** |
| Everything else | 2 |

**Timber is the currency.** The forest takes its own body back more seriously than anything else you could
bring, which makes felling a stand and handing the wood over the plain way to pay for a rite — and a bleak one,
since you are buying a weed with the trees you killed, and the felling is on your tally either way. A stack of
logs is **384 tribute**: enough for any of the five lesser weeds outright. Then hold the charm for the rite you want and use the altar:

| Charm | Rite | Costs | Does |
|---|---|---|---|
| **Grove charm** | Groves | the charm | Calls up **14 saplings** of whatever grows best in this country, and earns you a point of favour for it |
| **Root totem** | Roots | the charm | Sends out **6 rhizomes** from the altar. They are not yours and they do not take instructions |
| **Bargain idol** | The Bargain | **+12 trees** on your tally | The forest hands over **32 logs**. You did not cut them, and it still counts |
| **Seedbed charm** | Seeding | tribute, per species | Lays down a stand of one real invasive — **blackberry 60** (10 logs), **hyacinth 70** (12), **cheatgrass 80** (14), **wisteria 90** (15), **knotweed 110** (19) |
| **Blight seed** | Blight | **450 tribute** and **+20 trees** | Lets **kudzu** in on purpose. About **75 logs** — a stack and a bit |

The Rite of Seeding reads the ground around the altar to decide what you get, so stand the altar where the
species you want belongs.

## Sacrifices

The forest notices anything that dies **within six blocks of an altar**:

| | Offerings earned |
|---|---|
| Hostile mob | 1 |
| Animal | 3 |
| **Tamed pet** | **15** |

It counts a creature that trusted you far higher than one that didn't. Make of that what you will — all three
values, and the whole mechanic, are config switches.

## Gear

| Item | Made from | Notes |
|---|---|---|
| **Heartwood Sword** | 2 heartwood + stick | Iron-tier, hits harder than iron |
| **Heartwood Axe** | 3 heartwood + 2 sticks | Iron-tier |
| **Brush Hook** | 2 iron + fibre + 2 sticks | Clears **kudzu and every other weed, 5 blocks out in one swing** — far and away the fastest way to earn favour, and the only sane way to clear wisteria |
| **Heartwood armour** | heartwood + kudzu fibre | Full set: the forest treats you as **one stage calmer** than you are |
| **Woven armour** | wisteria + **one iron ingot** (chest and legs only) | **Stronger than iron** — 3/6/7/3 with 0.5 toughness and half again its durability. **Thorns cannot reach you through it**: any single piece turns blackberry |
| **Kudzu Fibre** | 4 kudzu leaves | Crafting material |
| **Spore Idol** | red + brown mushroom blocks, stem, heartwood, nether wart | Raises the Original. Only the Mushroom can use it |

### The specialists

A brush hook cuts anything green, badly. These three each answer one weed it cannot really deal with, and all
three are iron-tier weapons as well, because the things living under a kudzu canopy have to be got through
first.

| Tool | Made from | For | Reach per swing |
|---|---|---|---|
| **Heartwood Lopper** | 3 iron + 2 heartwood + 2 sticks | **Wisteria**, blackberry canes and the woody kudzu vine. The brush hook barely bites wisteria — **125 blocks a swing** against the lopper's **729**, which is most of the reason to make one | 9×9×9, 820 uses, 5 attack |
| **Grubbing Mattock** | 3 iron + 2 rhizome + 2 sticks | **Knotweed and the buried network.** The only tool that follows a weed **8 blocks straight down** under your floor, and the only one that takes the forest's own rhizomes | 7×7 down 8, 640 uses, 4 attack |
| **Hedge Slasher** | 3 iron + 2 kudzu fibre + stick | **Blackberry, cheatgrass, hyacinth, knotweed tops and kudzu leaf mats.** Widest sweep in the mod, fastest swing, and **holding it keeps the thorns off you** — the only way to work a bramble thicket without woven armour | 13×13×5, 560 uses, 3 attack |

**Tool sweeps drop nothing.** One swing can take hundreds of blocks and hundreds of item entities is how a
server dies, so clearing with a tool destroys the weed outright. Break it **by hand** if you want the harvest.

Each wants the right target: swung at something it is not for, nothing happens. And **clearing with a tool now
earns favour at the same rate as doing it by hand** — one swing through a thick stand can be worth several
offerings at once, which it previously was not.

Heartwood armour never makes you safe — it buys you one step, which at Wrathful is the difference between being
caged and merely having trees dropped on you.

### What fertilizer is made of, and what wants it

**Fertilizer**: a hay block, 2 bones, wheat seeds, and **any green the mod grows** — berries, knotweed shoots,
kudzu leaves, wisteria blooms, hyacinth fibre, wild ginger, wintergreen, fiddleheads or sweetgrass. That makes
**4**. If you have weeds but no hay there is a second way round it: dry thatch, kudzu leaves, 2 bone meal and a
green makes **2**.

Fertilizer is no longer only something you hand to a tree. **The altar and all five charms are bedded in with
it** — you ask the forest for something by offering first, not by holding the right rock:

| | Wants |
|---|---|
| **Verdant altar** | 2 heartwood + **fertilizer** + 6 logs |
| **Grove charm** | heartwood + sapling + **fertilizer** + **trillium** |
| **Root totem** | heartwood + 2 rhizome + **fertilizer** |
| **Bargain idol** | 2 heartwood + flint + **fertilizer** |
| **Seedbed charm** | heartwood + bone meal + small flower + dirt + **fertilizer** + **sweetgrass** |
| **Blight seed** | kudzu + kudzu leaves + bone + **2 fertilizer** |

Cut rhizomes now drop a length of rhizome about a third of the time, which is what a root totem is made of.

## Where everything is

Everything the mod adds sits in **one creative tab — "Vengeful Woods"** — rather than scattered through the
vanilla ones: the natives first, then the weeds, then what they pay out, the forest's own materials, the altar
and charms, and the gear last.

## Commands (operators only)

| Command | What it does |
|---|---|
| `/woods class` | Opens the class choice again if you missed the prompt |
| `/woods skills` | Opens the skill tree (the **U** key does the same) |
| `/woods original` | Calls an Original up where you stand, if the Call allows it |
| `/woods original here` | Moves the Original you already have to you |
| `/woods shimmer` | Turns the shimmer field on and off |
| `/vengefulwoods status` | Every player's standing, and what the forest is currently running |
| `/vengefulwoods set <n>` | Sets your destroyed-tree count |
| `/vengefulwoods favor <n>` | Sets your offerings |
| `/vengefulwoods reset` | Wipes every account back to nothing |
| `/vengefulwoods kudzu start` / `stop` | Starts or stops kudzu where you stand |

The four under `/woods` are open to everyone; the `/vengefulwoods` ones need operator level 2.

## Settings

After the first start you get `config/vengefulwoods-common.toml`. Every number above can be changed there
(stage thresholds, height cap, regrow chance, tendril damage, whether builds and containers can be broken, and so on).

### Playing together

Two settings under `[sharing]` decide whether a server is one forest or several, and they are independent:

| Setting | Default | What it does |
|---|---|---|
| `shareStanding` | `false` | `true` pools **hate and favour**. Every tree anybody fells counts against all of you, every offering anybody makes counts for all of you, and the whole server sits at one stage. One person clearing land puts the woods on everybody. |
| `shareSkills` | `false` | `true` pools **skill points and ranks**: one pool, one tree, and a power bought by anybody is held by everybody who can use it. |

Your **class is always your own**, whatever these are set to, and a class-only skill still does nothing for a
player of another class — so a shared tree is worth spending across all four rather than deep in one.

With `shareSkills` on and `shareStanding` off, the pool grows by **the furthest any one of you has pushed the
forest, plus everything all of you have felled and given**, so splitting the work up does not cost you points.

Switching either on does not merge what has already happened. The shared tally and the shared tree both start
where they were left — empty, the first time — and everything each player built up on their own is kept, set
aside, and comes straight back if you switch the setting off again.

Two datapack tags can be edited as well:

* `vengefulwoods:light_targets` - the blocks treated as torches (add lanterns here if you want)
* `vengefulwoods:rhizome_immune` - blocks rhizomes can never break

---

# Turning this folder into a .jar

This folder is the mod's source code. It has to be built once to get the `.jar` file you upload. Pick one way.

**First:** open `gradle.properties` in a text editor and change `mod_authors=YourNameHere` to your name.

## Way A - on your own computer

1. Install **Java 17** (the "JDK 17" download from https://adoptium.net).
2. Open this folder.
   * **Windows:** click the address bar of the folder window, type `cmd`, press Enter, then run `gradlew build`
   * **Mac / Linux:** open a terminal in this folder, then run `chmod +x gradlew` and `./gradlew build`
3. Wait. The first run downloads Minecraft and Forge and takes 5 to 15 minutes. It must end with `BUILD SUCCESSFUL`.
4. Your mod is `build/libs/vengefulwoods-1.20.1-1.0.0.jar`.

## Way B - let GitHub build it (nothing to install)

1. Make a free account on https://github.com and create a new repository (the "+" at the top right, "New repository"). Private is fine.
2. On the new repository page click "uploading an existing file" and drag **everything inside this folder** in. Then "Commit changes".
3. The folder `.github` is hidden on most computers and may not come along. If the "Actions" tab does not show a run called "Build mod":
   "Add file" > "Create new file", name it `.github/workflows/build.yml`, paste in the contents of `github-build-workflow.txt` (a copy kept in this folder for exactly this), and commit.
4. Open the "Actions" tab, click the newest run and wait for the green tick (about 5 minutes).
5. At the bottom of that run, under "Artifacts", download `vengefulwoods-jar` and unzip it. The `.jar` inside is your mod.

## If the build fails

Copy the red error lines (they name a file and a line number) and send them to whoever is helping you with the code.
This project was written against the Dynamic Trees 1.4.10 and Forge 47.3.0 source code but has not been through a real Forge build yet, so a small fix may be needed.

## Try it before you upload it

1. In the CurseForge app (or any launcher) make a Minecraft 1.20.1 Forge profile and add **Dynamic Trees**.
2. Drop your `.jar` into that profile's `mods` folder and start a new world.
3. Run `/vengefulwoods set 60`, stand in a forest in survival mode and watch for a few minutes. Then try `200`, `300` and `450`.
4. For the friendly side: `/vengefulwoods reset` then `/vengefulwoods favor 120`, and stand near trees with mobs around.

---

# Uploading to CurseForge

1. Go to https://authors.curseforge.com and log in (Google, Discord, GitHub or Twitch all work).
2. Click **Start a project**, choose **Minecraft**, then the class **Mods**.
3. Fill in the form:
   * **Name:** Vengeful Woods (it must be unique; if it is taken, pick another name)
   * **Summary:** one sentence, e.g. "A Dynamic Trees horror add-on: the more trees you destroy, the harder the forest fights back."
   * **Description:** paste the text from `CURSEFORGE_DESCRIPTION.md` and edit it to taste. It has to be in English and really describe the mod.
   * **Logo:** `curseforge_logo_400.png` from this folder, or your own picture
   * **Main category:** pick the closest fit from the list, for example Adventure and RPG or World Gen
   * **License:** MIT (that is what this folder is set up with; you can pick another)
4. Create the project, then open its **Files** tab and click **Upload file**:
   * choose your `.jar` (a mod must be a `.jar`, not a `.zip`)
   * **Release type:** Release (or Beta while you are still testing)
   * **Game version:** tick **1.20.1**, **Forge**, and, where the list offers them, **Java 17**, **Client** and **Server**
   * **Related projects:** add **Dynamic Trees** as a **Required Dependency**, so the app installs it automatically
   * **Changelog:** "First release."
5. Submit. The file shows "Under Review" until a moderator has looked at it. They either approve it or tell you what to change.
6. When it is approved the project page goes public and people can install it from the CurseForge app.

To publish an update later: raise `mod_version` in `gradle.properties`, build again, and upload the new `.jar` on the same Files tab.
