# Vengeful Woods

**The forest keeps count.**

Vengeful Woods is a horror add-on for Dynamic Trees. Every tree you chop down, burn or blow up is remembered, and the more you destroy, the harder the forest fights back. It starts quietly. It does not end quietly.

**Requires Dynamic Trees.** Minecraft 1.20.1, Forge. Needed on both client and server.

## Four ways in

The first time you join, three things are laid out in a ring and you pick one. The Druid is given far more by
the forest than anyone else and can point it at something to kill. The Colonialist is here to take the wood
out, is hated at nearly twice the rate for it, and is paid in timber and fire — strongest standing in ground
he has already cleared, which the forest is working hard to undo. The Invader gets the weeds cheap, walks
through them untouched and turns them on everything else, right up until there is more of them than there is
of him.

There is a fourth. It is the empty space in the middle of the other three, and nothing anywhere mentions it.
It is nearly useless for most of a playthrough. It ends up being the strongest thing in the mod.

## It knows who you are

The forest keeps a separate account for every player. It remembers who felled which tree and who fed it, so on a
server it can hunt one of you while leaving gifts at the roots for another. Trees behave according to whoever is
standing closest to them.

## How it escalates

**8 — Stirring.** Trees grow faster and never exhaust their soil. Cleared paths close up behind you.

**18 — Thickening.** Trees reach 60 blocks, thicken, and plant a sapling a day.

**28 — Creeping.** Rhizomes burrow out of the roots at thirty blocks a day, through whatever is in the way.

**38 — Snarling.** Stumps sprout the moment a tree falls, roots travel eighty blocks a day in packs, and they begin
hunting your torches.

**50 — Relentless.** Half of everything you fell stands again by morning, and the roots double their reach.

**64 — Grasping.** The woods lean your way. Roots underfoot drag at your legs and the canopy above you comes loose.

**80 — Hunting.** Tendrils surface beside you and strike, and whole trees are thrown down on top of you.

**100 — Wrathful.** Growth nine times over, regrowth guaranteed, double-strength tendrils, trees falling four times
as often, and wooden columns that cage you where you stand.

The first three stages are gentle and the rest are not far behind them. A hundred trees is one afternoon of
clearing land, and the half of this mod that hunts you is not something you have to go looking for.

## Making peace

Forest Fertilizer — hay, bone and seed — can be given to any tree. Each offering cancels out one felled tree for
the person who gives it, and enough of them turns the forest around for that person alone:

* **Gifts.** It starts leaving things at the roots: sticks, apples, bone meal, its own seeds, the occasional golden apple.
* **An open way.** Leaves pull aside as you walk, and saplings stop sprouting against your walls.
* **A guard.** Hostile mobs near you get caged in wooden columns, have branches dropped on them, and eventually have
  whole trees thrown down on them.

The forest only notices gifts while it is calm enough to care. Keep chopping and it stops listening.

## It fights mobs too

Kill a tree with a creeper and the trees nearby remember it. For the next ten minutes anything hostile in that
part of the woods gets caged, crushed under falling branches, or buried under a toppling trunk — whether or not
the forest likes you.

## And something is killing the forest

Kudzu grows the way a tree does, only sideways and far faster. Small, short-lived runners fork every few blocks
into a tangle of threads, and half of them travel underground, laying root beneath your floor before pushing shoots
back up inside your walls. They hang thick mats of leaf off everything they touch, and any scrap of vine or root left behind — or placed by
hand — starts running again by itself. They can't rise into open air — to get height they
climb trunks, walls and cliffs, then spread across the top and put the ground beneath into permanent night. They
strangle trees outright, swallow fields, break through walls or tunnel under them, crush what they pile onto, and
hunt you down — a runner that finds you fills the space you stand in a layer at a time and drowns you in green while
you dig for the surface.

The trees tear at it wherever it touches wood. They clear about a sixth as fast as it grows. They are losing.

It arrives because of you. Fell sixty trees and an outbreak takes hold forty to sixty blocks away, in the
gap you opened up.

Cut the weed back and the forest notices — clearing kudzu earns the same favour as feeding the trees by hand. It is
the fastest way to be forgiven, and the only fight the forest cannot win alone.

## The plants that belong here

Eleven real natives grow across the world, each in the ground it actually wants and nowhere else. Deciduous
forest has white trillium for white dye, wild ginger, and ramps. Wetlands have ostrich fern for fiddleheads
that will make you ill raw and feed you cooked, sweetgrass for fuel and cord, and cattail, whose dried head is
the best tinder growing anywhere. Taiga has wintergreen leaves to chew when you are hurt. Beaches and stony
shores have sea buckthorn, sour and orange and likely to heal you. Desert and badlands have prickly pear.
Savanna has wild bergamot, the tea that settles you. And on the peaks, where nothing much bothers, alpine
bistort carries its own young on the stem.

Each one is fussy about its ground, so you cannot pocket a shore plant and farm it in a forest.

The forest keeps a tally of how you treat them. Picking costs you a little — six pickings add up to one felled
tree, and a trillium counts as four, because a picked trillium may not flower again for years. Putting plants
back in the ground earns a little, capped so that gardening is a slow road to forgiveness rather than a
shortcut, and deliberately worse value than picking is bad: pull a trillium up and push it straight back in and
you end up worse off than before you touched it. Left alone, they creep back on their own. That is the only
reason the forest forgives picking them at all.

## Five real weeds you will regret

Himalayan blackberry, Japanese knotweed, cheatgrass, water hyacinth and Chinese wisteria. Every one of them is a
plant people introduced on purpose because it was useful, and every one is now somebody's nightmare.

They behave the way they do in life. Blackberry closes paths with thorn. Knotweed comes up through floors and
foundations. Cheatgrass cures to tinder and rewrites the fire season. Hyacinth seals a river shut in a fortnight.
Each pays you in food, fuel, fibre or rubble, and each is held back by exactly one thing — paving, a buried metal
barrier, water, or dry land. Pick your fence before you plant.

Nothing invasive appears on its own, kudzu included. The only way any of it reaches your world is a rite at an
altar, bought with tribute: everything you pile onto the stone, and everything you kill on it.

And the forest watches who does it. Let something escape and the trees put it on your tally — a hard jump the
moment it gets loose, then a steady drip for as long as it runs wild, while the weed itself spreads two and a
half times faster and starts pulling trees down. **If you planted it on purpose, all of that is tripled**, and
an hour of ignoring it will take you past the worst stage in the mod. The forest can tell bad luck from a
decision.

You can still make it right. Wipe out an escape you caused and you get back **every point of anger it cost**,
the drip included — but only once the patch has genuinely become a disaster, and only once you have taken that
much of it out of the ground yourself, down to the last running tip. Plant a weed, let it tick past the warning
line, and dig it straight back up, and the forest gives you nothing: it was never a mess. Wisteria is the worst of them for that, and the one worth being afraid of. It takes three seconds over a single
block and it never stops: it senses you from sixty-four blocks off and comes, crooked and unhurried, around
whatever is in the way. What it really wants is your walls. A stem touching anything built takes the built block
four times out of five, and the hole does not stay one block — the course above comes down and the wall opens
sideways, about four blocks of structure gone for every one it takes. It will not burn, it is harder than most
of what you build out of, and pulling it out by hand sets the rest of the plant growing back into the gap. Only
the brush hook really clears it. Its withy makes armour better than iron, which is exactly why people keep
planting it anyway.

## Biomass

Every standing tree feeds a pool, so a wood that has already taken a valley grows faster than one that has not.
Early on the forest spreads that pool thinly over everything it owns and the whole wood thickens evenly. From
Relentless on it stops doing that and starts aiming: the entire pool goes into whatever is nearest the person
it is angriest with, and trees forty blocks away get none of it. The late game is not a forest that grows
faster everywhere. It is a forest that is normal everywhere except exactly where you are standing.

## Altars, rites and sacrifices

Use an altar empty-handed and it opens: twenty-seven slots to put what you are giving up into, counted and
taken the moment you work a rite. Crouch and use it for a plain readout of where you stand, what the rites
cost and what the wood around you has banked.

Timber is the currency. Anything left on an altar becomes tribute, but a log is worth three times what an
ordinary item is, because the forest takes its own body back more seriously than anything you could bring it.
That makes felling a stand and handing the wood over the plain way to pay for a rite — and a bleak one, since
you are buying a weed with the trees you killed and the felling goes on your tally regardless. A stack of logs
buys any of the five lesser invasives outright. Kudzu costs a stack and a half, and twenty trees on top.

Build a verdant altar from heartwood the trees gave you, and it becomes the place where you deal with them. Four
charms, four rites: call up a grove of whatever belongs in this country, call the forest's own roots up through
the soil, trade a pile of good timber for the forest's lasting resentment, or deliberately let the weed in.

The altar also notices what dies on it. A hostile mob is worth a little. An animal is worth more. A tamed pet —
something that trusted you — is worth a great deal, and the forest understands exactly what it cost you.

## Tools for the ones that fight back

A brush hook cuts anything green, badly. Three specialists each answer a weed it cannot deal with: a
**heartwood lopper** for woody growth, which gets six times as much wisteria in a swing as the hook does; a
**grubbing mattock** that follows knotweed and kudzu root eight blocks straight down under your floor, where
nothing else you own can reach; and a **hedge slasher** with the widest sweep in the mod, which keeps bramble
thorns off you as long as you are holding it. All three are iron-tier weapons as well, which matters, because
whatever has been breeding under the leaf mats has to be got through first.

Clearing with any of them earns the forest's favour at the same rate as doing it by hand, so one swing through
a thick stand can be worth several offerings at once.

## Heartwood gear

Heartwood cannot be mined or farmed. The trees give it to you, once they think enough of you, and it makes a
sword, an axe, and an armour set the forest recognises as its own — wear the full set and it treats you as one
step less hated than you are. A brush hook cuts kudzu and every other weed five blocks at a time, which is both the fastest way back into
the forest's good books and the only sane way to clear wisteria.

## What counts

* Chopping a tree down
* Burning it with flint and steel, a fire charge or lava
* Blowing it up with TNT

Every player has their own tally, so in a shared world the forest can be sick of one of you and fond of
another. It is saved with the world.

## Details

* A message and a sound mark each new stage.
* Everything is configurable: stage thresholds, height cap, regrow chance, tendril damage, and whether built blocks or containers can be broken. Containers are safe by default; beds, obsidian and bedrock are always safe.
* Creative and spectator players are never targeted.
* Operator commands: `/vengefulwoods status`, `/vengefulwoods set <number>`, `/vengefulwoods favor <number>`, `/vengefulwoods reset`, `/vengefulwoods kudzu start|stop`. Everyone can use `/woods class`, `/woods skills`, `/woods original`, `/woods shimmer`.
* **Servers can share.** Two independent settings: `shareStanding` puts the whole server on one tally of hate and favour, so one person clearing land puts the woods on everybody; `shareSkills` gives the whole server one pool of skill points and one set of ranks. Your class is always your own either way.
* Works with every tree species that Dynamic Trees and its add-ons provide.

## Modpacks

You may include this mod in any modpack.
